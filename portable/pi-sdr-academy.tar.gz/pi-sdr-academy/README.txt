CLOSED NETWORK — START HERE
===========================

Needs on the target machine: python3 only.
Does NOT need: pip, internet, venv, sudo, Docker.

1) tar -xzf pi-sdr-academy.tar.gz
2) cd pi-sdr-academy
3) ./run.sh
4) Open the URL it prints (usually http://127.0.0.1:8080/)

Then: Start (a terminal opens in ~/signal-dojo/challenge) → solve → Done

That's the whole install.

CLASSROOM (one server, many browsers)
  ./academy serve --host <this machine's LAN IP>
  Learners open http://<that IP>:8080/, pick a username + password, and solve
  in their folder on the server (the page shows its path). See docs/CLASSROOM.md for the shared
  git progress repo. All learners share this machine's OS account: use a
  dedicated Pi / VM / container.
