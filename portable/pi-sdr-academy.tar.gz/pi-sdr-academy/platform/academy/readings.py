"""Offline copies of the outside reading (PySDR chapters, GNU Radio tutorials), served at /readings/.

curriculum/readings/sources.json lists every page; scripts/fetch_readings.py downloads them once on a
machine with internet. Lessons link to /readings/<site>/<file>, never to the web.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

TYPES = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".svg": "image/svg+xml",
    ".webp": "image/webp",
    ".ico": "image/x-icon",
    ".woff": "font/woff",
    ".woff2": "font/woff2",
    ".ttf": "font/ttf",
    ".txt": "text/plain; charset=utf-8",
}


def page_file(page: str) -> str:
    """File name of one mirrored page: wiki titles like `Simulation_example:_X` become safe names."""
    return re.sub(r"[^A-Za-z0-9_.-]", "_", page) + ".html"


def load_sources(readings_dir: Path) -> dict:
    path = readings_dir / "sources.json"
    return json.loads(path.read_text(encoding="utf-8")) if path.is_file() else {}


def reading_links(readings_dir: Path) -> dict[str, str]:
    """Every allowed /readings/ page link -> its title."""
    out = {}
    for site, spec in load_sources(readings_dir).items():
        for page, title in spec.get("pages", {}).items():
            out[f"/readings/{site}/{page_file(page)}"] = title
    return out


def reading_file(readings_dir: Path, rel: str):
    """(bytes, content type) for a file under readings_dir, or None. Refuses anything outside it."""
    parts = [p for p in rel.split("/") if p]
    if not parts or any(p in (".", "..") or p.startswith(".") or "\\" in p for p in parts):
        return None
    root = readings_dir.resolve()
    path = root.joinpath(*parts).resolve()
    if root not in path.parents or not path.is_file():
        return None
    ctype = TYPES.get(path.suffix.lower())
    if ctype is None:
        return None
    return path.read_bytes(), ctype
