#!/usr/bin/env python3
"""Ghost Rotor checker.

./check        grade every milestone (CHECK_OK only when all seven pass)
./check 3      grade milestone 3 only
"""
import glob
import contextlib
import hashlib
import importlib
import io
import json
import math
import os
import re
import shutil
import signal
import struct
import subprocess
import sys
import tempfile

sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)
sys.path.insert(0, HERE)

import numpy as np  # noqa: E402

EXPECTED = json.load(open("tests/expected.json"))
CAPTURE_META = "captures/tower_915M_usrp.sigmf-meta"  # the checker's own reference copy of the scene
CAPTURE_DATA = "captures/tower_915M_usrp.sigmf-data"
SYNC = "0010110111010100"
TMP = tempfile.mkdtemp(prefix="rotor-check-")


def sha(s):
    return hashlib.sha256(str(s).encode()).hexdigest()


class Milestone:
    def __init__(self):
        self.fails = []

    def task(self, name, fn):
        try:
            fn()
        except NotImplementedError:
            self.fails.append(f"{name}: not implemented yet")
        except AssertionError as exc:
            self.fails.append(f"{name}: {exc}")
        except Exception as exc:  # show the learner what broke
            self.fails.append(f"{name}: {type(exc).__name__}: {exc}")


def load(module):
    if module in sys.modules:
        del sys.modules[module]
    return importlib.import_module(module)


def run(cmd, timeout=300, env=None, **kw):
    full_env = os.environ.copy()
    full_env.update(env or {})
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, env=full_env,
                          stdin=subprocess.DEVNULL, **kw)


def tail(proc, n=4):
    text = (proc.stderr or proc.stdout or "").strip().splitlines()
    return " | ".join(text[-n:]) or f"exit code {proc.returncode}"


def crashed(proc):
    if proc.returncode < 0:
        return signal.Signals(-proc.returncode).name
    if proc.returncode in (139, 134):  # shells report signals as 128 + n
        return "SIGSEGV" if proc.returncode == 139 else "SIGABRT"
    return None


def field_iq():
    raw = np.fromfile(CAPTURE_DATA, "<i2").astype(np.float32)
    return (raw[0::2] + 1j * raw[1::2]) / 32768


def chosen_capture():
    """The recording station.conf points at (its CAPTURE= setting)."""
    try:
        p = run(["bash", "-c", '. ./station.conf && printf %s "$CAPTURE"'], timeout=30,
                env={"CAPTURE": ""})
        if p.returncode == 0 and os.path.exists(p.stdout.strip()):
            return p.stdout.strip()
    except (OSError, subprocess.TimeoutExpired):
        pass
    return CAPTURE_META


def reference_baseband(offset=62_600, fs=250_000, decim=10):
    """The checker's own channelizer, so milestone 4 does not depend on milestone 3."""
    x = field_iq()
    x = x - np.mean(x)
    n = np.arange(len(x))
    y = x * np.exp(-2j * np.pi * offset * n / fs)
    k = np.arange(129) - 64
    h = np.sinc(2 * 6000 / fs * k) * np.hamming(129)
    return (np.convolve(y, h / h.sum(), "same")[::decim]).astype(np.complex64)


def frame_hashes(bits):
    """Hash every frame found after a sync word (either polarity). No CRC needed here."""
    found = set()
    for b in (bits, bits.translate(str.maketrans("01", "10"))):
        i = b.find(SYNC)
        while i >= 0:
            p = i + 16
            if p + 8 <= len(b):
                n = (1 + int(b[p:p + 8], 2) + 2) * 8
                if p + n <= len(b):
                    found.add(hashlib.sha256(bytes(int(b[p + k:p + k + 8], 2) for k in range(0, n, 8))).hexdigest())
            i = b.find(SYNC, i + 1)
    return found & set(EXPECTED["frames"])


def intercept_ok(rep, key):
    pos = rep.get(key) or {}
    return sha(f"{pos.get('lat', 0):.3f},{pos.get('lon', 0):.3f}") == EXPECTED[key]


def read_png(path):
    """Grey 8-bit PNG -> (width, height, pixels). Handles all five PNG row filters."""
    import zlib
    data = open(path, "rb").read()
    assert data[:8] == b"\x89PNG\r\n\x1a\n", f"{path} is not a PNG file"
    pos, idat, w = 8, b"", 0
    while pos < len(data):
        n, kind = struct.unpack(">I4s", data[pos:pos + 8])
        body = data[pos + 8:pos + 8 + n]
        if kind == b"IHDR":
            w, h, depth, ctype = struct.unpack(">IIBB", body[:10])
            assert depth == 8 and ctype == 0, f"{path} should be 8-bit greyscale (use write_png)"
        elif kind == b"IDAT":
            idat += body
        pos += 12 + n
    raw, out, prev = zlib.decompress(idat), bytearray(), bytearray(w)
    for y in range(h):
        f, row = raw[y * (w + 1)], bytearray(raw[y * (w + 1) + 1:(y + 1) * (w + 1)])
        for x in range(w):
            a, b, c = (row[x - 1] if x else 0), prev[x], (prev[x - 1] if x else 0)
            if f == 1:
                row[x] = (row[x] + a) & 255
            elif f == 2:
                row[x] = (row[x] + b) & 255
            elif f == 3:
                row[x] = (row[x] + (a + b) // 2) & 255
            elif f == 4:
                p = a + b - c
                pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
                row[x] = (row[x] + (a if pa <= pb and pa <= pc else b if pb <= pc else c)) & 255
        out += row
        prev = row
    return w, h, bytes(out)


def gr_python():
    """First interpreter that can import GNU Radio: $GR_PYTHON, station.conf, then the usual places."""
    cands = [os.environ.get("GR_PYTHON")]
    try:
        m = re.search(r"GR_PYTHON=\$\{GR_PYTHON:-([^}]+)\}", open("station.conf").read())
        cands.append(m and m.group(1).strip())
    except OSError:
        pass
    cands += [shutil.which("python3"), "/usr/bin/python3", sys.executable,
              os.path.expanduser("~/radioconda/bin/python"), os.path.expanduser("~/miniforge3/bin/python"),
              "/opt/homebrew/bin/python3", "/usr/local/bin/python3"] + sorted(glob.glob("/usr/bin/python3.*"))
    seen = set()
    for c in cands:
        c = shutil.which(c) if c and not os.path.isabs(c) else c
        if not c or c in seen or not os.path.exists(c) or c.endswith("-config"):
            continue
        seen.add(c)
        try:
            if run([c, "-c", "from gnuradio import gr, blocks, filter"], timeout=30).returncode == 0:
                return c
        except (OSError, subprocess.TimeoutExpired):
            pass
    return None


# ---------------------------------------------------------------- 1 Field kit (Linux, shell)
def m1(t):
    def perms():
        for s in ("bin/inventory.sh", "bin/station.sh"):
            assert os.path.isfile(s), f"{s} is missing"
            assert os.access(s, os.X_OK), f"{s} is not executable yet (chmod)"
    t.task("1.1 scripts are executable", perms)

    def expected_csv(d):
        per = {"ci16_le": 4, "cf32_le": 8}
        rows = []
        for meta in glob.glob(os.path.join(d, "*.sigmf-meta")):
            m = json.load(open(meta))
            g, c = m["global"], m["captures"][0]
            n = os.path.getsize(meta[:-len(".sigmf-meta")] + ".sigmf-data") // per[g["core:datatype"]]
            rows.append((c["core:frequency"], f"{os.path.basename(meta)[:-11]},{g['core:datatype']},"
                                              f"{g['core:sample_rate']},{c['core:frequency']},{n}"))
        return ["name,datatype,sample_rate,frequency,samples"] + [r for _, r in sorted(rows)]

    def inventory(d):
        assert os.access("bin/inventory.sh", os.X_OK), "make bin/inventory.sh executable first"
        p = run(["bin/inventory.sh", d], timeout=60)
        assert p.returncode == 0, f"bin/inventory.sh {d} failed: {tail(p)}"
        return [line.strip() for line in p.stdout.strip().splitlines()]

    def field_kit():
        got, want = inventory("captures"), expected_csv("captures")
        assert got == want, f"on captures/ expected\n        " + "\n        ".join(want) + "\n      got\n        " + "\n        ".join(got)
    t.task("1.2 inventory of captures/", field_kit)

    def other_dir():
        d = os.path.join(TMP, "kit")
        os.makedirs(d, exist_ok=True)
        rng = np.random.default_rng()
        for i, (dt, per) in enumerate([("ci16_le", 4), ("cf32_le", 8), ("ci16_le", 4), ("cf32_le", 8)]):
            fc, fs, n = int(rng.integers(50, 6000)) * 1_000_000 + i, int(rng.integers(1, 40)) * 250_000, int(rng.integers(10, 900))
            meta = {"global": {"core:datatype": dt, "core:sample_rate": fs, "core:version": "1.0.0"},
                    "captures": [{"core:sample_start": 0, "core:frequency": fc}], "annotations": []}
            with open(os.path.join(d, f"rec{i}.sigmf-meta"), "w") as f:
                json.dump(meta, f, indent=2)
            with open(os.path.join(d, f"rec{i}.sigmf-data"), "wb") as f:
                f.write(b"\x01" * n * per)
        got, want = inventory(d), expected_csv(d)
        assert got == want, "on another folder of recordings expected\n        " + "\n        ".join(want) + "\n      got\n        " + "\n        ".join(got)
    t.task("1.3 inventory of any folder (no hard-coded answers)", other_dir)


# ---------------------------------------------------------------- 2 Survey the band (Python, PySDR)
def m2(t):
    rng = np.random.default_rng(2)

    def load_iq():
        s = load("scan")
        cases = [
            ("ci16_le", np.array([32767, -32768, 0, 16384], "<i2"), [(32767 - 32768j), (0 + 16384j)], 32768),
            ("cf32_le", np.array([0.5, -0.25, 1.0, 0.0], "<f4"), [(0.5 - 0.25j), (1 + 0j)], 1),
        ]
        for dt, raw, want, scale in cases:
            p = os.path.join(TMP, "t." + dt)
            raw.tofile(p)
            y = np.asarray(s.load_iq(p, dt))
            want = np.array(want) / scale
            assert y.dtype == np.complex64 and len(y) == 2 and np.allclose(y, want, atol=1e-6), \
                f"{dt}: got {y}, want {want}"
        p = os.path.join(TMP, "t.ci16_le")
        try:
            s.load_iq(p, "ci32_le")
        except ValueError:
            pass
        else:
            raise AssertionError("an unknown datatype such as ci32_le should raise ValueError")
    t.task("2.1 load_iq (ci16_le, cf32_le)", load_iq)

    def psd():
        s = load("scan")
        fs, n = 100_000, 50_000
        x = 0.5 * np.exp(2j * np.pi * 10_000 * np.arange(n) / fs) + 2.0 + 0.01 * rng.standard_normal(n)
        f, p = s.psd_db(x, fs, 256)
        assert len(f) == 256 and len(p) == 256, "return 256 frequencies and 256 powers"
        assert abs(f[0] + fs / 2) < 1e-6, "frequencies run from -fs/2 (fftshift)"
        assert abs(f[np.argmax(p)] - 10_000) < fs / 256, f"peak at {f[np.argmax(p)]} Hz, the tone is at 10000 Hz (remove the mean first)"
        assert np.max(p) - np.median(p) > 30, "p_db should be 10*log10 of power"
    t.task("2.2 psd_db", psd)

    def channels():
        s = load("scan")
        f = np.arange(-50, 50) * 100.0
        p = np.zeros(100)
        p[10:13] = 30
        p[60:70] = 15
        p[71] = 9
        got = [(round(c), round(b)) for c, b in s.find_channels(f, p, 10)]
        assert got == [(-3900, 300), (1450, 1000)], f"got {got}"
    t.task("2.3 find_channels", channels)

    def extract():
        s = load("scan")
        fs, n = 250_000, 20_000
        k = np.arange(n)
        x = np.exp(2j * np.pi * 20_000 * k / fs) + np.exp(2j * np.pi * -30_000 * k / fs)
        y = np.asarray(s.extract(x, fs, 20_000, 4_000))
        assert len(y) == n, "keep the length (np.convolve 'same')"
        mid = y[500:-500]
        assert abs(np.mean(np.abs(mid) ** 2) - 1) < 0.05 and np.std(np.angle(mid[1:] * np.conj(mid[:-1]))) < 0.01, \
            "the 20 kHz tone should come out at 0 Hz with power 1, the -30 kHz tone removed"
    t.task("2.4 extract", extract)

    def classify():
        s = load("scan")
        fs, n = 25_000, 25_000
        k = np.arange(n)
        noise = 0.05 * (rng.standard_normal(n) + 1j * rng.standard_normal(n))
        cw = np.exp(2j * np.pi * 50 * k / fs) + noise
        on = np.repeat(rng.integers(0, 2, n // 50 + 1), 50)[:n]
        ook = on * np.exp(2j * np.pi * -80 * k / fs) + noise
        sym = np.repeat(2.0 * rng.integers(0, 2, n // 5 + 1) - 1, 5)[:n]
        sym = np.convolve(sym, np.ones(3) / 3, "same")
        bpsk = sym * np.exp(2j * np.pi * 120 * k / fs + 0.4j) + noise
        got = [s.classify(v, fs) for v in (cw, ook, bpsk)]
        assert got == ["cw", "ook", "bpsk"], f"cw, ook, bpsk test signals were classified as {got}"
    t.task("2.5 classify", classify)

    def survey():
        s = load("scan")
        work = os.path.join(TMP, "scan")
        with contextlib.redirect_stdout(io.StringIO()):
            s.main(capture, work)
        assert os.path.getsize(os.path.join(work, "field.cf32")) == 562_500 * 8, "field.cf32 should hold 562500 complex64 samples"
        ch = json.load(open(os.path.join(work, "channels.json")))
        kinds = sorted(c["kind"] for c in ch)
        assert kinds == ["bpsk", "cw", "ook"], f"expected one cw, one ook and one bpsk channel in {capture}, got {kinds}"
        b = next(c for c in ch if c["kind"] == "bpsk")
        assert abs(b["offset_hz"] - 62_680) < 1500 and abs(b["freq_hz"] - 915_062_680) < 1500, f"bpsk channel at {b}"
        assert 4000 < b["bw_hz"] < 10_000, f"bpsk bandwidth {b['bw_hz']} Hz looks wrong"
    capture = chosen_capture()
    t.task(f"2.6 survey of {os.path.basename(capture)} (python3 scan.py)", survey)


# ---------------------------------------------------------------- 3 Tune in (GNU Radio)
def m3(t):
    def grc():
        assert os.path.isfile("gr/rx_drone.grc"), "build gr/rx_drone.grc in GNU Radio Companion (save it in gr/)"
        text = open("gr/rx_drone.grc").read()
        for block in ("blocks_file_source", "freq_xlating_fir_filter", "blocks_file_sink"):
            assert block in text, f"the flowgraph has no {block} block"
        for p in ("infile", "outfile", "offset"):
            assert re.search(rf"name: {p}\s*\n\s*id: parameter", text), f"add a Parameter block with id {p}"
        assert "generate_options: no_gui" in text, "Options block: Generate Options = No GUI"
        assert "run_options: run" in text, "Options block: Run Options = Run to Completion"
    t.task("3.1 gr/rx_drone.grc", grc)

    def flowgraph():
        py = gr_python()
        assert py, ("no Python here can `import gnuradio`. Install GNU Radio, or set "
                    "GR_PYTHON=/path/to/python in station.conf (GR_PYTHON=${GR_PYTHON:-/path/to/python})")
        assert os.path.isfile("gr/rx_drone.py"), "press Generate (F5) in GNU Radio Companion to write gr/rx_drone.py"
        src = os.path.join(TMP, "field_ref.cf32")
        x = field_iq().astype(np.complex64)
        x.tofile(src)
        out = os.path.join(TMP, "drone_gr.cf32")
        if os.path.exists(out):
            os.remove(out)
        p = run([py, "gr/rx_drone.py", "--infile", src, "--outfile", out, "--offset", "62600"], timeout=180)
        assert p.returncode == 0, f"gr/rx_drone.py --infile ... --outfile ... --offset 62600 failed: {tail(p)}"
        assert os.path.exists(out), "the flowgraph wrote no output file (File Sink file = outfile?)"
        y = np.fromfile(out, np.complex64)
        assert abs(len(y) - len(x) // 10) < 100, f"expected about {len(x) // 10} samples (decimate by 10), got {len(y)}"
        assert np.mean(np.abs(y) ** 2) > 1e-3, "the output is (almost) silent"
        spec = np.abs(np.fft.fftshift(np.fft.fft(y))) ** 2
        f = np.fft.fftshift(np.fft.fftfreq(len(y), 1 / 25_000))
        inband = spec[np.abs(f) < 4500].sum() / spec.sum()
        assert inband > 0.9, f"only {inband:.0%} of the output power is within 4.5 kHz of 0 Hz: tune to the offset and low-pass"
    t.task("3.2 the flowgraph runs and outputs the drone downlink at 0 Hz, 25 kHz", flowgraph)


# ---------------------------------------------------------------- 4 Demodulate (DSP)
def m4(t):
    rng = np.random.default_rng(4)

    def rrc():
        d = load("demod")
        for sps, beta, span in ((4, 0.35, 6), (4, 0.25, 8), (5, 0.35, 8)):
            h = np.asarray(d.rrc_taps(sps, beta, span), float)
            assert len(h) == span * sps + 1, f"rrc_taps({sps}, {beta}, {span}) should have {span * sps + 1} taps"
            assert np.all(np.isfinite(h)), f"rrc_taps({sps}, {beta}, {span}) has NaN/inf (the t = ±1/(4β) case)"
            assert abs(np.sum(h ** 2) - 1) < 1e-6 and np.allclose(h, h[::-1]), "unit energy and symmetric"
            rc = np.convolve(h, h)
            c = len(rc) // 2
            isi = [abs(rc[c + k * sps]) for k in range(1, span)]
            assert abs(rc[c] - 1) < 1e-6 and max(isi) < 0.02, "RRC * RRC should have no ISI at multiples of sps"
    t.task("4.1 rrc_taps", rrc)

    def cfo():
        d = load("demod")
        fs, n = 25_000, 30_000
        sym = np.repeat(2.0 * rng.integers(0, 2, n // 5 + 1) - 1, 5)[:n]
        x = sym * np.exp(2j * np.pi * 317 * np.arange(n) / fs + 1j) + 0.1 * rng.standard_normal(n)
        got = d.coarse_cfo(x, fs)
        assert abs(got - 317) < 3, f"estimated {got} Hz, the offset is 317 Hz"
    t.task("4.2 coarse_cfo", cfo)

    def sync():
        d = load("demod")
        sym = 2.0 * rng.integers(0, 2, 400) - 1
        up = np.zeros(2000)
        up[3::5] = sym
        y = np.convolve(up, np.array([0.2, 0.6, 1, 0.6, 0.2]), "same")
        s = np.asarray(d.symbol_sync(y, 5))
        assert len(s) == 400 and np.allclose(s, sym), "pick the sampling offset with the most energy and return y[o::sps]"
    t.task("4.3 symbol_sync", sync)

    def costas():
        d = load("demod")
        sym = 2.0 * rng.integers(0, 2, 600) - 1
        s = sym * np.exp(1j * (0.9 + 0.02 * np.arange(600))) + 0.05 * rng.standard_normal(600)
        out = np.asarray(d.costas(s))
        assert len(out) == 600, "same length out"
        late = out[300:]
        assert np.mean(np.abs(late.imag)) < 0.15 * np.mean(np.abs(late.real)), \
            "after the loop locks, the symbols should lie on the real axis (check the phase and freq updates)"
    t.task("4.4 costas", costas)

    def field():
        d = load("demod")
        bits = d.demodulate(reference_baseband())
        assert isinstance(bits, str) and set(bits) <= {"0", "1"} and len(bits) > 10_000, "return a str of '0'/'1', one per symbol"
        got = len(frame_hashes(bits))
        need = len(EXPECTED["frames"]) - 2
        assert got >= need, f"{got} of {len(EXPECTED['frames'])} downlink frames came out intact (need {need})"
    t.task("4.5 demodulate the drone downlink (frames found intact)", field)


# ---------------------------------------------------------------- 5 Decode frames (C++, gdb)
def m5(t):
    def unit():
        p = run(["make", "-s", "-C", "framer", "test_frame"], timeout=180)
        assert p.returncode == 0, f"make test_frame does not compile yet: {tail(p, 3)}"
        p = run(["./framer/test_frame"], timeout=30)
        assert p.returncode == 0, "; ".join(p.stdout.strip().splitlines()[:6]) or tail(p)
    t.task("5.1-5.4 frame.h unit tests (make -C framer test)", unit)

    def fixture():
        p = run(["make", "-s", "-C", "framer", "framer"], timeout=180)
        assert p.returncode == 0, f"framer does not compile yet: {tail(p, 3)}"
        p = run(["./framer/framer", "framer/tests/fixtures/mixed.bits"], timeout=30)
        sig = crashed(p)
        assert not sig, (f"framer crashed ({sig}) on framer/tests/fixtures/mixed.bits. It was built with -g: "
                         "cd framer; gdb --args ./framer tests/fixtures/mixed.bits, then run, bt, frame, info locals")
        assert p.returncode == 0, f"framer exited with {p.returncode}: {tail(p)}"
        got = [json.loads(line) for line in p.stdout.splitlines() if line.strip()]
        want = [json.loads(line) for line in open("framer/tests/fixtures/mixed.expected.jsonl")]
        assert len(got) == len(want), f"expected {len(want)} JSON lines, got {len(got)}"
        for i, (g, w) in enumerate(zip(got, want), 1):
            for k, v in w.items():
                ok = k in g and (abs(g[k] - v) < 1e-6 if isinstance(v, float) else g[k] == v)
                assert ok, f"line {i}: {k} should be {v!r}, got {g.get(k)!r}"
    t.task("5.5 framer decodes the test fixture without crashing", fixture)

    def crash():
        path = "framer/crash_seq.txt"
        assert os.path.isfile(path), ("run the original framer on your work/bits.txt in gdb. When it crashes, "
                                      "write the seq of the packet it was decoding into framer/crash_seq.txt")
        val = open(path).read().strip()
        assert sha(val) == EXPECTED["crash_seq"], f"{val!r} is not the seq of the packet that crashed the framer"
    t.task("5.6 framer/crash_seq.txt (found with gdb)", crash)


# ---------------------------------------------------------------- 6 Intercept report (Python)
def m6(t):
    def packets():
        r = load("report")
        lines = [
            {"type": "fix", "crc_ok": True, "seq": 7, "t_s": 70, "lat": 1.0, "lon": 2.0, "alt_m": 900, "temp_c": 1.0, "batt_v": 3.9},
            {"crc_ok": False, "bit": 5},
            {"type": "status", "crc_ok": True, "seq": 9, "text": "HI"},
            {"type": "fix", "crc_ok": True, "seq": 3, "t_s": 30, "lat": 1.0, "lon": 2.0, "alt_m": 400, "temp_c": 1.0, "batt_v": 3.9},
            {"type": "unknown", "crc_ok": True, "seq": 4, "type_id": 9},
            {"type": "image", "crc_ok": True, "seq": 12, "part": 0, "parts": 1, "data": "00ff"},
            {"type": "fix", "crc_ok": True, "seq": 7, "t_s": 70, "lat": 1.0, "lon": 2.0, "alt_m": 900, "temp_c": 1.0, "batt_v": 3.9},
            {"crc_ok": False, "bit": 77},
        ]
        p = os.path.join(TMP, "p.jsonl")
        with open(p, "w") as f:
            f.write("\n".join(json.dumps(x) for x in lines) + "\n\n")
        got, bad = r.load_packets(p)
        assert [x["seq"] for x in got] == [3, 7, 9, 12], \
            f"expected seqs [3, 7, 9, 12] (crc_ok fix/status/image, no repeats, sorted), got {[x['seq'] for x in got]}"
        assert bad == 2, f"2 CRC failures, got {bad}"
    t.task("6.1 load_packets", packets)

    def hav():
        r = load("report")
        d = r.haversine_km(0, 0, 0, 1)
        assert abs(d - 111.195) < 0.01, f"(0,0) to (0,1) is 111.195 km, got {d}"
        d = r.haversine_km(51.5074, -0.1278, 48.8566, 2.3522)
        assert abs(d - 343.56) < 0.1, f"London to Paris is 343.56 km, got {d}"
    t.task("6.2 haversine_km", hav)

    def summary():
        r = load("report")
        pk = [
            {"type": "fix", "seq": 1, "t_s": 100, "lat": 10.0, "lon": 20.0, "alt_m": 50},
            {"type": "fix", "seq": 2, "t_s": 900, "lat": 10.5, "lon": 20.2, "alt_m": 12000},
            {"type": "status", "seq": 3, "text": "RTH ARMED. PILOT ID AB-12. LINK OK"},
            {"type": "fix", "seq": 4, "t_s": 1500, "lat": 10.25, "lon": 20.5, "alt_m": 300},
            {"type": "fix", "seq": 5, "t_s": 1200, "lat": 10.3, "lon": 20.4, "alt_m": 800},
        ]
        got = r.summarize(pk, 4, tower=(10.1, 20.3))
        want = {"drone": {"lat": 10.25, "lon": 20.5, "alt_m": 300}, "home": {"lat": 10.0, "lon": 20.0},
                "max_alt_m": 12000, "flight_time_s": 1400,
                "range_km": round(r.haversine_km(10.1, 20.3, 10.25, 20.5), 2), "operator_id": "AB-12",
                "packets": 5, "crc_failures": 4}
        for k, v in want.items():
            assert got.get(k) == v, f"{k} should be {v!r}, got {got.get(k)!r}"
    t.task("6.3 summarize", summary)

    def image():
        import zlib
        r = load("report")
        w, h = 11, 3
        rows = [0b10100000, 0b00100000, 0b00000000, 0b00000000, 0b11111111, 0b11100000]
        blob = zlib.compress(struct.pack("<HH", w, h) + bytes(rows))
        cut = [blob[i:i + 5] for i in range(0, len(blob), 5)]
        pk = [{"type": "image", "seq": 50 + i, "part": i, "parts": len(cut), "data": c.hex()} for i, c in enumerate(cut)]
        pk = [{"type": "fix", "seq": 1, "t_s": 0, "lat": 0.0, "lon": 0.0, "alt_m": 0}] + pk[::-1]
        got = r.rebuild_image(pk)
        want = bytes([255, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255] + [0] * 11 + [255] * 11)
        assert tuple(got[:2]) == (w, h), f"width, height should be {(w, h)}, got {tuple(got[:2])}"
        assert bytes(got[2]) == want, f"pixels should be {list(want)}, got {list(bytes(got[2]))}"
        try:
            r.rebuild_image(pk[:-1])
        except ValueError:
            pass
        else:
            raise AssertionError("with a part missing, rebuild_image should raise ValueError")
    t.task("6.4 rebuild_image", image)

    def real():
        path = "work/intercept.json"
        assert os.path.isfile(path), "run your chain on the tower capture: python3 report.py work/packets.jsonl work/intercept.json"
        rep = json.load(open(path))
        assert intercept_ok(rep, "drone"), "the drone position in work/intercept.json is not where the drone is"
        assert intercept_ok(rep, "home"), "the home point in work/intercept.json is not where the drone took off"
        assert sha(rep.get("operator_id")) == EXPECTED["operator_id"], "operator_id is not right"
        assert sha(rep.get("max_alt_m")) == EXPECTED["max_alt_m"], "max_alt_m is not right"
    t.task("6.5 work/intercept.json from the tower capture", real)

    def snapshot():
        path = "work/snapshot.png"
        assert os.path.isfile(path), "python3 report.py work/packets.jsonl work/intercept.json also writes work/snapshot.png"
        w, h, pixels = read_png(path)
        assert hashlib.sha256(pixels).hexdigest() == EXPECTED["snapshot"], \
            f"work/snapshot.png ({w}x{h}) is not the drone's camera frame. Open it: is it a clear picture?"
    t.task("6.6 work/snapshot.png, the drone's camera frame", snapshot)


# ---------------------------------------------------------------- 7 Run the station (Linux ops)
def m7(t):
    def units():
        import configparser

        def ini(path):
            assert os.path.isfile(path), f"{path} is missing"
            c = configparser.ConfigParser(strict=False, interpolation=None)
            c.optionxform = str
            c.read(path)
            return c
        s = ini("deploy/rotor-watch.service")
        assert s.has_section("Service"), "rotor-watch.service needs a [Service] section"
        sv = s["Service"]
        assert sv.get("Type") == "oneshot", "Type=oneshot: the station runs once and exits"
        assert sv.get("ExecStart", "").startswith("/") and sv.get("ExecStart", "").rstrip().endswith("bin/station.sh"), \
            "ExecStart= the absolute path of bin/station.sh"
        assert sv.get("WorkingDirectory", "").startswith("/"), "WorkingDirectory= an absolute path"
        assert sv.get("User"), "User= the account to run as (not root)"
        assert sv.get("User") != "root", "do not run the station as root"
        tm = ini("deploy/rotor-watch.timer")
        assert tm.has_section("Timer"), "rotor-watch.timer needs a [Timer] section"
        assert any(k in tm["Timer"] for k in ("OnCalendar", "OnUnitActiveSec")), "the timer needs OnCalendar= or OnUnitActiveSec="
        assert tm.has_section("Install") and tm["Install"].get("WantedBy") == "timers.target", "[Install] WantedBy=timers.target"
    t.task("7.1 deploy/rotor-watch.service and .timer", units)

    def station():
        assert os.access("bin/station.sh", os.X_OK), "bin/station.sh is not executable"
        assert re.search(r"^\s*set\s+-[a-z]*e", open("bin/station.sh").read(), re.M), "bin/station.sh should stop at the first error (set -e)"
        work = os.path.join(TMP, "station")
        env = {"WORK_DIR": work, "LOG_DIR": os.path.join(work, "logs")}
        py = gr_python()
        if py:
            env["GR_PYTHON"] = py
        p = run(["bin/station.sh"], timeout=600, env=env)
        assert p.returncode == 0, f"WORK_DIR={work} bin/station.sh failed: {tail(p)}"
        rep = json.load(open(os.path.join(work, "intercept.json")))
        assert intercept_ok(rep, "drone") and intercept_ok(rep, "home") and \
            sha(rep.get("operator_id")) == EXPECTED["operator_id"], "the station's intercept.json is wrong"
        logs = glob.glob(os.path.join(work, "logs", "*.log"))
        assert logs and os.path.getsize(logs[0]) > 0, "the station should write a log file into LOG_DIR"
        p = run(["bin/station.sh"], timeout=300, env={**env, "CAPTURE": "captures/missing.sigmf-meta", "WORK_DIR": work + "2"})
        assert p.returncode != 0, "with a missing capture bin/station.sh must exit non-zero (so systemd sees the failure)"
    t.task("7.2 bin/station.sh runs the whole chain (WORK_DIR, LOG_DIR, set -e)", station)


MILESTONES = [
    ("Field kit (shell)", m1),
    ("Survey the band (Python, PySDR)", m2),
    ("Tune in (GNU Radio)", m3),
    ("Demodulate (DSP)", m4),
    ("Decode the frames (C++, gdb)", m5),
    ("Intercept report (Python)", m6),
    ("Run the station (bash, systemd)", m7),
]


def main(argv):
    pick = [int(a) for a in argv if a.isdigit()]
    todo = [(i, name, fn) for i, (name, fn) in enumerate(MILESTONES, 1) if not pick or i in pick]
    results = []
    for i, name, fn in todo:
        t = Milestone()
        try:
            fn(t)
        except Exception as exc:  # noqa: BLE001
            t.fails.append(f"{type(exc).__name__}: {exc}")
        results.append((i, name, t.fails))
        mark = "ok  " if not t.fails else "todo"
        print(f"[{mark}] {i} {name}")
        for f in t.fails:
            print(f"      - {f}")
    passed = sum(1 for *_, f in results if not f)
    shutil.rmtree(TMP, ignore_errors=True)
    if pick:
        print(f"{passed}/{len(results)} picked milestone(s) pass. Run ./check with no number to grade the project.")
        raise SystemExit(0 if passed == len(results) else 1)
    print(f"{passed}/{len(MILESTONES)} milestones pass")
    if passed != len(MILESTONES):
        raise SystemExit(1)
    print("CHECK_OK")


if __name__ == "__main__":
    main(sys.argv[1:])
