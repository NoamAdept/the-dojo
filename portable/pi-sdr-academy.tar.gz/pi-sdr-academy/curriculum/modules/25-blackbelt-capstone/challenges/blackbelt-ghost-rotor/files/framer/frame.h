// frame.h: the byte-level helpers the framer needs. Milestone 5 tasks 5.1 to 5.4.
// Header-only so the tests and the framer both just #include it.
#pragma once
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

// The 16-bit sync word that starts every frame, sent most significant bit first.
constexpr uint16_t SYNC_WORD = 0x2DD4;

// Task 5.1: CRC-16/CCITT-FALSE. Start crc = 0xFFFF. For each byte: crc ^= byte << 8, then
// 8 times: if the top bit (0x8000) is set, crc = (crc << 1) ^ 0x1021, else crc <<= 1.
// Keep crc to 16 bits. crc16_ccitt("123456789") == 0x29B1.
inline uint16_t crc16_ccitt(const uint8_t* data, size_t n) {
    // TODO
    (void)data; (void)n;
    return 0;
}

// Task 5.2: little-endian reads. p[0] is the least significant byte.
inline uint16_t get_le16(const uint8_t* p) {
    // TODO
    (void)p;
    return 0;
}
inline uint32_t get_le32(const uint8_t* p) {
    // TODO
    (void)p;
    return 0;
}

// Task 5.3: pack nbytes bytes from the '0'/'1' string, starting at bit index start, most
// significant bit first. If invert is true, flip every bit first (the Costas loop can lock
// 180 degrees out, which turns every 1 into 0). Return an empty vector if there are not
// enough bits left.
inline std::vector<uint8_t> pack_bits(const std::string& bits, size_t start, size_t nbytes, bool invert) {
    // TODO
    (void)bits; (void)start; (void)nbytes; (void)invert;
    return {};
}

// Task 5.4: find the next sync word at or after bit index from. Look for SYNC_WORD as 16
// '0'/'1' characters and for its inverse (every bit flipped), whichever comes first.
// Return the index of the first bit AFTER the sync word and set inverted, or -1 if neither
// is found.
inline long find_sync(const std::string& bits, size_t from, bool& inverted) {
    // TODO
    (void)bits; (void)from; (void)inverted;
    return -1;
}
