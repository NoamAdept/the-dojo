// framer: find and decode drone telemetry frames in a bit stream.
//
// Usage: ./framer BITS.txt > packets.jsonl     (or pipe the bits on stdin)
//
// A frame on the air:  preamble 0xAA x4 | sync 0x2DD4 | len | payload (len bytes) | CRC-16 (big-endian)
// The CRC covers len + payload. Payload byte 0 is the packet type, bytes 1-2 the sequence number.
// Prints one JSON object per frame.
//
// Inherited from the previous tower crew. It crashes on the tower capture: milestone 5.
#include "frame.h"

#include <cstdio>
#include <fstream>
#include <iostream>
#include <iterator>
#include <string>

// type 1: GPS fix, 21 bytes, all little-endian
//   u8 type | u16 seq | u32 t_s | i32 lat*1e7 | i32 lon*1e7 | u16 alt_m | i16 temp_c*10 | u16 batt_mv
static void decode_fix(const uint8_t* p, size_t n, uint16_t seq) {
    if (n < 21) {
        std::printf("{\"type\": \"fix\", \"crc_ok\": true, \"seq\": %u, \"error\": \"short\"}\n", seq);
        return;
    }
    uint32_t t_s = get_le32(p + 3);
    int32_t lat = static_cast<int32_t>(get_le32(p + 7));
    int32_t lon = static_cast<int32_t>(get_le32(p + 11));
    uint16_t alt = get_le16(p + 15);
    int16_t temp = static_cast<int16_t>(get_le16(p + 17));
    uint16_t batt = get_le16(p + 19);
    std::printf("{\"type\": \"fix\", \"crc_ok\": true, \"seq\": %u, \"t_s\": %u, \"lat\": %.7f, \"lon\": %.7f, "
                "\"alt_m\": %u, \"temp_c\": %.1f, \"batt_v\": %.3f}\n",
                seq, t_s, lat / 1e7, lon / 1e7, alt, temp / 10.0, batt / 1000.0);
}

// type 2: status text, u8 type | u16 seq | ASCII text
static void decode_status(const uint8_t* p, size_t n, uint16_t seq) {
    std::string text;
    for (size_t i = 3; i < n; ++i) {
        char c = static_cast<char>(p[i]);
        if (c == '"' || c == '\\') text += '\\';
        text += c;
    }
    std::printf("{\"type\": \"status\", \"crc_ok\": true, \"seq\": %u, \"text\": \"%s\"}\n", seq, text.c_str());
}

// type 3: one part of a camera image, u8 type | u16 seq | u8 part | u8 parts | data
// The data bytes are printed as hex; report.py puts the parts back together.
static void decode_image(const uint8_t* p, size_t n, uint16_t seq) {
    if (n < 5) {
        std::printf("{\"type\": \"image\", \"crc_ok\": true, \"seq\": %u, \"error\": \"short\"}\n", seq);
        return;
    }
    std::string hex;
    char two[3];
    for (size_t i = 5; i < n; ++i) {
        std::snprintf(two, sizeof two, "%02x", p[i]);
        hex += two;
    }
    std::printf("{\"type\": \"image\", \"crc_ok\": true, \"seq\": %u, \"part\": %u, \"parts\": %u, \"data\": \"%s\"}\n",
                seq, p[3], p[4], hex.c_str());
}

struct Handler {
    uint8_t type;
    void (*decode)(const uint8_t*, size_t, uint16_t);
};

static const Handler HANDLERS[] = {{1, decode_fix}, {2, decode_status}, {3, decode_image}};

static const Handler* find_handler(uint8_t type) {
    for (const auto& h : HANDLERS)
        if (h.type == type) return &h;
    return nullptr;
}

int main(int argc, char** argv) {
    std::string raw;
    if (argc > 1) {
        std::ifstream in(argv[1]);
        if (!in) {
            std::fprintf(stderr, "framer: cannot open %s\n", argv[1]);
            return 2;
        }
        raw.assign(std::istreambuf_iterator<char>(in), {});
    } else {
        raw.assign(std::istreambuf_iterator<char>(std::cin), {});
    }
    std::string bits;
    for (char c : raw)
        if (c == '0' || c == '1') bits += c;

    size_t pos = 0;
    while (true) {
        bool inverted = false;
        long at = find_sync(bits, pos, inverted);
        if (at < 0) break;
        auto lenb = pack_bits(bits, at, 1, inverted);
        if (lenb.empty()) break;
        size_t len = lenb[0];
        auto body = pack_bits(bits, at, 1 + len + 2, inverted);
        if (body.empty()) break;  // truncated frame at the end of the recording
        uint16_t sent = static_cast<uint16_t>((body[1 + len] << 8) | body[2 + len]);
        if (crc16_ccitt(body.data(), 1 + len) != sent) {
            std::printf("{\"crc_ok\": false, \"bit\": %ld}\n", at);
            pos = at;
            continue;
        }
        const uint8_t* payload = body.data() + 1;
        uint8_t type = len > 0 ? payload[0] : 0;
        uint16_t seq = len > 2 ? get_le16(payload + 1) : 0;
        const Handler* h = find_handler(type);
        h->decode(payload, len, seq);
        pos = at + (1 + len + 2) * 8;
    }
    return 0;
}
