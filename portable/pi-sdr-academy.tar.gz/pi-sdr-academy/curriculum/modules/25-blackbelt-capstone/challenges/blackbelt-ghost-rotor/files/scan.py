#!/usr/bin/env python3
"""Milestone 2: survey the band.

Usage: python3 scan.py CAPTURE.sigmf-meta WORK_DIR
Writes WORK_DIR/field.cf32 (the capture as complex64) and WORK_DIR/channels.json.
numpy + json only.
"""
import json
import os
import sys

import numpy as np


def load_iq(path, datatype):
    """Task 2.1: read a SigMF data file the USRP made. Both formats are interleaved
    I, Q, I, Q, ... and you return complex64 I + 1j*Q scaled to roughly -1..1:
      "ci16_le"  USRP (UHD sc16): little-endian int16.           raw / 32768
      "cf32_le"  USRP (UHD fc32) or GNU Radio: little-endian float32.  raw as is
    Raise ValueError for anything else."""
    raise NotImplementedError


def psd_db(x, fs, nfft=1024):
    """Task 2.2: averaged power spectrum (Welch).
    Remove the mean first (the DC spike: every direct-conversion radio, such as the
    USRP, leaks a little LO), cut x into non-overlapping blocks of nfft, multiply each by
    np.hanning(nfft), average |FFT|**2 over the blocks, fftshift it and return (freqs, p_db):
    freqs in Hz relative to the tuner (np.fft.fftshift(np.fft.fftfreq(nfft, 1/fs))) and p_db = 10*log10(average power)."""
    raise NotImplementedError


def find_channels(freqs, p_db, threshold_db=10.0):
    """Task 2.3: occupied channels. The noise floor is np.median(p_db). Every run of
    consecutive bins above floor + threshold_db is one channel. Return a list of
    (center_hz, bandwidth_hz) sorted by frequency, where center is the middle of the run
    ((first + last) / 2) and bandwidth = last - first + one bin width."""
    raise NotImplementedError


def extract(x, fs, offset_hz, bw_hz):
    """Task 2.4: bring one channel to 0 Hz and keep only it.
    Multiply by exp(-2j*pi*offset_hz*n/fs), then low-pass filter with a windowed-sinc FIR
    (101 taps, cutoff bw_hz/2, Hamming window, unit DC gain) using np.convolve(..., "same")."""
    raise NotImplementedError


def classify(y, fs):
    """Task 2.5: what is in this (already extracted) channel? Return "bpsk", "ook", "cw" or "unknown".
    tone(v) = the largest |FFT(v)|**2 bin within 1 kHz of 0 Hz divided by the mean of all bins
    (FFT over the whole of v, bin frequencies from np.fft.fftfreq(len(v), 1/fs)).
    - tone(y**2) > 5 * tone(y): squaring removed the +-1 modulation and left a strong tone, so "bpsk".
    - else tone(y) > 100 means a carrier: "ook" if the envelope switches on and off
      (np.std(|y|) / np.mean(|y|) > 0.5), otherwise "cw".
    - otherwise "unknown"."""
    raise NotImplementedError


def read_meta(meta_path):
    with open(meta_path) as f:
        meta = json.load(f)
    g = meta["global"]
    return g["core:datatype"], float(g["core:sample_rate"]), float(meta["captures"][0]["core:frequency"])


def main(meta_path, work):
    """Task 2.6: tie it together (already written, read it)."""
    datatype, fs, fc = read_meta(meta_path)
    x = load_iq(meta_path.replace(".sigmf-meta", ".sigmf-data"), datatype)
    os.makedirs(work, exist_ok=True)
    x.astype(np.complex64).tofile(os.path.join(work, "field.cf32"))
    freqs, p = psd_db(x, fs)
    channels = []
    for center, bw in find_channels(freqs, p):
        kind = classify(extract(x, fs, center, max(bw, 2000)), fs)
        channels.append({"freq_hz": round(fc + center), "offset_hz": round(center),
                         "bw_hz": round(bw), "kind": kind})
        print(f"{(fc + center) / 1e6:10.4f} MHz  offset {center:+9.0f} Hz  bw {bw:7.0f} Hz  {kind}")
    with open(os.path.join(work, "channels.json"), "w") as f:
        json.dump(channels, f, indent=2)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit(__doc__)
    main(sys.argv[1], sys.argv[2])
