#!/usr/bin/env python3
"""Milestone 6: build the intercept report.

Usage: python3 report.py PACKETS.jsonl INTERCEPT.json
Reads the framer's JSON lines and writes the report the response team acts on, plus
snapshot.png (the drone's last camera frame) in the same folder as INTERCEPT.json.
Standard library only.
"""
import json
import math
import os
import re
import struct
import sys
import zlib

TOWER = (35.2950, -116.0850)  # the Range 7 sensor tower, lat/lon in degrees
EARTH_RADIUS_KM = 6371.0


def load_packets(path):
    """Task 6.1: read one JSON object per line (skip blank lines). Return (packets, crc_failures):
    packets keeps only crc_ok frames of type "fix", "status" or "image", one per seq (the
    drone repeats some), sorted by seq. crc_failures counts the lines with crc_ok false."""
    raise NotImplementedError


def haversine_km(lat1, lon1, lat2, lon2):
    """Task 6.2: great-circle distance in km between two lat/lon points (degrees),
    Earth radius 6371 km:
        a = sin^2(dlat/2) + cos(lat1)*cos(lat2)*sin^2(dlon/2);  d = 2*R*asin(sqrt(a))"""
    raise NotImplementedError


def summarize(packets, crc_failures, tower=TOWER):
    """Task 6.3: build the report dict.
      drone        {"lat", "lon", "alt_m"} of the fix with the largest t_s (where it is now)
      home         {"lat", "lon"} of the fix with the smallest t_s (where it took off: the operator)
      max_alt_m    highest alt_m of any fix
      flight_time_s  largest t_s minus smallest t_s
      range_km     haversine from the tower to the drone, rounded to 2 decimals
      operator_id  the word after "PILOT ID " in a status text (None if there is none)
      packets      len(packets);  crc_failures  as given"""
    raise NotImplementedError


def rebuild_image(packets):
    """Task 6.4: put the drone's camera frame back together. Return (width, height, pixels).
    Each "image" packet holds one part: "part" is its number (0, 1, 2 ...), "parts" how many
    there are, "data" the bytes as hex (bytes.fromhex). Join the parts in part order (raise
    ValueError if one is missing) and zlib.decompress the result. That gives:
        u16 width | u16 height  (little-endian, struct.unpack("<HH", ...))
        then height rows of (width + 7) // 8 bytes: 1 bit per pixel, most significant bit first
    pixels is bytes of width * height values, row by row: 255 where the bit is 1 (hot), else 0."""
    raise NotImplementedError


def write_png(path, width, height, pixels):
    """Already written: save 8-bit grey pixels (bytes, row by row) as a PNG file."""
    def chunk(kind, data):
        return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data))
    rows = b"".join(b"\x00" + pixels[y * width:(y + 1) * width] for y in range(height))
    with open(path, "wb") as f:
        f.write(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 0, 0, 0, 0))
                + chunk(b"IDAT", zlib.compress(rows, 9)) + chunk(b"IEND", b""))


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit(__doc__)
    packets, crc_failures = load_packets(sys.argv[1])
    report = summarize(packets, crc_failures)
    snapshot = os.path.join(os.path.dirname(os.path.abspath(sys.argv[2])), "snapshot.png")
    write_png(snapshot, *rebuild_image(packets))
    report["snapshot"] = "snapshot.png"
    with open(sys.argv[2], "w") as f:
        json.dump(report, f, indent=2)
    d, h = report["drone"], report["home"]
    print(f"Drone at {d['lat']:.5f}, {d['lon']:.5f}, {d['alt_m']} m up, {report['range_km']} km from the tower. "
          f"Launched from {h['lat']:.5f}, {h['lon']:.5f}. Pilot ID: {report['operator_id']}")
    print(f"Camera frame rebuilt: {os.path.relpath(snapshot)}")
