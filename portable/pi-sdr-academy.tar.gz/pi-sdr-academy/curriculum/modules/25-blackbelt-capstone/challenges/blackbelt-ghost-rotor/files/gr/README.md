# Milestone 3: the GNU Radio front end

Build `rx_drone.grc` in this folder with **GNU Radio Companion** (`gnuradio-companion &`).
The front end is the first part of the receiver. It picks out the drone's signal.

| Block | Settings |
|-------|----------|
| Options | Id `rx_drone`, Generate Options **No GUI**, Run Options **Run to Completion** |
| Variable | `samp_rate` = 250000 |
| Parameter | Id `infile`, type String, default `work/field.cf32` |
| Parameter | Id `outfile`, type String, default `work/drone.cf32` |
| Parameter | Id `offset`, type Float, default: the offset of the drone downlink, from `work/channels.json` |
| File Source | complex, File `infile`, Repeat **No** |
| Frequency Xlating FIR Filter | complex in and out, Decimation 10, Center Frequency `offset`, Taps: a low-pass filter, `firdes.low_pass(1.0, samp_rate, 6000, 3000)` |
| File Sink | complex, File `outfile` |

Press **Generate** (F5). GRC writes `rx_drone.py` in the same folder as the `.grc` file.
Each Parameter block becomes a command-line option.
So the station can run the script with any file and any offset:

```bash
python3 gr/rx_drone.py --infile work/field.cf32 --outfile work/drone.cf32 --offset 62600
```

Do not add a Throttle block. The flowgraph reads a file, so it should run as fast as the CPU can.
GRC shows a warning about the missing Throttle block. Here, you can ignore that warning.

If your GNU Radio uses its own Python (radioconda, or a venv), set `GR_PYTHON` in `station.conf`.
