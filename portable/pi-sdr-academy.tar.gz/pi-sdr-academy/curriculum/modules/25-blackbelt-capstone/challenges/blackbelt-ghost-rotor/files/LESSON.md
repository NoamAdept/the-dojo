# Operation Ghost Rotor: lesson

Counter-drone (C-UAS) systems are built in the same way as this station.
Defense-tech companies such as Anduril put radars, cameras and software-defined radios (SDRs) on sensor towers.
The towers run with nobody watching them. They do 4 things:

1. they **detect** an emitter (something that sends radio signals),
2. they **identify** it,
3. they **locate** it,
4. they give that picture to a human, who decides what to do.

The RF (radio) part is the chain you will now build. It is a few small programs. Each program is good at one thing.
A shell script connects them, and the operating system starts the script.
You already know every part. What is new is putting all the parts together, with little time.

Everything here is passive: you only listen. You find, you locate, you report. Someone else decides how to respond.

## The architecture

![The station you build](media/station-pipeline.png)

| Stage | Program | Input → output | You learned it in |
|-------|---------|----------------|-------------------|
| 1 | `bin/inventory.sh` | `captures/` → CSV | White and Yellow Belts: globbing, pipes, scripts, permissions |
| 2 | `scan.py` | the USRP recording → `field.cf32`, `channels.json` | Brown Belt: the USRP, frequency domain, filters |
| 3 | `gr/rx_drone.py` | `field.cf32` → `drone.cf32` | Purple Belt: GNU Radio |
| 4 | `demod.py` | `drone.cf32` → `bits.txt` | Red Belt: pulse shaping, synchronization |
| 5 | `framer/framer` | `bits.txt` → `packets.jsonl` | Orange Belt: bytes, structs, gdb |
| 6 | `report.py` | `packets.jsonl` → `intercept.json` + `snapshot.png` | Blue Belt: files, dicts, bytes |
| 7 | `bin/station.sh` + systemd | everything, every 10 minutes | Yellow Belt: services, logs |

Every stage reads a file and writes a file. This has 2 good results:

- You can test each stage by itself. That is how `./check` grades them.
- When something goes wrong, you can look at the data between stages. Use `ls -l`, `head`, or a quick numpy plot.

## 1. Field kit

A SigMF recording is 2 files:

- `NAME.sigmf-data` holds the raw samples, with no header.
- `NAME.sigmf-meta` is JSON. It says what the samples are.

The datatype tells you the size of one complex sample:

- `ci16_le`: 4 bytes,
- `cf32_le`: 8 bytes.

So the number of samples = bytes / size.

These pieces of shell are useful:

- `for meta in "$dir"/*.sigmf-meta`
- `basename "$meta" .sigmf-meta`
- `grep '"core:datatype"' "$meta" | sed 's/.../'`
- `wc -c < file`
- `case $datatype in ... esac`
- `$((bytes / per))`
- `sort -t, -k4,4n` (split on commas, sort by number on field 4)

Print the header line before the loop. Send only the output of the loop into `sort`.

## 2. Survey the band

![The tower recording: waterfall and averaged spectrum](media/tower-spectrum.png)

- An SDR gives you complex samples, I + jQ. The USRP stores them interleaved: I, Q, I, Q
  (see the USRP chapter of PySDR).

  | Format | SigMF datatype | One value | To floats |
  |--------|----------------|-----------|-----------|
  | USRP, UHD `sc16` | `ci16_le` | int16, little-endian | `÷ 32768` |
  | USRP, UHD `fc32`, or a GNU Radio File Sink | `cf32_le` | float32 | as is |

  Read the bytes with `np.fromfile(path, dtype=...)`. The dtype is `"<i2"` or `"<f4"`.
  Scale the values. Then make pairs: `raw[0::2] + 1j * raw[1::2]`.
- 16 bits give about 96 dB of dynamic range (the gap between the weakest and the strongest signal
  the radio can record). Each bit gives about 6 dB.
- Almost every SDR leaves a **DC spike** (a false peak) at 0 Hz.
  - Direct-conversion front ends, like the AD9361 in the B210, leak a little of the local oscillator
    into the samples.

  Subtract the mean before you calculate a spectrum.
  This is also why real operators tune a little away from the signal they want.
- One FFT of noisy data is noisy. So **average** many windowed FFTs. This is Welch's method.
  It gives a steady result: the noise floor is flat, and every transmitter is easy to see.
- The median of the spectrum is a good estimate of the noise floor, because most bins hold only noise.
- To identify a channel, move it to 0 Hz and filter it out. Then ask 2 questions:
  - Is there a carrier at 0 Hz?
  - Does the envelope (the strength of the signal over time) switch on and off?

  If you **square** a BPSK signal, the ±1 data disappears (1² = (−1)² = 1).
  What is left is a pure tone at 2 times the carrier offset.
  This is the classic blind test for BPSK (see the Synchronization chapter of PySDR).

## 3. Tune in with GNU Radio

The `Frequency Xlating FIR Filter` does 3 jobs in one block:

1. It shifts the spectrum by **−center_freq**. So a center of +62.6 kHz moves the drone to 0 Hz.
2. It applies a low-pass filter.
3. It decimates (lowers the sample rate).

250 kHz / 10 = 25 kHz. At 25 kHz, a signal of 5000 baud (symbols per second) has 5 samples per symbol.

A **Parameter** block turns a value into a constructor argument and a command-line option.
This is how one flowgraph can serve the whole station: `--infile`, `--outfile`, `--offset`.
Use **No GUI** and **Run to Completion**. Then the generated script runs until the File Source has no more data,
and then it exits. A script in a pipeline must do this.
(With the default "Prompt for Exit", it would wait for Enter. Or it would stop at once when there is no terminal.)

These GNU Radio tutorials cover this stage:

- [Your First Flowgraph](/readings/gnuradio/Your_First_Flowgraph.html)
- [Hier Blocks and Parameters](/readings/gnuradio/Hier_Blocks_and_Parameters.html)
- [Frequency Shifting](/readings/gnuradio/Frequency_Shifting.html)
- [Sample Rate Change](/readings/gnuradio/Sample_Rate_Change.html)
- [Reading and Writing Binary Files](/readings/gnuradio/Reading_and_Writing_Binary_Files.html)
- [Understanding a Flowgraph's Python Code](/readings/gnuradio/Understanding_a_Flowgraph_s_Python_Code.html)

They are all saved in the academy. For a receiver made only in GNU Radio, see
[BPSK Demodulation](/readings/gnuradio/BPSK_Demodulation.html) and [Packet Communications](/readings/gnuradio/Packet_Communications.html).

## 4. Demodulate

This is the receiver from the Pulse Shaping and Synchronization chapters of PySDR. The steps, in order:

1. **Coarse frequency**: the crystal in the drone's radio is a few hundred Hz off.
   Also, your tuning was only as exact as one FFT bin. So do this:
   square the signal, take the FFT, and find the peak.
   Divide its frequency by 2. Then mix (shift) that frequency away.
2. **Matched filter**: the transmitter shaped each symbol with a root-raised cosine (RRC) filter (β = 0.35).
   Use the same filter at the receiver. This gives the best SNR (signal-to-noise ratio).
   Also, RRC × RRC = raised cosine.
   A raised cosine has zero inter-symbol interference (symbols do not leak into each other).
3. **Timing**: there are exactly 5 samples per symbol, and the clock does not drift.
   So choose the 1 sampling phase (out of 5) with the most energy. It falls on the peak of the eye diagram.
4. **Costas loop** (a feedback loop that follows the carrier): it tracks the phase and frequency error that is left. For BPSK the error is `I × Q`.
   Normalise the symbols first (make their size about 1). The loop gains expect |s| ≈ 1.
5. **Decide**: if the real part is > 0, the bit is 1.

A Costas loop has a 180° ambiguity. It can lock with every bit inverted (0 and 1 swapped). You do not fix that here.
The framer looks for the sync word and also for its inverse.

## 5. Decode the frames

```text
| preamble AA AA AA AA | sync 2D D4 | len | payload (len bytes) | CRC-16, big-endian |
payload type 1 (fix):    u8 type | u16 seq | u32 t_s | i32 lat×1e7 | i32 lon×1e7 | u16 alt_m | i16 temp×10 | u16 batt_mV
payload type 2 (status): u8 type | u16 seq | ASCII text
payload type 3 (image):  u8 type | u16 seq | u8 part | u8 parts | data bytes
```

The bits are sent most significant bit first.
The numbers inside the payload are **little-endian** (lowest byte first). The ARM chip in the flight controller
stores them that way. But the CRC is sent big-endian (highest byte first).

A **CRC** is a checksum. Here it is CRC-16/CCITT-FALSE. The receiver calculates it again.
If the 2 values are different, the frame has bit errors. Then the frame is dropped,
and the search continues 1 bit later.

**gdb, for the crash.** The Makefile builds with `-g -O0` (debug information, no optimisation). So you can do this:

```bash
cd framer
gdb --args ./framer ../work/bits.txt
(gdb) run            # it stops at the SIGSEGV
(gdb) bt             # where are we?
(gdb) info locals    # what was it decoding? look at type, seq, h
(gdb) print *h       # why does this line crash?
```

Then fix the code, so a packet of an unexpected type cannot crash it.
A receiver on a sensor tower must survive any input. Anyone can transmit anything on 915 MHz.
That includes an adversary (an enemy) who knows your decoder and wants to blind it.
(Orange Belt: *Locate and Fix a Segmentation Fault*.)

## 6. Intercept report

The drone keeps its recent track in a rolling buffer (a memory that keeps only the newest points).
It sends this buffer again and again. So the data survives dropouts (short losses of signal).
But this means packets arrive out of order. Some arrive twice. Some arrive damaged.
Keep each good packet once, and sort them by `seq`. Then find these values:

- **drone**: the fix (GPS position) with the **latest time**. Do not just use the last line you received.
  This is where the drone is now.
- **home**: the fix with the **earliest time**. Small drones save their take-off point as "home".
  They use it for return-to-home. The operator usually stands right there.
  In real counter-drone work, this is often the most valuable thing the downlink tells you.
- **range_km**: the distance from the tower to the drone. Use the haversine great-circle distance
  on a sphere of radius 6371 km.
- **operator_id**: the word after `PILOT ID` in the status text.

**The camera frame.** A whole picture does not fit in one packet. So the drone cuts it into parts.
Each image packet says which part it is (`part`). It also says how many parts there are (`parts`).
The framer prints the data as hex. To rebuild the picture:

1. Collect one copy of each part. Join them in part order: `b"".join(...)`.
2. The result is compressed (made smaller). Use `zlib.decompress` on it.
3. The first 4 bytes are the width and height: `struct.unpack("<HH", raw[:4])`.
4. After that come the rows. Each pixel is 1 bit. The most significant bit (the highest bit) comes first.
   So a row of 160 pixels is 20 bytes.
   A 1 is hot (white, 255). A 0 is cold (black, 0).
5. `write_png` is already in `report.py`. It saves the pixels as a PNG file that you can open.

Real radio links move pictures in the same way. They split the picture, number the parts, and send them.
On the ground, they put the parts back together.
If 1 part is missing, the picture is broken. So `rebuild_image` raises an error. It does not guess.

## 7. Run the station

- `set -euo pipefail` does 3 things:
  - it stops the script at the first command that fails,
  - it treats unset variables as errors,
  - it makes a pipeline fail if any part of it fails (so `... | tee log` does not hide a crash).
- `cd "$(dirname "$0")/.."` makes the script work from any folder, including the folder systemd uses.
- `. ./station.conf` loads the settings. In that file, `${NAME:-default}` lets the environment change them.
- `{ ...; } 2>&1 | tee "$LOG_DIR/station-$(date +%Y%m%d-%H%M%S).log"` shows the output and also saves a copy.
- A **oneshot** service runs until it finishes, each time it is started. A **timer** starts it on a schedule.
  These commands show how it is doing: `systemctl list-timers`, `systemctl status rotor-watch` and
  `journalctl -u rotor-watch`. (Yellow Belt: *Services, Ports and Logs*.)

## New words

- **Counter-drone (C-UAS)**: systems that find and track drones (UAS = unmanned aircraft system).
- **Emitter**: anything that sends radio signals.
- **Passive**: you only receive. You never transmit.
- **SigMF**: a standard file format for radio recordings: a data file plus a JSON meta file.
- **Dynamic range**: the gap between the weakest and the strongest signal a radio can record at the same time.
- **DC spike**: a false peak at 0 Hz, made by the radio itself.
- **Welch's method**: averaging many windowed FFTs to get a smooth spectrum.
- **Envelope**: the strength of a signal over time.
- **Baud**: symbols per second.
- **Decimate**: keep only some of the samples, to lower the sample rate.
- **Matched filter**: a receive filter with the same shape as the transmit pulse. It gives the best SNR.
- **Costas loop**: a feedback loop that locks to the phase and frequency of the carrier.
- **Inter-symbol interference (ISI)**: when one symbol leaks into the next one.
- **Eye diagram**: a plot of many symbols on top of each other. The best sampling time is where the "eye" is most open.
- **Little-endian / big-endian**: the order of bytes in a number. Little-endian puts the lowest byte first.
- **CRC**: a checksum that finds bit errors.
- **Haversine distance**: a formula for the distance between 2 points on a sphere.
- **oneshot service**: a systemd service that runs once and then exits.
- **Timer**: a systemd unit that starts a service on a schedule.

## Going further

- Plot the track on a map with the tower, the drone and the home point. Also plot altitude against time.
- Add a bearing (direction) from the tower to the home point to the report. Use the initial great-circle bearing.
- Make the picture bigger. Scale each pixel up 4x before you save it. Or draw the track on top of it.
- With a real USRP, replace the File Source with a **UHD: USRP Source** block.
  Then decode your own 915 MHz test beacon, sent from a second USRP. Transmit only as your local ISM-band rules allow.
  Never transmit on someone else's link.
- Rebuild stages 4 and 5 inside GNU Radio. Use the Symbol Sync, Costas Loop and Correlate Access Code blocks.

## Offline help

- systemd timers: `man systemd.timer`, `man systemd.service`
