#!/usr/bin/env python3
"""Milestone 4: demodulate the drone downlink (BPSK).

Usage: python3 demod.py BALLOON.cf32 BITS.txt
The input is the GNU Radio output: complex64 at 25 kHz, 5000 baud BPSK, so 5 samples per symbol.
Writes the bits as one line of '0' and '1' characters. numpy only.
"""
import sys

import numpy as np

FS = 25_000
SPS = 5
BETA = 0.35


def rrc_taps(sps, beta, span):
    """Task 4.1: root-raised-cosine taps, span*sps + 1 of them, normalised to unit energy.
    t = np.arange(-span*sps//2, span*sps//2 + 1) / sps (time in symbols). For each t:
      t == 0:              1 + beta*(4/pi - 1)
      |t| == 1/(4*beta):   beta/sqrt(2) * ((1 + 2/pi)*sin(pi/(4*beta)) + (1 - 2/pi)*cos(pi/(4*beta)))
      otherwise:           (sin(pi*t*(1-beta)) + 4*beta*t*cos(pi*t*(1+beta))) / (pi*t*(1 - (4*beta*t)**2))
    Then divide by sqrt(sum(h**2))."""
    raise NotImplementedError


def coarse_cfo(x, fs):
    """Task 4.2: carrier offset in Hz by squaring. x**2 turns +-1 BPSK into a pure tone at
    twice the offset. Take |np.fft.fft(x**2, 2**17)|, find the peak on np.fft.fftfreq(2**17, 1/fs)
    and divide by 2."""
    raise NotImplementedError


def symbol_sync(y, sps):
    """Task 4.3: y is matched-filtered. Pick the offset o in range(sps) with the largest
    mean(|y[o::sps]|**2) and return y[o::sps] (one sample per symbol)."""
    raise NotImplementedError


def costas(s, alpha=0.132, beta=0.00932):
    """Task 4.4: BPSK Costas loop, one sample per symbol (PySDR chapter 17). phase = freq = 0, then:
        out[i] = s[i] * exp(-1j*phase)
        error  = out[i].real * out[i].imag
        freq  += beta * error
        phase += freq + alpha * error
    Return out (complex array, same length)."""
    raise NotImplementedError


def demodulate(x, fs=FS, sps=SPS):
    """Task 4.5: the whole receiver. Return a str of '0'/'1' (1 when the real part > 0).
      1. remove the coarse offset: x * exp(-2j*pi*coarse_cfo(x, fs)*n/fs)
      2. matched filter: np.convolve(x, rrc_taps(sps, 0.35, 8), "same")
      3. symbol_sync
      4. normalise to unit RMS (the Costas gains assume |s| is about 1)
      5. costas, then decide."""
    raise NotImplementedError


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit(__doc__)
    bits = demodulate(np.fromfile(sys.argv[1], dtype=np.complex64))
    with open(sys.argv[2], "w") as f:
        f.write(bits + "\n")
    print(f"{len(bits)} bits -> {sys.argv[2]}")
