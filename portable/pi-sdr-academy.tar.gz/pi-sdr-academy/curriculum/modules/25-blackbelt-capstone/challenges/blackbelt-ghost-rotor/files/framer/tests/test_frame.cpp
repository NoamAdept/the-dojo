// Unit tests for frame.h. Run: make test
#include "frame.h"

#include <cstdio>
#include <cstring>

static int fails = 0;
#define EXPECT(cond, what)                                   \
    do {                                                     \
        if (!(cond)) {                                       \
            std::printf("FAIL %s\n", what);                  \
            ++fails;                                         \
        }                                                    \
    } while (0)

int main() {
    const char* nine = "123456789";
    EXPECT(crc16_ccitt(reinterpret_cast<const uint8_t*>(nine), 9) == 0x29B1, "5.1 crc16_ccitt(\"123456789\") == 0x29B1");
    EXPECT(crc16_ccitt(nullptr, 0) == 0xFFFF, "5.1 crc16_ccitt of nothing == 0xFFFF");
    const uint8_t one[] = {0x15};
    EXPECT(crc16_ccitt(one, 1) == 0xA364, "5.1 crc16_ccitt({0x15}) == 0xA364");

    const uint8_t le[] = {0x34, 0x12, 0x78, 0x56, 0xF6, 0xFF, 0xFF, 0xFF};
    EXPECT(get_le16(le) == 0x1234, "5.2 get_le16({0x34, 0x12}) == 0x1234");
    EXPECT(get_le32(le) == 0x56781234u, "5.2 get_le32 == 0x56781234");
    EXPECT(static_cast<int32_t>(get_le32(le + 4)) == -10, "5.2 get_le32 of F6 FF FF FF as int32 == -10");

    auto b = pack_bits("0010110111010100", 0, 2, false);
    EXPECT(b.size() == 2 && b[0] == 0x2D && b[1] == 0xD4, "5.3 pack_bits MSB first");
    auto c = pack_bits("xx1101001000101011", 2, 2, true);
    EXPECT(c.size() == 2 && c[0] == 0x2D && c[1] == 0xD4, "5.3 pack_bits with start and invert");
    EXPECT(pack_bits("0101", 0, 1, false).empty(), "5.3 pack_bits returns empty when bits run out");

    bool inv = true;
    EXPECT(find_sync("1010101000101101110101001111", 0, inv) == 24 && !inv, "5.4 find_sync finds 0x2DD4");
    inv = false;
    EXPECT(find_sync("01011101001000101011", 0, inv) == 20 && inv, "5.4 find_sync finds the inverted word");
    EXPECT(find_sync("0010110111010100" "00" "0010110111010100", 1, inv) == 34, "5.4 find_sync starts at from");
    EXPECT(find_sync("0101010101010101", 0, inv) == -1, "5.4 find_sync returns -1 when there is no sync");

    if (fails) return 1;
    std::printf("all frame.h tests pass\n");
    return 0;
}
