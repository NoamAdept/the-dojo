# Black Belt: Operation Ghost Rotor

![Range 7 at 21:47: the radar track fades north-west of Sentry Tower 3](media/situation-map.png)

**Mission brief.** You are the RF (radio) engineer on the counter-drone team at Range 7.
Range 7 is a desert test range. A company called Bastion Dynamics runs it.
At 21:47 the radar on Sentry Tower 3 (35.2950 N, 116.0850 W) saw a small quadcopter.
It was flying low and coming from the north-west.
It had no transponder (a radio that says who it is) and no flight plan.
Then it dropped below the radar horizon, so the radar lost it.
But first, the tower's radios recorded 2.25 seconds of its 915 MHz downlink.
(The downlink is the radio link from the drone to the ground.)

**The radio.** The tower's SDR (software-defined radio) is an Ettus USRP B210, the same radio as in the PySDR belts.
It saved the 2.25 s as `captures/tower_915M_usrp.sigmf-*`: `ci16_le`, 16-bit signed I, Q.
`station.conf` already points at it.

The drone's radio sends 3 things:

- its recent GPS track
- a status message
- the last frame from its thermal camera, cut into small packets

Decode them. Then the response team knows 3 things:
**where the drone is now, where it took off (that is where its operator stands), and
who is flying it.**
Then put the camera frame back together. That picture is your final product.
It shows the launch point from the air.

The tower has no network. There is no cloud, and there is nobody to call.
You have the recording, the tools you learned on every belt, and `./check`.

You will build the station that turns the recording into an intercept report and a picture.
Then you will make the station run by itself:

![The station you build](media/station-pipeline.png)

```text
captures/*.sigmf  →  scan.py  →  gr/rx_drone.py  →  demod.py  →  framer (C++)  →  report.py  →  intercept.json
                                                                                          + snapshot.png
   (shell)          (Python)     (GNU Radio)        (DSP)       (C++, gdb)       (Python)
                          all of it run by bin/station.sh under systemd (Linux)
```

Work in vim. Keep a tmux pane open for `./check`.
If you like, save your work with git as you go (`git init` here works).

## The milestones

`./check` grades all 7 milestones. `./check 4` grades only milestone 4.
The mission is complete when `./check` prints `CHECK_OK`.

**1. Field kit (shell).**

- Use `chmod` to make the scripts in `bin/` executable.
- Then write `bin/inventory.sh DIR`. It prints a CSV of every SigMF recording in `DIR`.
  Each line has: name, datatype, sample rate, frequency, samples.
  Sort the lines by frequency.
- The tower's USRP saves recordings in 2 formats: `ci16_le` (16-bit) and `cf32_le` (32-bit float).
- The comment at the top of the script shows the exact format.
- Use only shell: grep, sed, wc, sort.

**2. Survey the band (Python, PySDR).** Fill in `scan.py`. It must:

- read the USRP's samples (`ci16_le` or `cf32_le`),
- calculate an averaged spectrum,
- find every channel that has a signal in it,
- say what each channel is: a carrier, an on/off keyed sensor, or BPSK.

Then run it on the tower's recording:
`python3 scan.py captures/tower_915M_usrp.sigmf-meta work`.
It writes `work/field.cf32` and `work/channels.json`.
Which channel is the drone?

![The tower recording: three emitters, one of them the drone](media/tower-spectrum.png)

**3. Tune in (GNU Radio).** In GNU Radio Companion, build `gr/rx_drone.grc`. It has 3 parts, in order:

1. a file source,
2. a frequency-xlating FIR filter. It tunes to the drone, applies a low-pass filter,
   and decimates (lowers the sample rate) from 250 kHz to 25 kHz,
3. a file sink.

Add `infile`, `outfile` and `offset` as Parameter blocks.
Generate the flowgraph to `gr/rx_drone.py` and run it.
`gr/README.md` lists the blocks.

**4. Demodulate (DSP).** Fill in `demod.py`. It does these steps, in order:

1. coarse frequency correction by squaring,
2. an RRC matched filter,
3. symbol timing,
4. a Costas loop,
5. decisions (choose 0 or 1 for each symbol).

Run `python3 demod.py work/drone.cf32 work/bits.txt`.

**5. Decode the frames (C++, gdb).** `framer/` is a C++ decoder. The team before you wrote it.

- Finish the helpers in `framer/frame.h`: CRC-16, little-endian reads, bit packing, and sync search.
  Work until `make -C framer test` passes.
- Then run `./framer/framer work/bits.txt`. It crashes.
  Something in the downlink is not what the old code expected.
- Use **gdb** to find out why.
- Write the `seq` of the packet that it crashed on into `framer/crash_seq.txt`.
- Fix `framer.cpp`, so that no packet from any transmitter can crash it.

**6. Intercept report (Python).** Fill in `report.py`. It must:

- drop bad frames and repeated frames,
- put the track in order,
- calculate where the drone is, where it took off, and how far it is from the tower,
- find the pilot ID.

**6. Intercept report and camera frame (Python).** Fill in `report.py`.

- Drop bad frames and repeated frames. Put the track in order.
- Calculate where the drone is, where it took off, how far it is from the tower, and the pilot ID.
- Then join the image packets, unpack the pixels, and save the picture.
Run `./framer/framer work/bits.txt > work/packets.jsonl && python3 report.py work/packets.jsonl work/intercept.json`.
It writes `work/intercept.json` and `work/snapshot.png`. Open the PNG: what did the drone see?

**7. Run the station (bash, systemd).**

- Write `bin/station.sh`. One command must run the whole chain.
  It must also write a log, and it must fail clearly when something goes wrong.
- Then fill in `deploy/rotor-watch.service` and `deploy/rotor-watch.timer`.
  With them, the tower runs the chain again every 10 minutes, with nobody at the keyboard.

## Rules of engagement

- Everything runs offline. The Python stages need only numpy. The framer needs only g++ and make.
- GNU Radio must be installed (`sudo apt install gnuradio`, or radioconda on a Mac).
  If GNU Radio uses its own Python, set `GR_PYTHON` in `station.conf`.
  You do not need a radio. The recording takes the place of the radio.
- Do not hard-code answers (do not write the expected results into your code). The checker also runs your code on other data.
- Stuck? `LESSON.md` explains every milestone. It also says which earlier belt taught each part. The hints are in the app.

*Bastion Dynamics, Range 7 and the drone are not real. The equipment and the methods are real.*
