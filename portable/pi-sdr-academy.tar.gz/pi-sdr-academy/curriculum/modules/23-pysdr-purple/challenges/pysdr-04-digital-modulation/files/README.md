# Ch 4: The Spinning Constellation

*Range 7, mission 4 of 15. Brown belt.*

## The story so far

You are the new radio engineer at Bastion Dynamics, a made-up company that builds systems to spot and track drones. Its desert test range is called Range 7. On the range stands Sentry Tower 3, which listens to the sky with a USRP radio. In this belt you get the tower's radio working, using Bastion's own test drones and beacons.

## This mission

The tower's data link uses QPSK, where each symbol carries 2 bits. The receiver locked on with an unknown quarter turn, so every symbol is rotated. Every link starts with the word BDYN, then sends a picture.

**Your goal:** Rebuild the picture on the tower's data link.

**How the chapter helps:** Chapter 4 shows how QPSK maps bits to points, so you can read the bits back from the points.

## What you do

### 1. Read the chapter

[PySDR Chapter 4 (Digital Modulation)](/readings/pysdr/digital_modulation.html), saved in the academy. In the app, open **Lesson** and click the link.

Then take the **Quiz** tab to check you understood the chapter. Retry as often as you like.

### 2. Write two small functions in `tasks.py`

Open `tasks.py` with `vim tasks.py`. The comment in each function says exactly what to return.

1. **Bits to QPSK points**: `qpsk_map(bits)`.
2. **QPSK points to bits**: `qpsk_demap(symbols)`.

Run `./check` after each one. It tests your function and tells you what is still wrong.

### 3. Run the mission

`mission.py` is already written. It uses your two functions on the real recording:

```bash
python3 mission.py
```

It prints the picture and saves it as **`picture.png`**. Open `picture.png` to see it.
Read `mission.py` to see how your functions are used: look for the comments that say `your Task`.

### 4. Check your work

Run `./check`. It runs `mission.py` and checks `picture.png`. When it prints `CHECK_OK`, press **Done** in the dojo.

## What you get

- `evidence/symbols.npy`: noisy QPSK symbols, one per point.
- `evidence/intel.json`: the preamble text.

## About the pictures

Every radio link at Range 7 carries a small black-and-white picture. `mission.py` turns the bits into that picture and saves it as `picture.png`. If the picture looks right, your functions work. (The format: 8 bits of width, 8 bits of height, then the pixels row by row, 1 = lit.)
