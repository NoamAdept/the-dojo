# Ch 4: Digital Modulation: lesson

This challenge follows **PySDR Chapter 4: Digital Modulation**. Read it first: [PySDR Chapter 4: Digital Modulation](/readings/pysdr/digital_modulation.html). It is saved in the academy and opens in a new tab.

When you have read it, take the **Quiz** tab. You can retry every question as often as you like, and each answer tells you why it is right or wrong.

## Key ideas

- Digital modulation maps bits onto **symbols**: points in the IQ plane (the constellation).
- **BPSK** sends 1 bit per symbol: +1 or -1. **QPSK** sends 2 bits per symbol: one on I, one on Q,
  scaled by `1/sqrt(2)` so every symbol has power 1.
- A receiver makes **hard decisions** by checking which side of each axis a noisy symbol falls on.

## What you will build

1. Bits to QPSK points: `qpsk_map(bits)`
2. QPSK points to bits: `qpsk_demap(symbols)`

Then `python3 mission.py` uses them on the recording and saves the picture as `picture.png`.

## The mission at a glance

![Mission 4: The Spinning Constellation](media/mission.png)

Every link at Range 7 carries a picture in the same format:

![The Range 7 picture format](media/picture-format.png)

## Credit

PySDR by Marc Lichtman is licensed CC BY-NC-SA 4.0. The academy keeps an offline copy of the chapter. This challenge is original material written to follow it.
