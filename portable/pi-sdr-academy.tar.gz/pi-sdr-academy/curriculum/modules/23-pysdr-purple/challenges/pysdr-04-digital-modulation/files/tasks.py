"""PySDR chapter 4: Digital Modulation. numpy only. Fill in the two functions."""
import numpy as np


def qpsk_map(bits):
    """Task 1: bits has even length. Each pair (b0, b1) becomes one complex symbol:
    ((1 - 2*b0) + 1j*(1 - 2*b1)) / sqrt(2). Return a complex array."""
    raise NotImplementedError


def qpsk_demap(symbols):
    """Task 2: the other way. For each symbol: b0 = 1 if real < 0 else 0, b1 = 1 if imag < 0 else 0.
    Return all the bits in order (b0, b1, b0, b1, ...) as an int array."""
    raise NotImplementedError
