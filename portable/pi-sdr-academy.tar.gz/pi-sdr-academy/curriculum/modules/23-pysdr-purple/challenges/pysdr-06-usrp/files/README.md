# Ch 6: Hop by Hop

*Range 7, mission 5 of 15. Brown belt.*

## The story so far

You are the new radio engineer at Bastion Dynamics, a made-up company that builds systems to spot and track drones. Its desert test range is called Range 7. On the range stands Sentry Tower 3, which listens to the sky with a USRP radio. In this belt you get the tower's radio working, using Bastion's own test drones and beacons.

## This mission

Bastion's fixed-wing drone hops between 16 radio channels near 915 MHz. The channel of each hop carries 4 bits. Sentry Tower 3's USRP recorded the hops as raw 16-bit numbers (sc16), the format the USRP sends over USB.

**Your goal:** Rebuild the picture the fixed-wing drone sends.

**How the chapter helps:** Chapter 6 shows how a USRP hands you samples, and that a baseband frequency is really an RF frequency next to the centre frequency.

## What you do

### 1. Read the chapter

[PySDR Chapter 6 (USRP in Python)](/readings/pysdr/usrp.html), saved in the academy. In the app, open **Lesson** and click the link.

Then take the **Quiz** tab to check you understood the chapter. Retry as often as you like.

### 2. Write two small functions in `tasks.py`

Open `tasks.py` with `vim tasks.py`. The comment in each function says exactly what to return.

1. **Raw USRP samples to complex**: `sc16_to_complex(raw)`.
2. **RF frequency of the strongest signal**: `strongest_rf_freq(x, fs, center_freq)`.

Run `./check` after each one. It tests your function and tells you what is still wrong.

### 3. Run the mission

`mission.py` is already written. It uses your two functions on the real recording:

```bash
python3 mission.py
```

It prints the picture and saves it as **`picture.png`**. Open `picture.png` to see it.
Read `mission.py` to see how your functions are used: look for the comments that say `your Task`.

### 4. Check your work

Run `./check`. It runs `mission.py` and checks `picture.png`. When it prints `CHECK_OK`, press **Done** in the dojo.

## What you get

- `evidence/hops.sc16`: raw little-endian int16 I/Q from the USRP, every hop back to back.
- `evidence/hops.json`: sample rate, centre frequency, samples per hop and the channel plan.

## About the pictures

Every radio link at Range 7 carries a small black-and-white picture. `mission.py` turns the bits into that picture and saves it as `picture.png`. If the picture looks right, your functions work. (The format: 8 bits of width, 8 bits of height, then the pixels row by row, 1 = lit.)
