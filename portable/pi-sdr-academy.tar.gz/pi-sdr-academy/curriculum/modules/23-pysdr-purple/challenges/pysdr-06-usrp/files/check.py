#!/usr/bin/env python3
"""Run with ./check. Tests your two functions in tasks.py, then runs mission.py and checks picture.png."""
import contextlib
import hashlib
import io
import os
import struct
import sys
import zlib

sys.path.insert(0, ".")
sys.dont_write_bytecode = True
failed, passed = [], []


def task(name):
    def run(fn):
        try:
            fn()
            passed.append(name)
        except NotImplementedError:
            failed.append(f"{name}: not implemented yet")
        except Exception as exc:  # show the learner what broke
            failed.append(f"{name}: {type(exc).__name__}: {exc}")
        return fn
    return run


import numpy as np
import tasks

rng = np.random.default_rng(6)


@task("1 sc16_to_complex")
def _():
    raw = np.array([32767, -32768, 0, 16384, -16384, 0], "<i2").tobytes()
    x = np.asarray(tasks.sc16_to_complex(raw))
    assert x.dtype == np.complex64, f"return complex64, got {x.dtype}"
    assert np.allclose(x, [32767 / 32768 - 1j, 0.5j, -0.5]), f"got {x}"


@task("2 strongest_rf_freq")
def _():
    fs, fc, n = 1e6, 100e6, np.arange(8192)
    x = np.exp(2j * np.pi * -153e3 * n / fs) + 0.2 * (rng.standard_normal(8192) + 1j * rng.standard_normal(8192))
    got = float(tasks.strongest_rf_freq(x, fs, fc))
    assert abs(got - (fc - 153e3)) <= fs / 8192, f"expected about {fc - 153e3:.0f} Hz, got {got:.0f}"


# ---- Mission: Range 7 -------------------------------------------------------
ANSWER_SHA = "1f26c61a92384b08060293b8e3f42c511ff2cb7aa389c7a516ef30c6b6737758"
dossier = []


def _sha(answer):
    return hashlib.sha256(" ".join(str(answer).upper().split()).encode()).hexdigest()


def _bitmap_key(bm):
    return "|".join("".join(str(int(v)) for v in row) for row in np.asarray(bm))


def _read_png(path, scale=8):
    """Read back the PNG that mission.py's save_png wrote: 8-bit grey, one square per pixel."""
    with open(path, "rb") as f:
        data = f.read()
    assert data[:8] == b"\x89PNG\r\n\x1a\n", f"{path} is not a PNG file"
    pos, idat, w, h = 8, b"", 0, 0
    while pos + 8 <= len(data):
        n, kind = struct.unpack(">I4s", data[pos:pos + 8])
        body = data[pos + 8:pos + 8 + n]
        if kind == b"IHDR":
            w, h = struct.unpack(">II", body[:8])
        elif kind == b"IDAT":
            idat += body
        pos += 12 + n
    px = np.frombuffer(zlib.decompress(idat), np.uint8).reshape(h, w + 1)[:, 1:]
    return (px[scale // 2::scale, scale // 2::scale] > 127).astype(int)


def _show(bm):
    return "\n".join("    " + "".join("#" if v else " " for v in row) for row in np.asarray(bm))


def _run_mission():
    """Run mission.py like `python3 mission.py` does, then read the picture.png it saved."""
    import mission
    if os.path.exists("picture.png"):
        os.remove("picture.png")
    with contextlib.redirect_stdout(io.StringIO()):
        mission.main()
    assert os.path.exists("picture.png"), "mission.py did not save picture.png"
    img = _read_png("picture.png")
    assert _sha(_bitmap_key(img)) == ANSWER_SHA, (
        "picture.png is not the right picture yet. Run python3 mission.py and look at it: "
        "a function that passes its own test but returns the wrong type or shape can still break the mission")
    return mission, img


def _closed(num, title, body):
    bar = "=" * 64
    dossier.append(f"\n{bar}\n  MISSION {num} CLOSED: {title}\n{bar}\n{body}\n  Saved: picture.png\n")

@task("3 MISSION: run mission.py and save picture.png")
def _():
    mission, img = _run_mission()
    _closed("5", "Hop by Hop", _show(img) + "\n" + "  The fixed-wing link is up.")


print(f"{len(passed)}/{len(passed) + len(failed)} tasks pass")
for page in dossier:
    print(page)
if failed:
    print("Not yet:")
    for line in failed:
        print("  -", line)
    raise SystemExit(1)
print("CHECK_OK")
