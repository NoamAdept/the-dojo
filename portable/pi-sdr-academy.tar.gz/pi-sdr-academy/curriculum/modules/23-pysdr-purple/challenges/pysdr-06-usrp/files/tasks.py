"""PySDR chapter 6: USRP in Python. numpy only. Fill in the two functions."""
import numpy as np


def sc16_to_complex(raw):
    """Task 1: raw is bytes of interleaved little-endian int16: I, Q, I, Q, ...
    Return complex64 samples (I + 1j*Q) / 32768. np.frombuffer(raw, "<i2") reads the numbers."""
    raise NotImplementedError


def strongest_rf_freq(x, fs, center_freq):
    """Task 2: find the strongest bin of np.abs(np.fft.fftshift(np.fft.fft(x))). Its baseband frequency
    comes from np.fft.fftshift(np.fft.fftfreq(len(x), 1/fs)). Return center_freq + that frequency."""
    raise NotImplementedError
