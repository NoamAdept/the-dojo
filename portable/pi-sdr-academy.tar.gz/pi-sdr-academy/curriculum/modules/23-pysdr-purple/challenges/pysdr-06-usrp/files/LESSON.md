# Ch 6: USRP in Python: lesson

This challenge follows **PySDR Chapter 6: USRP in Python**. Read it first: [PySDR Chapter 6: USRP in Python](/readings/pysdr/usrp.html). It is saved in the academy and opens in a new tab.

When you have read it, take the **Quiz** tab. You can retry every question as often as you like, and each answer tells you why it is right or wrong.

## Key ideas

- UHD's Python API (`import uhd`) gives you `complex64` samples. On the wire the USRP sends
  **sc16**: interleaved signed 16-bit I and Q, where 32768 means full scale.
- Bin `k` of a baseband capture is really at RF frequency `center_freq + baseband_freq`.

**No radio needed.** The recording is simulated in exactly the format the USRP's driver produces,
so you can do the whole challenge on a laptop or Pi.

If you own a USRP, this is how the chapter talks to it:

```python
import uhd
usrp = uhd.usrp.MultiUSRP()
x = usrp.recv_num_samps(10000, 100e6, 1e6, [0], 50)  # num_samps, center_freq, sample_rate, channels, gain
```

## What you will build

1. Raw USRP samples to complex: `sc16_to_complex(raw)`
2. RF frequency of the strongest signal: `strongest_rf_freq(x, fs, center_freq)`

Then `python3 mission.py` uses them on the recording and saves the picture as `picture.png`.

## The mission at a glance

![Mission 5: Hop by Hop](media/mission.png)

Every link at Range 7 carries a picture in the same format:

![The Range 7 picture format](media/picture-format.png)

## Credit

PySDR by Marc Lichtman is licensed CC BY-NC-SA 4.0. The academy keeps an offline copy of the chapter. This challenge is original material written to follow it.
