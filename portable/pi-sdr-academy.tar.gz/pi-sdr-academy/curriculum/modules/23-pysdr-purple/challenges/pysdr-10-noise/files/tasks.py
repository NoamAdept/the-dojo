"""PySDR chapter 10: Noise and dB. numpy only. Fill in the two functions."""
import numpy as np


def snr_db(signal, noise):
    """Task 1: return 10*log10(mean(|signal|**2) / mean(|noise|**2)) as a float."""
    raise NotImplementedError


def average_frames(x, repeats):
    """Task 2: x holds `repeats` copies of the same frame, back to back. Return the average frame:
    x.reshape(repeats, -1).mean(axis=0)."""
    raise NotImplementedError
