#!/usr/bin/env python3
"""Run with ./check. Tests your two functions in tasks.py, then runs mission.py and checks picture.png."""
import contextlib
import hashlib
import io
import os
import struct
import sys
import zlib

sys.path.insert(0, ".")
sys.dont_write_bytecode = True
failed, passed = [], []


def task(name):
    def run(fn):
        try:
            fn()
            passed.append(name)
        except NotImplementedError:
            failed.append(f"{name}: not implemented yet")
        except Exception as exc:  # show the learner what broke
            failed.append(f"{name}: {type(exc).__name__}: {exc}")
        return fn
    return run


import numpy as np
import tasks

rng = np.random.default_rng(10)


@task("1 snr_db")
def _():
    s = 2.0 * np.exp(2j * np.pi * 0.1 * np.arange(10000))
    n = 0.2 * (rng.standard_normal(10000) + 1j * rng.standard_normal(10000))
    want = 10 * np.log10(np.mean(np.abs(s) ** 2) / np.mean(np.abs(n) ** 2))
    assert abs(float(tasks.snr_db(s, n)) - want) < 1e-9, f"expected {want:.3f} dB"


@task("2 average_frames")
def _():
    frame = np.exp(1j * rng.uniform(0, 6, 50))
    x = np.tile(frame, 40) + (rng.standard_normal(2000) + 1j * rng.standard_normal(2000))
    avg = np.asarray(tasks.average_frames(x, 40))
    assert avg.shape == (50,), f"one frame of 50 samples, got {avg.shape}"
    assert np.allclose(avg, x.reshape(40, 50).mean(axis=0)), "average the 40 copies sample by sample"


# ---- Mission: Range 7 -------------------------------------------------------
ANSWER_SHA = "5a578054db9cbf032ab500fe9c6e59359491fe5e30af18e4a41bba18a03cf8d6"
dossier = []


def _sha(answer):
    return hashlib.sha256(" ".join(str(answer).upper().split()).encode()).hexdigest()


def _bitmap_key(bm):
    return "|".join("".join(str(int(v)) for v in row) for row in np.asarray(bm))


def _read_png(path, scale=8):
    """Read back the PNG that mission.py's save_png wrote: 8-bit grey, one square per pixel."""
    with open(path, "rb") as f:
        data = f.read()
    assert data[:8] == b"\x89PNG\r\n\x1a\n", f"{path} is not a PNG file"
    pos, idat, w, h = 8, b"", 0, 0
    while pos + 8 <= len(data):
        n, kind = struct.unpack(">I4s", data[pos:pos + 8])
        body = data[pos + 8:pos + 8 + n]
        if kind == b"IHDR":
            w, h = struct.unpack(">II", body[:8])
        elif kind == b"IDAT":
            idat += body
        pos += 12 + n
    px = np.frombuffer(zlib.decompress(idat), np.uint8).reshape(h, w + 1)[:, 1:]
    return (px[scale // 2::scale, scale // 2::scale] > 127).astype(int)


def _show(bm):
    return "\n".join("    " + "".join("#" if v else " " for v in row) for row in np.asarray(bm))


def _run_mission():
    """Run mission.py like `python3 mission.py` does, then read the picture.png it saved."""
    import mission
    if os.path.exists("picture.png"):
        os.remove("picture.png")
    with contextlib.redirect_stdout(io.StringIO()):
        mission.main()
    assert os.path.exists("picture.png"), "mission.py did not save picture.png"
    img = _read_png("picture.png")
    assert _sha(_bitmap_key(img)) == ANSWER_SHA, (
        "picture.png is not the right picture yet. Run python3 mission.py and look at it: "
        "a function that passes its own test but returns the wrong type or shape can still break the mission")
    return mission, img


def _closed(num, title, body):
    bar = "=" * 64
    dossier.append(f"\n{bar}\n  MISSION {num} CLOSED: {title}\n{bar}\n{body}\n  Saved: picture.png\n")

@task("3 MISSION: run mission.py and save picture.png")
def _():
    mission, img = _run_mission()
    _closed("6", "Twenty Kilometres Out", _show(img) + "\n" + "  SNR of one copy: {:.1f} dB. After averaging 64: {:.1f} dB.".format(*mission.snr_gain()))


print(f"{len(passed)}/{len(passed) + len(failed)} tasks pass")
for page in dossier:
    print(page)
if failed:
    print("Not yet:")
    for line in failed:
        print("  -", line)
    raise SystemExit(1)
print("CHECK_OK")
