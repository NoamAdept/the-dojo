# Ch 10: Twenty Kilometres Out

*Range 7, mission 6 of 15. Brown belt.*

## The story so far

You are the new radio engineer at Bastion Dynamics, a made-up company that builds systems to spot and track drones. Its desert test range is called Range 7. On the range stands Sentry Tower 3, which listens to the sky with a USRP radio. In this belt you get the tower's radio working, using Bastion's own test drones and beacons.

## This mission

A drone flies 20 km away and sends its picture. The signal is weaker than the noise (about -8 dB SNR), so one copy is mostly guesses. But the drone repeats the same frame 64 times.

**Your goal:** Rebuild the picture the far-away drone sends.

**How the chapter helps:** Chapter 10 shows that noise is random, so averaging many copies keeps the signal and shrinks the noise.

## What you do

### 1. Read the chapter

[PySDR Chapter 10 (Noise and dB)](/readings/pysdr/noise.html), saved in the academy. In the app, open **Lesson** and click the link.

Then take the **Quiz** tab to check you understood the chapter. Retry as often as you like.

### 2. Write two small functions in `tasks.py`

Open `tasks.py` with `vim tasks.py`. The comment in each function says exactly what to return.

1. **SNR in dB**: `snr_db(signal, noise)`.
2. **Average the copies**: `average_frames(x, repeats)`.

Run `./check` after each one. It tests your function and tells you what is still wrong.

### 3. Run the mission

`mission.py` is already written. It uses your two functions on the real recording:

```bash
python3 mission.py
```

It prints the picture and saves it as **`picture.png`**. Open `picture.png` to see it.
Read `mission.py` to see how your functions are used: look for the comments that say `your Task`.

### 4. Check your work

Run `./check`. It runs `mission.py` and checks `picture.png`. When it prints `CHECK_OK`, press **Done** in the dojo.

## What you get

- `evidence/beacon.npy`: a quiet stretch of pure noise, then 64 back-to-back copies of one BPSK frame (1 sample per bit), all far below the noise.
- `evidence/intel.json`: how long the quiet stretch is, and how many repeats follow.

## About the pictures

Every radio link at Range 7 carries a small black-and-white picture. `mission.py` turns the bits into that picture and saves it as `picture.png`. If the picture looks right, your functions work. (The format: 8 bits of width, 8 bits of height, then the pixels row by row, 1 = lit.)
