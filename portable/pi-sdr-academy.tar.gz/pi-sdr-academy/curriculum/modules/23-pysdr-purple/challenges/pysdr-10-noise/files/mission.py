"""Range 7, mission 6: Twenty Kilometres Out.

This file is already written. It uses the two functions you write in tasks.py.
Run `python3 mission.py`: it prints the picture and saves it as picture.png.
"""
import json
import struct
import zlib

import numpy as np

from tasks import average_frames, snr_db

SYNC = [1, 1, 1, 0, 0, 0, 1, 0, 0, 1, 0, 1, 1, 0, 1, 0]


def bits_to_image(bits):
    """Given: the Range 7 picture format. 8 bits of width, 8 bits of height (most significant bit
    first), then the pixels row by row (1 = lit). Returns a 2-D array of 0/1, height x width."""
    bits = [int(b) for b in bits]
    w = int("".join(map(str, bits[0:8])), 2)
    h = int("".join(map(str, bits[8:16])), 2)
    px = bits[16:16 + w * h]
    if w == 0 or h == 0 or len(px) < w * h:
        raise ValueError(f"not a picture: header says {w} x {h}, but {len(px)} pixels follow")
    return np.array(px).reshape(h, w)


def show(img):
    """Given: print a picture, # for a lit pixel."""
    print("\n".join("".join("#" if v else "." for v in row) for row in np.asarray(img)))


def save_png(img, path="picture.png", scale=8):
    """Given: save a 0/1 picture as a black-and-white PNG file. Each pixel becomes a
    scale x scale square, lit pixels white. Only numpy and the standard library."""
    px = np.kron((np.asarray(img) != 0).astype(np.uint8) * 255, np.ones((scale, scale), np.uint8))
    h, w = px.shape

    def chunk(kind, data):
        return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data))

    rows = b"".join(b"\x00" + row.tobytes() for row in px)  # filter byte 0, then the row
    with open(path, "wb") as f:
        f.write(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 0, 0, 0, 0))
                + chunk(b"IDAT", zlib.compress(rows)) + chunk(b"IEND", b""))


def fix_phase(sym):
    """Given: rotate BPSK symbols onto the real axis. Squaring removes the data and leaves twice the phase."""
    sym = np.asarray(sym)
    return sym * np.exp(-1j * np.angle(np.sum(sym ** 2)) / 2)


def snr_gain():
    """Given: (SNR of one copy, SNR after averaging) in dB, measured with your snr_db.
    The quiet stretch is pure noise. Averaging r copies divides the noise power by r."""
    x = np.load("evidence/beacon.npy")
    intel = json.load(open("evidence/intel.json"))
    q, r = intel["quiet_samples"], intel["repeats"]
    noise = x[:q]
    frame = x[q:q + len(x[q:]) // r]
    p_sig = np.mean(np.abs(frame) ** 2) - np.mean(np.abs(noise) ** 2)
    before = snr_db(np.full(len(noise), np.sqrt(p_sig)), noise)
    return before, before + 10 * np.log10(r)


def rebuild():
    """Return the far drone's picture as a 2-D array of 0/1."""
    x = np.load("evidence/beacon.npy")
    intel = json.load(open("evidence/intel.json"))
    avg = average_frames(x[intel["quiet_samples"]:], intel["repeats"])   # your Task 2
    sym = fix_phase(avg)
    return bits_to_image((sym.real < 0).astype(int))   # BPSK: negative means 1


def main():
    """Rebuild the picture, print it and save it as picture.png."""
    img = rebuild()
    before, after = snr_gain()
    print(f"SNR of one copy: {before:.1f} dB. After averaging: {after:.1f} dB.")
    show(img)
    save_png(img)
    print("Saved picture.png. Open it to see the picture.")


if __name__ == "__main__":
    main()
