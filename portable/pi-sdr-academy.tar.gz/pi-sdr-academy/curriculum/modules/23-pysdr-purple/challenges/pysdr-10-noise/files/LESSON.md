# Ch 10: Noise and dB: lesson

This challenge follows **PySDR Chapter 10: Noise and dB**. Read it first: [PySDR Chapter 10: Noise and dB](/readings/pysdr/noise.html). It is saved in the academy and opens in a new tab.

When you have read it, take the **Quiz** tab. You can retry every question as often as you like, and each answer tells you why it is right or wrong.

## Key ideas

- Receiver noise is modelled as **AWGN**: independent Gaussian samples, the same power at every
  frequency. For IQ, I and Q each get half the power: `sqrt(P/2) * (randn + 1j*randn)`.
- Power is `mean(|x|^2)`; in dB it is `10*log10(power)`. **SNR** in dB is signal dB minus noise dB.
- To hit a target SNR, scale the noise **amplitude** (not power) by
  `sqrt(P_s / (P_n * 10**(snr/10)))`.

## What you will build

1. SNR in dB: `snr_db(signal, noise)`
2. Average the copies: `average_frames(x, repeats)`

Then `python3 mission.py` uses them on the recording and saves the picture as `picture.png`.

## The mission at a glance

![Mission 6: Twenty Kilometres Out](media/mission.png)

Every link at Range 7 carries a picture in the same format:

![The Range 7 picture format](media/picture-format.png)

## Credit

PySDR by Marc Lichtman is licensed CC BY-NC-SA 4.0. The academy keeps an offline copy of the chapter. This challenge is original material written to follow it.
