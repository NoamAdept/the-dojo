# Ch 2: Sixteen Whistles

*Range 7, mission 2 of 15. Brown belt.*

## The story so far

You are the new radio engineer at Bastion Dynamics, a made-up company that builds systems to spot and track drones. Its desert test range is called Range 7. On the range stands Sentry Tower 3, which listens to the sky with a USRP radio. In this belt you get the tower's radio working, using Bastion's own test drones and beacons.

## This mission

Bastion's test drone K-1 sends its picture as short whistles. Each whistle is one of 16 tones, so each one carries 4 bits. In the time domain it looks like a mess.

**Your goal:** Rebuild the picture drone K-1 sends.

**How the chapter helps:** In the frequency domain (an FFT), each whistle is one clear spike, so you can read which tone it is.

## What you do

### 1. Read the chapter

[PySDR Chapter 2 (Frequency Domain)](/readings/pysdr/frequency_domain.html), saved in the academy. In the app, open **Lesson** and click the link.

Then take the **Quiz** tab to check you understood the chapter. Retry as often as you like.

### 2. Write two small functions in `tasks.py`

Open `tasks.py` with `vim tasks.py`. The comment in each function says exactly what to return.

1. **Frequency axis**: `fft_freqs(n, fs)`.
2. **Find the tone**: `strongest_freq(x, fs)`.

Run `./check` after each one. It tests your function and tells you what is still wrong.

### 3. Run the mission

`mission.py` is already written. It uses your two functions on the real recording:

```bash
python3 mission.py
```

It prints the picture and saves it as **`picture.png`**. Open `picture.png` to see it.
Read `mission.py` to see how your functions are used: look for the comments that say `your Task`.

### 4. Check your work

Run `./check`. It runs `mission.py` and checks `picture.png`. When it prints `CHECK_OK`, press **Done** in the dojo.

## What you get

- `evidence/tones.npy`: complex IQ samples: one tone per frame, plus noise.
- `evidence/intel.json`: the sample rate, frame length and tone spacing.

## About the pictures

Every radio link at Range 7 carries a small black-and-white picture. `mission.py` turns the bits into that picture and saves it as `picture.png`. If the picture looks right, your functions work. (The format: 8 bits of width, 8 bits of height, then the pixels row by row, 1 = lit.)
