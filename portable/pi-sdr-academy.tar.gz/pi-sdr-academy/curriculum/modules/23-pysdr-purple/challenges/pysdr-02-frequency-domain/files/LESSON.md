# Ch 2: Frequency Domain: lesson

This challenge follows **PySDR Chapter 2: Frequency Domain**. Read it first: [PySDR Chapter 2: Frequency Domain](/readings/pysdr/frequency_domain.html). It is saved in the academy and opens in a new tab.

When you have read it, take the **Quiz** tab. You can retry every question as often as you like, and each answer tells you why it is right or wrong.

## Key ideas

- The **FFT** turns N time samples into N frequency bins. `np.fft.fftshift` moves 0 Hz to the
  middle so the bins run from `-fs/2` to just under `+fs/2`.
- Bin spacing is `fs / N`. More samples means finer frequency resolution.
- Plot the **magnitude in dB**: `20*log10(|X|)`. Dividing by N first makes a full-scale tone read 0 dB.

## What you will build

1. Frequency axis: `fft_freqs(n, fs)`
2. Find the tone: `strongest_freq(x, fs)`

Then `python3 mission.py` uses them on the recording and saves the picture as `picture.png`.

## The mission at a glance

![Mission 2: Sixteen Whistles](media/mission.png)

Every link at Range 7 carries a picture in the same format:

![The Range 7 picture format](media/picture-format.png)

## Credit

PySDR by Marc Lichtman is licensed CC BY-NC-SA 4.0. The academy keeps an offline copy of the chapter. This challenge is original material written to follow it.
