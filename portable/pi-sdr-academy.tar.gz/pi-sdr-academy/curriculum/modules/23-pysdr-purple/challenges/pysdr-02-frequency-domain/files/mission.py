"""Range 7, mission 2: Sixteen Whistles.

This file is already written. It uses the two functions you write in tasks.py.
Run `python3 mission.py`: it prints the picture and saves it as picture.png.
"""
import json
import struct
import zlib

import numpy as np

from tasks import strongest_freq

SYNC = [1, 1, 1, 0, 0, 0, 1, 0, 0, 1, 0, 1, 1, 0, 1, 0]


def bits_to_image(bits):
    """Given: the Range 7 picture format. 8 bits of width, 8 bits of height (most significant bit
    first), then the pixels row by row (1 = lit). Returns a 2-D array of 0/1, height x width."""
    bits = [int(b) for b in bits]
    w = int("".join(map(str, bits[0:8])), 2)
    h = int("".join(map(str, bits[8:16])), 2)
    px = bits[16:16 + w * h]
    if w == 0 or h == 0 or len(px) < w * h:
        raise ValueError(f"not a picture: header says {w} x {h}, but {len(px)} pixels follow")
    return np.array(px).reshape(h, w)


def show(img):
    """Given: print a picture, # for a lit pixel."""
    print("\n".join("".join("#" if v else "." for v in row) for row in np.asarray(img)))


def save_png(img, path="picture.png", scale=8):
    """Given: save a 0/1 picture as a black-and-white PNG file. Each pixel becomes a
    scale x scale square, lit pixels white. Only numpy and the standard library."""
    px = np.kron((np.asarray(img) != 0).astype(np.uint8) * 255, np.ones((scale, scale), np.uint8))
    h, w = px.shape

    def chunk(kind, data):
        return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data))

    rows = b"".join(b"\x00" + row.tobytes() for row in px)  # filter byte 0, then the row
    with open(path, "wb") as f:
        f.write(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 0, 0, 0, 0))
                + chunk(b"IDAT", zlib.compress(rows)) + chunk(b"IEND", b""))


def nibble(k):
    """Given: the 4 bits of a number from 0 to 15, most significant bit first."""
    return [(int(k) >> s) & 1 for s in (3, 2, 1, 0)]


def rebuild():
    """Return drone K-1's picture as a 2-D array of 0/1."""
    x = np.load("evidence/tones.npy")
    intel = json.load(open("evidence/intel.json"))
    fs, spacing = intel["sample_rate"], intel["tone_spacing_hz"]
    bits = []
    for frame in x.reshape(-1, intel["samples_per_symbol"]):   # one whistle per row
        f = strongest_freq(frame, fs)                          # your Task 2
        k = round(f / spacing) + 8                             # tone k sits at (k - 8) * spacing
        bits += nibble(k)
    return bits_to_image(bits)


def main():
    """Rebuild the picture, print it and save it as picture.png."""
    img = rebuild()
    show(img)
    save_png(img)
    print("Saved picture.png. Open it to see the picture.")


if __name__ == "__main__":
    main()
