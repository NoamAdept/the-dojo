"""PySDR chapter 2: Frequency Domain. numpy only. Fill in the two functions."""
import numpy as np


def fft_freqs(n, fs):
    """Task 1: the frequency in Hz of each bin of an fftshift-ed n-point FFT, from -fs/2 upward.
    np.fft.fftfreq(n, 1/fs) gives the bins in FFT order; shift it with np.fft.fftshift."""
    raise NotImplementedError


def strongest_freq(x, fs):
    """Task 2: the frequency in Hz (negative allowed) of the strongest bin of
    np.abs(np.fft.fftshift(np.fft.fft(x))). Use your fft_freqs for the axis."""
    raise NotImplementedError
