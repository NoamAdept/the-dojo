#!/usr/bin/env python3
"""Run with ./check. Tests your two functions in tasks.py, then runs mission.py and checks picture.png."""
import contextlib
import hashlib
import io
import os
import struct
import sys
import zlib

sys.path.insert(0, ".")
sys.dont_write_bytecode = True
failed, passed = [], []


def task(name):
    def run(fn):
        try:
            fn()
            passed.append(name)
        except NotImplementedError:
            failed.append(f"{name}: not implemented yet")
        except Exception as exc:  # show the learner what broke
            failed.append(f"{name}: {type(exc).__name__}: {exc}")
        return fn
    return run


import numpy as np
import tasks

rng = np.random.default_rng(13)


def _uncoded():
    """The picture you would get without the code: only the first copy of every bit."""
    bits = np.load("evidence/intercept.npy").astype(int)
    head = [int(b) for b in tasks.repeat_decode(bits[:48], 3)]
    w, h = int("".join(map(str, head[:8])), 2), int("".join(map(str, head[8:16])), 2)
    return bits[::3][16:16 + w * h].reshape(h, w)


@task("1 repeat_encode")
def _():
    assert list(tasks.repeat_encode([1, 0, 1], 3)) == [1, 1, 1, 0, 0, 0, 1, 1, 1]
    assert list(tasks.repeat_encode([0, 1], 5)) == [0] * 5 + [1] * 5


@task("2 repeat_decode")
def _():
    assert list(tasks.repeat_decode([1, 1, 0, 0, 0, 1, 1, 0, 1], 3)) == [1, 0, 1]
    data = rng.integers(0, 2, 500)
    coded = np.repeat(data, 5)
    flips = np.zeros(len(coded), int)
    for g in range(500):
        flips[g * 5 + rng.choice(5, 2, replace=False)] = 1
    assert np.array_equal(np.asarray(tasks.repeat_decode(coded ^ flips, 5)), data), "two errors in five are fixed"


# ---- Mission: Range 7 -------------------------------------------------------
ANSWER_SHA = "7b4c20143050b103fd495caf3417e8f1bf465324d31c473e92e8471fb07ba06a"
dossier = []


def _sha(answer):
    return hashlib.sha256(" ".join(str(answer).upper().split()).encode()).hexdigest()


def _bitmap_key(bm):
    return "|".join("".join(str(int(v)) for v in row) for row in np.asarray(bm))


def _read_png(path, scale=8):
    """Read back the PNG that mission.py's save_png wrote: 8-bit grey, one square per pixel."""
    with open(path, "rb") as f:
        data = f.read()
    assert data[:8] == b"\x89PNG\r\n\x1a\n", f"{path} is not a PNG file"
    pos, idat, w, h = 8, b"", 0, 0
    while pos + 8 <= len(data):
        n, kind = struct.unpack(">I4s", data[pos:pos + 8])
        body = data[pos + 8:pos + 8 + n]
        if kind == b"IHDR":
            w, h = struct.unpack(">II", body[:8])
        elif kind == b"IDAT":
            idat += body
        pos += 12 + n
    px = np.frombuffer(zlib.decompress(idat), np.uint8).reshape(h, w + 1)[:, 1:]
    return (px[scale // 2::scale, scale // 2::scale] > 127).astype(int)


def _show(bm):
    return "\n".join("    " + "".join("#" if v else " " for v in row) for row in np.asarray(bm))


def _run_mission():
    """Run mission.py like `python3 mission.py` does, then read the picture.png it saved."""
    import mission
    if os.path.exists("picture.png"):
        os.remove("picture.png")
    with contextlib.redirect_stdout(io.StringIO()):
        mission.main()
    assert os.path.exists("picture.png"), "mission.py did not save picture.png"
    img = _read_png("picture.png")
    assert _sha(_bitmap_key(img)) == ANSWER_SHA, (
        "picture.png is not the right picture yet. Run python3 mission.py and look at it: "
        "a function that passes its own test but returns the wrong type or shape can still break the mission")
    return mission, img


def _closed(num, title, body):
    bar = "=" * 64
    dossier.append(f"\n{bar}\n  MISSION {num} CLOSED: {title}\n{bar}\n{body}\n  Saved: picture.png\n")

@task("3 MISSION: run mission.py and save picture.png")
def _():
    mission, img = _run_mission()
    _closed("9", "Broken Bits", _show(img) + "\n" + "  Without coding:\n" + _show(_uncoded()) + "\n  With coding: the tower is online.")


print(f"{len(passed)}/{len(passed) + len(failed)} tasks pass")
for page in dossier:
    print(page)
if failed:
    print("Not yet:")
    for line in failed:
        print("  -", line)
    raise SystemExit(1)
print("CHECK_OK")
