# Ch 13: Broken Bits

*Range 7, mission 9 of 15. Brown belt.*

## The story so far

You are the new radio engineer at Bastion Dynamics, a made-up company that builds systems to spot and track drones. Its desert test range is called Range 7. On the range stands Sentry Tower 3, which listens to the sky with a USRP radio. In this belt you get the tower's radio working, using Bastion's own test drones and beacons.

## This mission

The tower sends its status picture over a bad link that flips about one bit in seven. The link sends every bit three times, so the damage can be undone.

**Your goal:** Fix the broken bits and rebuild the tower's status picture.

**How the chapter helps:** Chapter 13 shows how a repetition code and a majority vote find and fix flipped bits.

## What you do

### 1. Read the chapter

[PySDR Chapter 13 (Channel Coding)](/readings/pysdr/channel_coding.html), saved in the academy. In the app, open **Lesson** and click the link.

Then take the **Quiz** tab to check you understood the chapter. Retry as often as you like.

### 2. Write two small functions in `tasks.py`

Open `tasks.py` with `vim tasks.py`. The comment in each function says exactly what to return.

1. **Repeat every bit**: `repeat_encode(bits, n)`.
2. **Majority vote**: `repeat_decode(bits, n)`.

Run `./check` after each one. It tests your function and tells you what is still wrong.

### 3. Run the mission

`mission.py` is already written. It uses your two functions on the real recording:

```bash
python3 mission.py
```

It prints the picture and saves it as **`picture.png`**. Open `picture.png` to see it.
Read `mission.py` to see how your functions are used: look for the comments that say `your Task`.

### 4. Check your work

Run `./check`. It runs `mission.py` and checks `picture.png`. When it prints `CHECK_OK`, press **Done** in the dojo.

## What you get

- `evidence/intercept.npy`: the received bits: every bit of the picture sent 3 times, some flipped.

## About the pictures

Every radio link at Range 7 carries a small black-and-white picture. `mission.py` turns the bits into that picture and saves it as `picture.png`. If the picture looks right, your functions work. (The format: 8 bits of width, 8 bits of height, then the pixels row by row, 1 = lit.)
