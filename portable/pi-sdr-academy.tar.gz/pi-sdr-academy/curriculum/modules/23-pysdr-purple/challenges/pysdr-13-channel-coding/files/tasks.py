"""PySDR chapter 13: Channel Coding. numpy only. Fill in the two functions."""
import numpy as np


def repeat_encode(bits, n):
    """Task 1: repeat every bit n times in place: [1, 0] with n=3 gives [1, 1, 1, 0, 0, 0].
    Return an int array."""
    raise NotImplementedError


def repeat_decode(bits, n):
    """Task 2: n is odd. Cut bits into groups of n. Each group becomes 1 if more than half of it is 1,
    else 0. Return len(bits)//n bits as an int array."""
    raise NotImplementedError
