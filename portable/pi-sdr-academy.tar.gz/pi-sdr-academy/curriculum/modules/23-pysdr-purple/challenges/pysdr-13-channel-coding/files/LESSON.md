# Ch 13: Channel Coding: lesson

This challenge follows **PySDR Chapter 13: Channel Coding**. Read it first: [PySDR Chapter 13: Channel Coding](/readings/pysdr/channel_coding.html). It is saved in the academy and opens in a new tab.

When you have read it, take the **Quiz** tab. You can retry every question as often as you like, and each answer tells you why it is right or wrong.

## Key ideas

- **Channel coding** adds extra bits so the receiver can fix errors. The code rate is
  data bits / coded bits.
- The simplest code repeats each bit n times. The decoder takes a **majority vote**: with n = 3,
  one flipped bit in a group of three is fixed.
- Better codes, like **Hamming(7,4)** in the chapter, fix errors with fewer extra bits.

## What you will build

1. Repeat every bit: `repeat_encode(bits, n)`
2. Majority vote: `repeat_decode(bits, n)`

Then `python3 mission.py` uses them on the recording and saves the picture as `picture.png`.

## The mission at a glance

![Mission 9: Broken Bits](media/mission.png)

Every link at Range 7 carries a picture in the same format:

![The Range 7 picture format](media/picture-format.png)

## Credit

PySDR by Marc Lichtman is licensed CC BY-NC-SA 4.0. The academy keeps an offline copy of the chapter. This challenge is original material written to follow it.
