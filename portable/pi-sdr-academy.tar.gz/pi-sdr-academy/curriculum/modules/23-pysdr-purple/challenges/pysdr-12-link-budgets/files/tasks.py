"""PySDR chapter 12: Link Budgets. numpy only. Fill in the two functions."""
import numpy as np

C = 299792458.0       # speed of light, m/s


def fspl_db(distance_m, freq_hz):
    """Task 1: 20*log10(distance_m) + 20*log10(freq_hz) + 20*log10(4*pi/C) in dB."""
    raise NotImplementedError


def received_power_dbm(pt_dbm, gt_dbi, gr_dbi, distance_m, freq_hz, losses_db=0.0):
    """Task 2: transmit power + both antenna gains - fspl_db(distance_m, freq_hz) - losses_db, in dBm."""
    raise NotImplementedError
