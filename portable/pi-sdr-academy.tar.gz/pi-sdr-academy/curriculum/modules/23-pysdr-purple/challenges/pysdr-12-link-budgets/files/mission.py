"""Range 7, mission 8: Pick the Site.

This file is already written. It uses the two functions you write in tasks.py.
Run `python3 mission.py`: it prints the picture and saves it as picture.png.
"""
import json
import struct
import zlib

import numpy as np

from tasks import received_power_dbm

SYNC = [1, 1, 1, 0, 0, 0, 1, 0, 0, 1, 0, 1, 1, 0, 1, 0]


def bits_to_image(bits):
    """Given: the Range 7 picture format. 8 bits of width, 8 bits of height (most significant bit
    first), then the pixels row by row (1 = lit). Returns a 2-D array of 0/1, height x width."""
    bits = [int(b) for b in bits]
    w = int("".join(map(str, bits[0:8])), 2)
    h = int("".join(map(str, bits[8:16])), 2)
    px = bits[16:16 + w * h]
    if w == 0 or h == 0 or len(px) < w * h:
        raise ValueError(f"not a picture: header says {w} x {h}, but {len(px)} pixels follow")
    return np.array(px).reshape(h, w)


def read_image(bits):
    """Given: find SYNC in a bit stream and read the picture right after it.
    BPSK can lock upside down, so the inverted bits are tried too."""
    bits = [int(b) for b in bits]
    for flip in (0, 1):
        b = [v ^ flip for v in bits]
        for i in range(len(b) - 32):
            if b[i:i + 16] == SYNC:
                try:
                    return bits_to_image(b[i + 16:])
                except ValueError:
                    pass
    raise ValueError("no picture found in these bits")


def show(img):
    """Given: print a picture, # for a lit pixel."""
    print("\n".join("".join("#" if v else "." for v in row) for row in np.asarray(img)))


def save_png(img, path="picture.png", scale=8):
    """Given: save a 0/1 picture as a black-and-white PNG file. Each pixel becomes a
    scale x scale square, lit pixels white. Only numpy and the standard library."""
    px = np.kron((np.asarray(img) != 0).astype(np.uint8) * 255, np.ones((scale, scale), np.uint8))
    h, w = px.shape

    def chunk(kind, data):
        return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data))

    rows = b"".join(b"\x00" + row.tobytes() for row in px)  # filter byte 0, then the row
    with open(path, "wb") as f:
        f.write(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 0, 0, 0, 0))
                + chunk(b"IDAT", zlib.compress(rows)) + chunk(b"IEND", b""))


def link_snr_db(pr_dbm, bandwidth_hz, nf_db):
    """Given: SNR = received power minus the noise floor, 10*log10(k*290*B) + 30 + noise figure."""
    return pr_dbm - (10 * np.log10(1.380649e-23 * 290 * bandwidth_hz) + 30 + nf_db)


def fix_phase(sym):
    """Given: rotate BPSK symbols onto the real axis."""
    sym = np.asarray(sym)
    return sym * np.exp(-1j * np.angle(np.sum(sym ** 2)) / 2)


def site_snrs():
    """Given: {site name: SNR in dB}, from your received_power_dbm."""
    intel = json.load(open("evidence/intel.json"))
    tx = intel["transmitter"]
    out = {}
    for s in intel["sites"]:
        pr = received_power_dbm(tx["power_dbm"], tx["antenna_gain_dbi"], s["antenna_gain_dbi"],
                                s["distance_m"], tx["freq_hz"], s["cable_loss_db"])   # your Task 2
        out[s["name"]] = float(link_snr_db(pr, tx["bandwidth_hz"], s["noise_figure_db"]))
    return out


def rebuild():
    """Return the picture from the site with the best SNR, as a 2-D array of 0/1."""
    intel = json.load(open("evidence/intel.json"))
    snr = site_snrs()
    best = max(snr, key=snr.get)
    key = next(s["file_key"] for s in intel["sites"] if s["name"] == best)
    x = np.load("evidence/sites.npz")[key]
    return read_image((fix_phase(x).real < 0).astype(int))


def main():
    """Rebuild the picture, print it and save it as picture.png."""
    img = rebuild()
    for name, snr in site_snrs().items():
        print(f"{name:12s} {snr:6.1f} dB")
    show(img)
    save_png(img)
    print("Saved picture.png. Open it to see the picture.")


if __name__ == "__main__":
    main()
