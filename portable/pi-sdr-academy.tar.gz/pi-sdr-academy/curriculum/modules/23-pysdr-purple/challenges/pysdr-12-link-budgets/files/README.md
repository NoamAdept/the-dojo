# Ch 12: Pick the Site

*Range 7, mission 8 of 15. Brown belt.*

## The story so far

You are the new radio engineer at Bastion Dynamics, a made-up company that builds systems to spot and track drones. Its desert test range is called Range 7. On the range stands Sentry Tower 3, which listens to the sky with a USRP radio. In this belt you get the tower's radio working, using Bastion's own test drones and beacons.

## This mission

Bastion wants a relay receiver for Tower 3 and has three possible sites. A test drone sent the same picture while each site recorded it. Only one site gets a clean copy.

**Your goal:** Work out which site is best, and rebuild the picture from its recording.

**How the chapter helps:** Chapter 12 shows how to predict signal strength from power, distance and antenna gains.

## What you do

### 1. Read the chapter

[PySDR Chapter 12 (Link Budgets)](/readings/pysdr/link_budgets.html), saved in the academy. In the app, open **Lesson** and click the link.

Then take the **Quiz** tab to check you understood the chapter. Retry as often as you like.

### 2. Write two small functions in `tasks.py`

Open `tasks.py` with `vim tasks.py`. The comment in each function says exactly what to return.

1. **Free-space path loss**: `fspl_db(distance_m, freq_hz)`.
2. **Received power**: `received_power_dbm(pt_dbm, gt_dbi, gr_dbi, distance_m, freq_hz, losses_db=0.0)`.

Run `./check` after each one. It tests your function and tells you what is still wrong.

### 3. Run the mission

`mission.py` is already written. It uses your two functions on the real recording:

```bash
python3 mission.py
```

It prints the picture and saves it as **`picture.png`**. Open `picture.png` to see it.
Read `mission.py` to see how your functions are used: look for the comments that say `your Task`.

### 4. Check your work

Run `./check`. It runs `mission.py` and checks `picture.png`. When it prints `CHECK_OK`, press **Done** in the dojo.

## What you get

- `evidence/intel.json`: the transmitter, and each site's distance, antenna gain, noise figure and cable loss.
- `evidence/sites.npz`: each site's recording: BPSK at 1 sample per bit, with that site's noise.

## About the pictures

Every radio link at Range 7 carries a small black-and-white picture. `mission.py` turns the bits into that picture and saves it as `picture.png`. If the picture looks right, your functions work. (The format: 8 bits of width, 8 bits of height, then the pixels row by row, 1 = lit.)
