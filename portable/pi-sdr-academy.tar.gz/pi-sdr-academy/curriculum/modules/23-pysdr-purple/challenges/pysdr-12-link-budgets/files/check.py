#!/usr/bin/env python3
"""Run with ./check. Tests your two functions in tasks.py, then runs mission.py and checks picture.png."""
import contextlib
import hashlib
import io
import os
import struct
import sys
import zlib

sys.path.insert(0, ".")
sys.dont_write_bytecode = True
failed, passed = [], []


def task(name):
    def run(fn):
        try:
            fn()
            passed.append(name)
        except NotImplementedError:
            failed.append(f"{name}: not implemented yet")
        except Exception as exc:  # show the learner what broke
            failed.append(f"{name}: {type(exc).__name__}: {exc}")
        return fn
    return run


import numpy as np
import tasks

C = 299792458.0


@task("1 fspl_db")
def _():
    got = float(tasks.fspl_db(1000.0, 2.4e9))
    assert abs(got - 100.05) < 0.05, f"1 km at 2.4 GHz is about 100 dB, got {got:.2f}"
    assert abs(float(tasks.fspl_db(2000.0, 2.4e9)) - got - 6.02) < 0.01, "double the distance adds 6 dB"


@task("2 received_power_dbm")
def _():
    want = 20 + 3 + 6 - (20 * np.log10(5000) + 20 * np.log10(915e6) + 20 * np.log10(4 * np.pi / C)) - 2
    got = float(tasks.received_power_dbm(20, 3, 6, 5000, 915e6, 2))
    assert abs(got - want) < 1e-6, f"expected {want:.2f} dBm, got {got:.2f}"
    assert abs(float(tasks.received_power_dbm(20, 0, 0, 5000, 915e6)) - (want - 9 + 2)) < 1e-6, "losses default to 0"


# ---- Mission: Range 7 -------------------------------------------------------
ANSWER_SHA = "9458719dd85d035eb2b91b25852650ae9d9d72303a8c6cda8c4746ee54711d4e"
dossier = []


def _sha(answer):
    return hashlib.sha256(" ".join(str(answer).upper().split()).encode()).hexdigest()


def _bitmap_key(bm):
    return "|".join("".join(str(int(v)) for v in row) for row in np.asarray(bm))


def _read_png(path, scale=8):
    """Read back the PNG that mission.py's save_png wrote: 8-bit grey, one square per pixel."""
    with open(path, "rb") as f:
        data = f.read()
    assert data[:8] == b"\x89PNG\r\n\x1a\n", f"{path} is not a PNG file"
    pos, idat, w, h = 8, b"", 0, 0
    while pos + 8 <= len(data):
        n, kind = struct.unpack(">I4s", data[pos:pos + 8])
        body = data[pos + 8:pos + 8 + n]
        if kind == b"IHDR":
            w, h = struct.unpack(">II", body[:8])
        elif kind == b"IDAT":
            idat += body
        pos += 12 + n
    px = np.frombuffer(zlib.decompress(idat), np.uint8).reshape(h, w + 1)[:, 1:]
    return (px[scale // 2::scale, scale // 2::scale] > 127).astype(int)


def _show(bm):
    return "\n".join("    " + "".join("#" if v else " " for v in row) for row in np.asarray(bm))


def _run_mission():
    """Run mission.py like `python3 mission.py` does, then read the picture.png it saved."""
    import mission
    if os.path.exists("picture.png"):
        os.remove("picture.png")
    with contextlib.redirect_stdout(io.StringIO()):
        mission.main()
    assert os.path.exists("picture.png"), "mission.py did not save picture.png"
    img = _read_png("picture.png")
    assert _sha(_bitmap_key(img)) == ANSWER_SHA, (
        "picture.png is not the right picture yet. Run python3 mission.py and look at it: "
        "a function that passes its own test but returns the wrong type or shape can still break the mission")
    return mission, img


def _closed(num, title, body):
    bar = "=" * 64
    dossier.append(f"\n{bar}\n  MISSION {num} CLOSED: {title}\n{bar}\n{body}\n  Saved: picture.png\n")

@task("3 MISSION: run mission.py and save picture.png")
def _():
    mission, img = _run_mission()
    _closed("8", "Pick the Site", _show(img) + "\n" + "\n".join(f"  {k:12s} {v:6.1f} dB SNR" for k, v in mission.site_snrs().items()) + "\n  The relay goes on the ridge.")


print(f"{len(passed)}/{len(passed) + len(failed)} tasks pass")
for page in dossier:
    print(page)
if failed:
    print("Not yet:")
    for line in failed:
        print("  -", line)
    raise SystemExit(1)
print("CHECK_OK")
