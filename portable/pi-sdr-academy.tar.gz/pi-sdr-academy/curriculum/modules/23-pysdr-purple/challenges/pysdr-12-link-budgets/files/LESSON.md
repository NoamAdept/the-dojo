# Ch 12: Link Budgets: lesson

This challenge follows **PySDR Chapter 12: Link Budgets**. Read it first: [PySDR Chapter 12: Link Budgets](/readings/pysdr/link_budgets.html). It is saved in the academy and opens in a new tab.

When you have read it, take the **Quiz** tab. You can retry every question as often as you like, and each answer tells you why it is right or wrong.

## Key ideas

- **Free-space path loss** in dB: `20*log10(d) + 20*log10(f) + 20*log10(4*pi/c)`.
- A link budget is addition in dB: received power = transmit power + antenna gains - path loss
  - other losses.
- The **noise floor** is thermal noise `10*log10(k*T*B) + 30` dBm (T = 290 K) plus the receiver's noise
  figure. SNR = received power - noise floor.

## What you will build

1. Free-space path loss: `fspl_db(distance_m, freq_hz)`
2. Received power: `received_power_dbm(pt_dbm, gt_dbi, gr_dbi, distance_m, freq_hz, losses_db=0.0)`

Then `python3 mission.py` uses them on the recording and saves the picture as `picture.png`.

## The mission at a glance

![Mission 8: Pick the Site](media/mission.png)

Every link at Range 7 carries a picture in the same format:

![The Range 7 picture format](media/picture-format.png)

## Credit

PySDR by Marc Lichtman is licensed CC BY-NC-SA 4.0. The academy keeps an offline copy of the chapter. This challenge is original material written to follow it.
