"""PySDR chapter 1: Introduction. numpy only. Fill in the two functions."""
import numpy as np


def adc_to_volts(codes, bits):
    """Task 1: an ADC with `bits` bits gave whole-number codes. Turn them back into volts:
    codes / 2**(bits - 1), as a float array. (8 bits: code 64 is 0.5 V.)"""
    raise NotImplementedError


def rms(x):
    """Task 2: the RMS (root mean square) level of x: sqrt(mean(x**2)), as a float."""
    raise NotImplementedError
