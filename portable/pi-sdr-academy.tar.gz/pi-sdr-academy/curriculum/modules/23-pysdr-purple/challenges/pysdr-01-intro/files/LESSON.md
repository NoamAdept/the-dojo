# Ch 1: Introduction: lesson

This challenge follows **PySDR Chapter 1: Introduction**. Read it first: [PySDR Chapter 1: Introduction](/readings/pysdr/intro.html). It is saved in the academy and opens in a new tab.

When you have read it, take the **Quiz** tab. You can retry every question as often as you like, and each answer tells you why it is right or wrong.

## Key ideas

- A **software-defined radio** moves as much of the radio as possible into software. The
  hardware only tunes, filters and digitises; everything else (demodulation, decoding) is code.
- The **ADC** samples the signal `fs` times per second and turns each sample into an integer
  code with a fixed number of bits. More bits means a finer staircase and less quantisation noise.
- Everything in PySDR is plain Python with **numpy** arrays. Sample number `n` happens at time
  `n / fs`.

## What you will build

1. ADC codes to volts: `adc_to_volts(codes, bits)`
2. Loudness of a piece of signal: `rms(x)`

Then `python3 mission.py` uses them on the recording and saves the picture as `picture.png`.

## The mission at a glance

![Mission 1: First Light](media/mission.png)

Every link at Range 7 carries a picture in the same format:

![The Range 7 picture format](media/picture-format.png)

## Credit

PySDR by Marc Lichtman is licensed CC BY-NC-SA 4.0. The academy keeps an offline copy of the chapter. This challenge is original material written to follow it.
