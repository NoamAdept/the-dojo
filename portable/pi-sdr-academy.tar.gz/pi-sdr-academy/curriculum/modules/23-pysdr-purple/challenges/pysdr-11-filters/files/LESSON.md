# Ch 11: Filters: lesson

This challenge follows **PySDR Chapter 11: Filters**. Read it first: [PySDR Chapter 11: Filters](/readings/pysdr/filters.html). It is saved in the academy and opens in a new tab.

When you have read it, take the **Quiz** tab. You can retry every question as often as you like, and each answer tells you why it is right or wrong.

## Key ideas

- An **FIR filter** is a list of taps; filtering is convolution: `np.convolve(x, taps)`.
- A **windowed sinc** is the classic low-pass design: `sinc(2*fc/fs * n)` times a window, centred on
  the middle tap, normalised so the taps sum to 1 (0 dB at DC).
- The **frequency response** is the DTFT of the taps. Multiplying the taps by `exp(j*2*pi*f0*k/fs)`
  moves the passband to `f0`, giving a complex band-pass filter.

## What you will build

1. Low-pass filter taps: `lowpass_taps(num_taps, cutoff_hz, fs)`
2. Move the filter to another frequency: `shift_taps(taps, f0_hz, fs)`

Then `python3 mission.py` uses them on the recording and saves the picture as `picture.png`.

## The mission at a glance

![Mission 7: Through the Jammer](media/mission.png)

Every link at Range 7 carries a picture in the same format:

![The Range 7 picture format](media/picture-format.png)

## Credit

PySDR by Marc Lichtman is licensed CC BY-NC-SA 4.0. The academy keeps an offline copy of the chapter. This challenge is original material written to follow it.
