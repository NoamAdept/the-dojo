# Ch 11: Through the Jammer

*Range 7, mission 7 of 15. Brown belt.*

## The story so far

You are the new radio engineer at Bastion Dynamics, a made-up company that builds systems to spot and track drones. Its desert test range is called Range 7. On the range stands Sentry Tower 3, which listens to the sky with a USRP radio. In this belt you get the tower's radio working, using Bastion's own test drones and beacons.

## This mission

The red team is jamming. Their carrier is 1000 times louder than the drone and only 300 Hz away. The drone's on/off signal at 700 Hz is still in the capture.

**Your goal:** Filter out the jammer and rebuild the drone's picture.

**How the chapter helps:** Chapter 11 shows how to design a filter that keeps one frequency and cuts another.

## What you do

### 1. Read the chapter

[PySDR Chapter 11 (Filters)](/readings/pysdr/filters.html), saved in the academy. In the app, open **Lesson** and click the link.

Then take the **Quiz** tab to check you understood the chapter. Retry as often as you like.

### 2. Write two small functions in `tasks.py`

Open `tasks.py` with `vim tasks.py`. The comment in each function says exactly what to return.

1. **Low-pass filter taps**: `lowpass_taps(num_taps, cutoff_hz, fs)`.
2. **Move the filter to another frequency**: `shift_taps(taps, f0_hz, fs)`.

Run `./check` after each one. It tests your function and tells you what is still wrong.

### 3. Run the mission

`mission.py` is already written. It uses your two functions on the real recording:

```bash
python3 mission.py
```

It prints the picture and saves it as **`picture.png`**. Open `picture.png` to see it.
Read `mission.py` to see how your functions are used: look for the comments that say `your Task`.

### 4. Check your work

Run `./check`. It runs `mission.py` and checks `picture.png`. When it prints `CHECK_OK`, press **Done** in the dojo.

## What you get

- `evidence/crowded.npy`: complex samples: the drone, two jammer carriers and noise.
- `evidence/intel.json`: the sample rate, the drone's and the jammer's frequencies, the bit length and the silent lead-in.

## About the pictures

Every radio link at Range 7 carries a small black-and-white picture. `mission.py` turns the bits into that picture and saves it as `picture.png`. If the picture looks right, your functions work. (The format: 8 bits of width, 8 bits of height, then the pixels row by row, 1 = lit.)
