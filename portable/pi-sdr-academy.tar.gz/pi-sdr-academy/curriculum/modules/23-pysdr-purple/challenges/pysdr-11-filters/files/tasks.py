"""PySDR chapter 11: Filters. numpy only. Fill in the two functions."""
import numpy as np


def lowpass_taps(num_taps, cutoff_hz, fs):
    """Task 1: num_taps is odd. n = np.arange(num_taps) - (num_taps - 1) / 2.
    h = np.sinc(2 * cutoff_hz / fs * n) * np.hamming(num_taps). Return h / h.sum()."""
    raise NotImplementedError


def shift_taps(taps, f0_hz, fs):
    """Task 2: return taps * exp(2j*pi*f0_hz*k/fs) for k = 0..len(taps)-1. The low-pass becomes a
    band-pass centred on f0_hz (complex taps)."""
    raise NotImplementedError
