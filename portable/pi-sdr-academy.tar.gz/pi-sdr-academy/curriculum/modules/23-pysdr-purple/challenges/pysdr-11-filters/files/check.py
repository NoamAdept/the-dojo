#!/usr/bin/env python3
"""Run with ./check. Tests your two functions in tasks.py, then runs mission.py and checks picture.png."""
import contextlib
import hashlib
import io
import os
import struct
import sys
import zlib

sys.path.insert(0, ".")
sys.dont_write_bytecode = True
failed, passed = [], []


def task(name):
    def run(fn):
        try:
            fn()
            passed.append(name)
        except NotImplementedError:
            failed.append(f"{name}: not implemented yet")
        except Exception as exc:  # show the learner what broke
            failed.append(f"{name}: {type(exc).__name__}: {exc}")
        return fn
    return run


import numpy as np
import tasks

FS = 48000.0


@task("1 lowpass_taps")
def _():
    h = np.asarray(tasks.lowpass_taps(101, 3000.0, FS))
    assert h.shape == (101,), "num_taps taps"
    assert abs(h.sum() - 1) < 1e-9, "taps must sum to 1"
    n = np.arange(101) - 50
    want = np.sinc(2 * 3000 / FS * n) * np.hamming(101)
    assert np.allclose(h, want / want.sum()), "windowed sinc with np.hamming"


@task("2 shift_taps")
def _():
    lp = np.sinc(2 * 3000 / FS * (np.arange(101) - 50)) * np.hamming(101)
    lp /= lp.sum()
    bp = np.asarray(tasks.shift_taps(lp, 10000.0, FS))
    assert np.iscomplexobj(bp), "shifted taps are complex"
    k = np.arange(101)
    H = lambda f: abs(np.sum(bp * np.exp(-2j * np.pi * f * k / FS)))  # noqa: E731
    assert abs(H(10000.0) - 1) < 0.01, "the passband moved to +10 kHz"
    assert H(0.0) < 0.01, "DC is now in the stopband"


# ---- Mission: Range 7 -------------------------------------------------------
ANSWER_SHA = "ef6f1b0b60aaf148c09e3a4a6b88d24c1611282bfba053c81d33b1d44ceed24b"
dossier = []


def _sha(answer):
    return hashlib.sha256(" ".join(str(answer).upper().split()).encode()).hexdigest()


def _bitmap_key(bm):
    return "|".join("".join(str(int(v)) for v in row) for row in np.asarray(bm))


def _read_png(path, scale=8):
    """Read back the PNG that mission.py's save_png wrote: 8-bit grey, one square per pixel."""
    with open(path, "rb") as f:
        data = f.read()
    assert data[:8] == b"\x89PNG\r\n\x1a\n", f"{path} is not a PNG file"
    pos, idat, w, h = 8, b"", 0, 0
    while pos + 8 <= len(data):
        n, kind = struct.unpack(">I4s", data[pos:pos + 8])
        body = data[pos + 8:pos + 8 + n]
        if kind == b"IHDR":
            w, h = struct.unpack(">II", body[:8])
        elif kind == b"IDAT":
            idat += body
        pos += 12 + n
    px = np.frombuffer(zlib.decompress(idat), np.uint8).reshape(h, w + 1)[:, 1:]
    return (px[scale // 2::scale, scale // 2::scale] > 127).astype(int)


def _show(bm):
    return "\n".join("    " + "".join("#" if v else " " for v in row) for row in np.asarray(bm))


def _run_mission():
    """Run mission.py like `python3 mission.py` does, then read the picture.png it saved."""
    import mission
    if os.path.exists("picture.png"):
        os.remove("picture.png")
    with contextlib.redirect_stdout(io.StringIO()):
        mission.main()
    assert os.path.exists("picture.png"), "mission.py did not save picture.png"
    img = _read_png("picture.png")
    assert _sha(_bitmap_key(img)) == ANSWER_SHA, (
        "picture.png is not the right picture yet. Run python3 mission.py and look at it: "
        "a function that passes its own test but returns the wrong type or shape can still break the mission")
    return mission, img


def _closed(num, title, body):
    bar = "=" * 64
    dossier.append(f"\n{bar}\n  MISSION {num} CLOSED: {title}\n{bar}\n{body}\n  Saved: picture.png\n")

@task("3 MISSION: run mission.py and save picture.png")
def _():
    mission, img = _run_mission()
    _closed("7", "Through the Jammer", _show(img) + "\n" + "  Your filter: 700 Hz at {:.1f} dB, the jammer at {:.1f} dB.".format(*mission.freq_response_db(mission.design_filter(), [700.0, 1000.0], 4000)))


print(f"{len(passed)}/{len(passed) + len(failed)} tasks pass")
for page in dossier:
    print(page)
if failed:
    print("Not yet:")
    for line in failed:
        print("  -", line)
    raise SystemExit(1)
print("CHECK_OK")
