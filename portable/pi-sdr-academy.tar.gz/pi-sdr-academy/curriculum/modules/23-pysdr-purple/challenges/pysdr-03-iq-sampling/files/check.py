#!/usr/bin/env python3
"""Run with ./check. Tests your two functions in tasks.py, then runs mission.py and checks picture.png."""
import contextlib
import hashlib
import io
import os
import struct
import sys
import zlib

sys.path.insert(0, ".")
sys.dont_write_bytecode = True
failed, passed = [], []


def task(name):
    def run(fn):
        try:
            fn()
            passed.append(name)
        except NotImplementedError:
            failed.append(f"{name}: not implemented yet")
        except Exception as exc:  # show the learner what broke
            failed.append(f"{name}: {type(exc).__name__}: {exc}")
        return fn
    return run


import numpy as np
import tasks


@task("1 alias_real")
def _():
    cases = [(100.0, 1000.0, 100.0), (600.0, 1000.0, 400.0), (1100.0, 1000.0, 100.0), (1900.0, 1000.0, 100.0), (500.0, 1000.0, 500.0)]
    for f, fs, want in cases:
        got = float(tasks.alias_real(f, fs))
        assert abs(got - want) < 1e-9, f"{f} Hz at fs={fs}: expected {want}, got {got}"


@task("2 downconvert")
def _():
    fs, n = 1e6, np.arange(2048)
    x = np.exp(2j * np.pi * 125e3 * n / fs)
    y = np.asarray(tasks.downconvert(x, 125e3, fs))
    assert np.allclose(y, 1.0), "a 125 kHz tone shifted down by 125 kHz is DC"


# ---- Mission: Range 7 -------------------------------------------------------
ANSWER_SHA = "942b4a57d078dd23d0c1675ba9e40c3bf0fd7e202e492225654d575ce1090da6"
dossier = []


def _sha(answer):
    return hashlib.sha256(" ".join(str(answer).upper().split()).encode()).hexdigest()


def _bitmap_key(bm):
    return "|".join("".join(str(int(v)) for v in row) for row in np.asarray(bm))


def _read_png(path, scale=8):
    """Read back the PNG that mission.py's save_png wrote: 8-bit grey, one square per pixel."""
    with open(path, "rb") as f:
        data = f.read()
    assert data[:8] == b"\x89PNG\r\n\x1a\n", f"{path} is not a PNG file"
    pos, idat, w, h = 8, b"", 0, 0
    while pos + 8 <= len(data):
        n, kind = struct.unpack(">I4s", data[pos:pos + 8])
        body = data[pos + 8:pos + 8 + n]
        if kind == b"IHDR":
            w, h = struct.unpack(">II", body[:8])
        elif kind == b"IDAT":
            idat += body
        pos += 12 + n
    px = np.frombuffer(zlib.decompress(idat), np.uint8).reshape(h, w + 1)[:, 1:]
    return (px[scale // 2::scale, scale // 2::scale] > 127).astype(int)


def _show(bm):
    return "\n".join("    " + "".join("#" if v else " " for v in row) for row in np.asarray(bm))


def _run_mission():
    """Run mission.py like `python3 mission.py` does, then read the picture.png it saved."""
    import mission
    if os.path.exists("picture.png"):
        os.remove("picture.png")
    with contextlib.redirect_stdout(io.StringIO()):
        mission.main()
    assert os.path.exists("picture.png"), "mission.py did not save picture.png"
    img = _read_png("picture.png")
    assert _sha(_bitmap_key(img)) == ANSWER_SHA, (
        "picture.png is not the right picture yet. Run python3 mission.py and look at it: "
        "a function that passes its own test but returns the wrong type or shape can still break the mission")
    return mission, img


def _closed(num, title, body):
    bar = "=" * 64
    dossier.append(f"\n{bar}\n  MISSION {num} CLOSED: {title}\n{bar}\n{body}\n  Saved: picture.png\n")

@task("3 MISSION: run mission.py and save picture.png")
def _():
    mission, img = _run_mission()
    _closed("3", "Above Nyquist", _show(img) + "\n" + f"  13 kHz sampled at 8 kHz showed up at {tasks.alias_real(13000, 8000):.0f} Hz.")


print(f"{len(passed)}/{len(passed) + len(failed)} tasks pass")
for page in dossier:
    print(page)
if failed:
    print("Not yet:")
    for line in failed:
        print("  -", line)
    raise SystemExit(1)
print("CHECK_OK")
