# Ch 3: IQ Sampling: lesson

This challenge follows **PySDR Chapter 3: IQ Sampling**. Read it first: [PySDR Chapter 3: IQ Sampling](/readings/pysdr/sampling.html). It is saved in the academy and opens in a new tab.

When you have read it, take the **Quiz** tab. You can retry every question as often as you like, and each answer tells you why it is right or wrong.

## Key ideas

- **Nyquist**: a real signal sampled at `fs` can only represent 0 to `fs/2`; anything above folds
  back (aliases). Complex IQ sampling covers `-fs/2` to `+fs/2`.
- Multiplying by `exp(-j*2*pi*f*t)` shifts the whole spectrum down by `f`. This is how a receiver
  **downconverts** a signal to baseband.
- Direct-conversion SDRs show a **DC spike** at 0 Hz. Subtracting the mean removes it (or tune
  slightly off-frequency: "offset tuning").

## What you will build

1. Where does it alias to?: `alias_real(f_hz, fs)`
2. Move a frequency to 0 Hz: `downconvert(x, f_hz, fs)`

Then `python3 mission.py` uses them on the recording and saves the picture as `picture.png`.

## The mission at a glance

![Mission 3: Above Nyquist](media/mission.png)

Every link at Range 7 carries a picture in the same format:

![The Range 7 picture format](media/picture-format.png)

## Credit

PySDR by Marc Lichtman is licensed CC BY-NC-SA 4.0. The academy keeps an offline copy of the chapter. This challenge is original material written to follow it.
