"""PySDR chapter 3: IQ Sampling. numpy only. Fill in the two functions."""
import numpy as np


def alias_real(f_hz, fs):
    """Task 1: a REAL tone at f_hz >= 0 is sampled at fs. Return the frequency in [0, fs/2] where it
    shows up: f = f_hz % fs, and if f > fs/2 the answer is fs - f."""
    raise NotImplementedError


def downconvert(x, f_hz, fs):
    """Task 2: return x[n] * exp(-2j*pi*f_hz*n/fs) for n = 0..len(x)-1. This moves f_hz to 0 Hz."""
    raise NotImplementedError
