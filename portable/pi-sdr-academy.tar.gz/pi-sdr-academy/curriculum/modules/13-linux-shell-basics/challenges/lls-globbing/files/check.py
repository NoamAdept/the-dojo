#!/usr/bin/env python3
"""Run with ./check. Tests each task in answers/task1.sh to answers/task10.sh and lists what still fails."""
import sys
sys.path.insert(0, ".")
sys.dont_write_bytecode = True
failed, passed = [], []

def task(name):
    def run(fn):
        try:
            fn()
            passed.append(name)
        except NotImplementedError:
            failed.append(f"{name}: not implemented yet")
        except Exception as exc:  # show the learner what broke
            failed.append(f"{name}: {type(exc).__name__}: {exc}")
        return fn
    return run

import os, pathlib, shutil, subprocess, tempfile

HERE = pathlib.Path(".").resolve()

def answer(n):
    """Path of answers/taskN.sh; NotImplementedError while it still says TODO."""
    p = HERE / "answers" / f"task{n}.sh"
    if not p.exists() or "TODO" in p.read_text():
        raise NotImplementedError
    return p

def sandbox(files=None):
    """Fresh temp dir filled with {relative path: text or bytes}. Returns its Path."""
    # ponytail: sandboxes live in /tmp and are left for the OS to clean.
    d = pathlib.Path(tempfile.mkdtemp(prefix="academy-sh-"))
    for rel, data in (files or {}).items():
        p = d / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data) if isinstance(data, bytes) else p.write_text(data)
    return d

def run(n, cwd=None, stdin=None, env=None, args=(), timeout=20):
    """Run answers/taskN.sh with bash in cwd (a new sandbox by default).
    Returns (CompletedProcess, cwd). HOME points at the sandbox unless env overrides it."""
    cwd = cwd or sandbox()
    e = {**os.environ, "HOME": str(cwd), **(env or {})}
    r = subprocess.run(["bash", str(answer(n)), *args], cwd=cwd, input=stdin, env=e,
                       capture_output=True, text=True, timeout=timeout)
    return r, cwd

import random, re, shlex
RNG = random.Random(105)


def word(n=8):
    return "".join(RNG.choice("abcdefghijklmnopqrstuvwxyz0123456789") for _ in range(n))


def secret(tag="s"):
    return "academy{%s_%s}" % (tag, word(12))


def dojo(tree=None, subs=None):
    """Fresh fake root from TREE and PROGS (plus overrides). Returns its resolved Path."""
    root = sandbox({**TREE, **(tree or {})}).resolve()
    for d in ("home/hacker", "tmp"):
        (root / d).mkdir(parents=True, exist_ok=True)
    allsubs = {**PRACTICE, **(subs or {})}
    for rel, body in PROGS.items():
        for k, v in allsubs.items():
            body = body.replace(k, v)
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(body)
        p.chmod(0o755)
    return root


def go(n, root, cwd=None, stdin=None, env=None, timeout=20):
    """Run answers/taskN.sh the way the README describes. Returns (result, token)."""
    home = root / "home/hacker"
    tok = word()
    e = {"DOJO": str(root), "HOME": str(home), "TOKEN": tok,
         "PATH": str(root / "bin") + os.pathsep + os.environ.get("PATH", ""), **(env or {})}
    r, _ = run(n, cwd=cwd or home, stdin=stdin, env=e, timeout=timeout)
    return r, tok


def show(r):
    return f"(stdout: {r.stdout[-300:]!r}, stderr: {r.stderr[-300:]!r})"


def reports(r, tok):
    """Each run of a reporting program whose token matches: dict(argv0, cwd, args)."""
    out, cur = [], None
    for line in r.stdout.splitlines():
        if line.startswith("RAN argv0="):
            cur = {"argv0": line[10:], "args": []}
        elif cur is not None and line.startswith("RAN cwd="):
            cur["cwd"] = line[8:]
        elif cur is not None and line.startswith("RAN arg="):
            cur["args"].append(line[8:])
        elif cur is not None and line.startswith("RAN token="):
            if line[10:] == tok:
                out.append(cur)
            cur = None
    return out


def report(r, tok, prog="the challenge program"):
    reps = reports(r, tok)
    assert reps, f"{prog} never ran {show(r)}"
    return reps[-1]


def commands(n):
    """Answer lines split into words like the shell does, globs left as typed (comments skipped)."""
    out = []
    for line in answer(n).read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        s = shlex.shlex(line, posix=True, punctuation_chars=True)
        s.whitespace_split = True
        try:
            out.append(list(s))
        except ValueError:
            out.append(line.split())
    return out


def args_of(n, name):
    """For every place the script calls a command ending in `name`: its argument words."""
    found = []
    for words in commands(n):
        for i, w in enumerate(words):
            if w.endswith(name):
                rest = []
                for a in words[i + 1:]:
                    if a in (";", "&&", "||", "|", "&", ">", "<", ">>", "2>"):
                        break
                    rest.append(a)
                found.append(rest)
    return found


def lines(r):
    return [x for x in r.stdout.splitlines() if x.strip()]

TREE = {'challenge/files/file_a': '', 'challenge/files/file_b': '', 'challenge/files/file_c': '', 'challenge/files/file_d': '', 'challenge/files/file_e': '', 'challenge/files/file_f': '', 'challenge/files/file_g': '', 'challenge/files/file_h': '', 'challenge/files/file_i': '', 'challenge/files/file_j': '', 'challenge/files/file_k': '', 'challenge/files/file_l': '', 'challenge/files/file_m': '', 'challenge/files/file_n': '', 'challenge/files/file_o': '', 'challenge/files/file_p': '', 'challenge/files/file_q': '', 'challenge/files/file_r': '', 'challenge/files/file_s': '', 'challenge/files/file_t': '', 'challenge/files/file_u': '', 'challenge/files/file_v': '', 'challenge/files/file_w': '', 'challenge/files/file_x': '', 'challenge/files/file_y': '', 'challenge/files/file_z': '', 'challenge/words/amazing': '', 'challenge/words/beautiful': '', 'challenge/words/challenging': '', 'challenge/words/delightful': '', 'challenge/words/educational': '', 'challenge/words/fantastic': '', 'challenge/words/great': '', 'challenge/words/happy': '', 'challenge/words/incredible': '', 'challenge/words/jovial': '', 'challenge/words/kind': '', 'challenge/words/laughing': '', 'challenge/words/magical': '', 'challenge/words/nice': '', 'challenge/words/optimistic': '', 'challenge/words/pwning': '', 'challenge/words/queenly': '', 'challenge/words/radiant': '', 'challenge/words/splendid': '', 'challenge/words/thrilling': '', 'challenge/words/uplifting': '', 'challenge/words/victorious': '', 'challenge/words/wonderful': '', 'challenge/words/xenial': '', 'challenge/words/youthful': '', 'challenge/words/zesty': '', 'challenge/tabfiles/hack-the-planet': '', 'challenge/tabfiles/pwn': '', 'challenge/tabfiles/pwn-college': '', 'challenge/tabfiles/pwn-the-planet': '', 'challenge/tabfiles/pwncollege-family': '', 'challenge/tabfiles/pwncollege-flamingo': '', 'challenge/tabfiles/pwncollege-flyswatter': '', 'challenge/tabfiles/pwncollege-hacking': '', 'challenge/pwncollege': 'academy{practice_tab}\n', 'cache/.keep': ''}
PROGS = {'challenge/run': '#!/bin/bash\necho "(this program reports how you ran it; ./check reads the RAN lines)" >&2\nprintf \'RAN argv0=%s\\n\' "$0"\nprintf \'RAN cwd=%s\\n\' "$(pwd -P)"\nfor a in "$@"; do printf \'RAN arg=%s\\n\' "$a"; done\nprintf \'RAN token=%s\\n\' "${TOKEN:-practice}"\n', 'bin/pwncollege-practice': '#!/bin/bash\necho "you found me"\n'}
PRACTICE = {}


WORDS = ['amazing', 'beautiful', 'challenging', 'delightful', 'educational', 'fantastic', 'great', 'happy', 'incredible', 'jovial', 'kind', 'laughing', 'magical', 'nice', 'optimistic', 'pwning', 'queenly', 'radiant', 'splendid', 'thrilling', 'uplifting', 'victorious', 'wonderful', 'xenial', 'youthful', 'zesty']
TABFILES = ['hack-the-planet', 'pwn', 'pwn-college', 'pwn-the-planet', 'pwncollege-family', 'pwncollege-flamingo', 'pwncollege-flyswatter', 'pwncollege-hacking']

def cd_args(n):
    return [a[0] for a in args_of(n, "cd") if a]

def run_args(n):
    found = args_of(n, "challenge/run")
    assert found, "call \"$DOJO/challenge/run\" in your script"
    return found[-1]

def glob_run(n, cwd_rel, want, check_arg):
    root = dojo()
    r, tok = go(n, root)
    rep = report(r, tok)
    wcwd = str(root / cwd_rel) if cwd_rel else str(root / "home/hacker")
    assert rep["cwd"] == wcwd, f"run it from {cwd_rel and '$DOJO/' + cwd_rel or 'your home directory'} (it ran in {rep['cwd']})"
    args = run_args(n)
    assert len(args) == 1, f"pass exactly 1 argument, and make it a glob. You typed {args}"
    check_arg(args[0])
    want = [w.replace("@ROOT@", str(root)) for w in want]
    assert rep["args"] == want, f"your glob expanded to {[a.replace(str(root), '$DOJO') for a in rep['args']]}"
    return args[0]

def cd_glob(n, rule):
    root = dojo()
    r, tok = go(n, root)
    rep = report(r, tok)
    assert rep["cwd"] == str(root / "challenge"), f"cd into $DOJO/challenge before running it (it ran in {rep['cwd']})"
    globs = [a for a in cd_args(n) if a.startswith("$DOJO/") or a.startswith("${DOJO}/")]
    assert globs, 'use cd "$DOJO"/GLOB'
    rule(globs[-1].split("/", 1)[1])

@task("1 matching with *")
def _():
    def rule(g):
        assert "*" in g, f"use * in the cd argument after $DOJO/. You typed {g!r}"
        assert len(g) <= 4, f"the part after $DOJO/ must have 4 characters or fewer. Yours is {g!r}"
    cd_glob(1, rule)

@task("2 matching with ?")
def _():
    def rule(g):
        assert "?" in g and "*" not in g, f"use ? and do not use *. You typed {g!r}"
        assert "c" not in g and "l" not in g, f"change every c and l to ?. You typed {g!r}"
    cd_glob(2, rule)

@task("3 matching with []")
def _():
    def rule(a):
        assert "[" in a, f"use a [] glob. You typed {a!r}"
    glob_run(3, "challenge/files", ["file_a", "file_b", "file_h", "file_s"], rule)

@task("4 matching paths with []")
def _():
    def rule(a):
        assert "[" in a, f"use a [] glob. You typed {a!r}"
    glob_run(4, "", [f"@ROOT@/challenge/files/file_{c}" for c in "abhs"], rule)

@task("5 multiple globs")
def _():
    def rule(a):
        assert len(a) <= 3 and a.count("*") == 2, f"use a glob of 3 characters or fewer, with 2 *. You typed {a!r}"
    glob_run(5, "challenge/words", [w for w in WORDS if "p" in w], rule)

@task("6 mixing globs")
def _():
    def rule(a):
        assert len(a) <= 6 and "[" in a, f"use a glob with [] of 6 characters or fewer. You typed {a!r}"
    glob_run(6, "challenge/words", ["challenging", "educational", "pwning"], rule)

@task("7 exclusionary globbing")
def _():
    def rule(a):
        assert "[!" in a or "[^" in a, f"use an exclusion glob like [!...]. You typed {a!r}"
    glob_run(7, "challenge/words", [w for w in WORDS if w[0] not in "pwn"], rule)

@task("8 tab completion")
def _():
    name = "pwncollege_" + word()
    root = dojo({"challenge/" + name: "x\n"})
    (root / "challenge/pwncollege").unlink()
    r, _ = go(8, root)
    assert lines(r) == [f"{root}/challenge/{name}"], f"print the completions of $DOJO/challenge/pwnc (the check renames the file) {show(r)}"

@task("9 multiple options for tab completion")
def _():
    extra = "pwncollege-f" + word(5)
    root = dojo({"challenge/tabfiles/" + extra: ""})
    want = sorted(f"{root}/challenge/tabfiles/{t}" for t in TABFILES + [extra] if t.startswith("pwncollege-f"))
    r, _ = go(9, root)
    assert sorted(lines(r)) == want, f"expected the {len(want)} completions of $DOJO/challenge/tabfiles/pwncollege-f {show(r)}"

@task("10 tab completion on commands")
def _():
    name = "pwncollege-" + word()
    root = dojo()
    (root / "bin/pwncollege-practice").rename(root / "bin" / name)
    r, _ = go(10, root)
    assert set(lines(r)) == {name}, f"print the command names that start with pwncollege (the check renames it to {name}) {show(r)}"

print(f"{len(passed)}/{len(passed) + len(failed)} tasks pass")
if failed:
    print("Not yet:")
    for line in failed:
        print("  -", line)
    raise SystemExit(1)
print("CHECK_OK")
