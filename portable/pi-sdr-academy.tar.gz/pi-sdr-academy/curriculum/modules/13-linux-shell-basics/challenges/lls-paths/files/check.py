#!/usr/bin/env python3
"""Run with ./check. Tests each task in answers/task1.sh to answers/task8.sh and lists what still fails."""
import sys
sys.path.insert(0, ".")
sys.dont_write_bytecode = True
failed, passed = [], []

def task(name):
    def run(fn):
        try:
            fn()
            passed.append(name)
        except NotImplementedError:
            failed.append(f"{name}: not implemented yet")
        except Exception as exc:  # show the learner what broke
            failed.append(f"{name}: {type(exc).__name__}: {exc}")
        return fn
    return run

import os, pathlib, shutil, subprocess, tempfile

HERE = pathlib.Path(".").resolve()

def answer(n):
    """Path of answers/taskN.sh; NotImplementedError while it still says TODO."""
    p = HERE / "answers" / f"task{n}.sh"
    if not p.exists() or "TODO" in p.read_text():
        raise NotImplementedError
    return p

def sandbox(files=None):
    """Fresh temp dir filled with {relative path: text or bytes}. Returns its Path."""
    # ponytail: sandboxes live in /tmp and are left for the OS to clean.
    d = pathlib.Path(tempfile.mkdtemp(prefix="academy-sh-"))
    for rel, data in (files or {}).items():
        p = d / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data) if isinstance(data, bytes) else p.write_text(data)
    return d

def run(n, cwd=None, stdin=None, env=None, args=(), timeout=20):
    """Run answers/taskN.sh with bash in cwd (a new sandbox by default).
    Returns (CompletedProcess, cwd). HOME points at the sandbox unless env overrides it."""
    cwd = cwd or sandbox()
    e = {**os.environ, "HOME": str(cwd), **(env or {})}
    r = subprocess.run(["bash", str(answer(n)), *args], cwd=cwd, input=stdin, env=e,
                       capture_output=True, text=True, timeout=timeout)
    return r, cwd

import random, re, shlex
RNG = random.Random(102)


def word(n=8):
    return "".join(RNG.choice("abcdefghijklmnopqrstuvwxyz0123456789") for _ in range(n))


def secret(tag="s"):
    return "academy{%s_%s}" % (tag, word(12))


def dojo(tree=None, subs=None):
    """Fresh fake root from TREE and PROGS (plus overrides). Returns its resolved Path."""
    root = sandbox({**TREE, **(tree or {})}).resolve()
    for d in ("home/hacker", "tmp"):
        (root / d).mkdir(parents=True, exist_ok=True)
    allsubs = {**PRACTICE, **(subs or {})}
    for rel, body in PROGS.items():
        for k, v in allsubs.items():
            body = body.replace(k, v)
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(body)
        p.chmod(0o755)
    return root


def go(n, root, cwd=None, stdin=None, env=None, timeout=20):
    """Run answers/taskN.sh the way the README describes. Returns (result, token)."""
    home = root / "home/hacker"
    tok = word()
    e = {"DOJO": str(root), "HOME": str(home), "TOKEN": tok,
         "PATH": str(root / "bin") + os.pathsep + os.environ.get("PATH", ""), **(env or {})}
    r, _ = run(n, cwd=cwd or home, stdin=stdin, env=e, timeout=timeout)
    return r, tok


def show(r):
    return f"(stdout: {r.stdout[-300:]!r}, stderr: {r.stderr[-300:]!r})"


def reports(r, tok):
    """Each run of a reporting program whose token matches: dict(argv0, cwd, args)."""
    out, cur = [], None
    for line in r.stdout.splitlines():
        if line.startswith("RAN argv0="):
            cur = {"argv0": line[10:], "args": []}
        elif cur is not None and line.startswith("RAN cwd="):
            cur["cwd"] = line[8:]
        elif cur is not None and line.startswith("RAN arg="):
            cur["args"].append(line[8:])
        elif cur is not None and line.startswith("RAN token="):
            if line[10:] == tok:
                out.append(cur)
            cur = None
    return out


def report(r, tok, prog="the challenge program"):
    reps = reports(r, tok)
    assert reps, f"{prog} never ran {show(r)}"
    return reps[-1]


def commands(n):
    """Answer lines split into words like the shell does, globs left as typed (comments skipped)."""
    out = []
    for line in answer(n).read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        s = shlex.shlex(line, posix=True, punctuation_chars=True)
        s.whitespace_split = True
        try:
            out.append(list(s))
        except ValueError:
            out.append(line.split())
    return out


def args_of(n, name):
    """For every place the script calls a command ending in `name`: its argument words."""
    found = []
    for words in commands(n):
        for i, w in enumerate(words):
            if w.endswith(name):
                rest = []
                for a in words[i + 1:]:
                    if a in (";", "&&", "||", "|", "&", ">", "<", ">>", "2>"):
                        break
                    rest.append(a)
                found.append(rest)
    return found


def lines(r):
    return [x for x in r.stdout.splitlines() if x.strip()]

TREE = {'var/lib/academy/.keep': '', 'etc/.keep': '', 'usr/share/.keep': '', 'var/log/.keep': '', 'home/.keep': '', 'tmp/.keep': ''}
PROGS = {'pwn': '#!/bin/bash\necho "(this program reports how you ran it; ./check reads the RAN lines)" >&2\nprintf \'RAN argv0=%s\\n\' "$0"\nprintf \'RAN cwd=%s\\n\' "$(pwd -P)"\nfor a in "$@"; do printf \'RAN arg=%s\\n\' "$a"; done\nprintf \'RAN token=%s\\n\' "${TOKEN:-practice}"\n', 'challenge/run': '#!/bin/bash\necho "(this program reports how you ran it; ./check reads the RAN lines)" >&2\nprintf \'RAN argv0=%s\\n\' "$0"\nprintf \'RAN cwd=%s\\n\' "$(pwd -P)"\nfor a in "$@"; do printf \'RAN arg=%s\\n\' "$a"; done\nprintf \'RAN token=%s\\n\' "${TOKEN:-practice}"\n', 'challenge/position': '#!/bin/bash\necho "(this program reports how you ran it; ./check reads the RAN lines)" >&2\nprintf \'RAN argv0=%s\\n\' "$0"\nprintf \'RAN cwd=%s\\n\' "$(pwd -P)"\nfor a in "$@"; do printf \'RAN arg=%s\\n\' "$a"; done\nprintf \'RAN token=%s\\n\' "${TOKEN:-practice}"\n', 'challenge/tour': '#!/bin/bash\necho "(this program reports how you ran it; ./check reads the RAN lines)" >&2\nprintf \'RAN argv0=%s\\n\' "$0"\nprintf \'RAN cwd=%s\\n\' "$(pwd -P)"\nfor a in "$@"; do printf \'RAN arg=%s\\n\' "$a"; done\nprintf \'RAN token=%s\\n\' "${TOKEN:-practice}"\n', 'challenge/copyflag': '#!/bin/bash\ncase "$1" in\n    /*) ;;\n    *) echo "copyflag: give me an ABSOLUTE path (it must start with /), got: \'$1\'" >&2; exit 1;;\nesac\ncase "$1" in\n    "$HOME"/*) ;;\n    *) echo "copyflag: the path must be inside your home directory ($HOME)" >&2; exit 1;;\nesac\necho "@SECRET@" > "$1" && echo "copied the secret to $1"\n'}
PRACTICE = {'@SECRET@': 'academy{practice_home}'}


TOUR = ['etc', 'usr/share', 'var/log', 'home', 'tmp']

@task("1 the root: absolute path")
def _():
    root = dojo()
    r, tok = go(1, root)
    rep = report(r, tok, "$DOJO/pwn")
    assert rep["argv0"].startswith("/"), f"run it by its absolute path. You used {rep['argv0']!r}"
    assert rep["argv0"] == f"{root}/pwn", f"run $DOJO/pwn. You ran {rep['argv0']!r}"

@task("2 program and absolute paths")
def _():
    root = dojo()
    r, tok = go(2, root)
    rep = report(r, tok, "$DOJO/challenge/run")
    assert rep["argv0"] == f"{root}/challenge/run", f"use the absolute path \"$DOJO/challenge/run\". You used {rep['argv0']!r}"

@task("3 position thy self")
def _():
    root = dojo()
    r, tok = go(3, root)
    rep = report(r, tok, "$DOJO/challenge/position")
    want = str(root / "var/lib/academy")
    assert rep["cwd"] == want, f"it ran in {rep['cwd']}, but must run with working directory $DOJO/var/lib/academy"

@task("4 position elsewhere, five times")
def _():
    root = dojo()
    r, tok = go(4, root)
    cwds = [x["cwd"] for x in reports(r, tok) if x["argv0"].endswith("challenge/tour")]
    want = [str(root / d) for d in TOUR]
    assert cwds == want, f"tour ran from {[c.replace(str(root), '$DOJO') for c in cwds]}, expected {['$DOJO/' + d for d in TOUR]}"

@task("5 implicit relative path from the root")
def _():
    root = dojo()
    r, tok = go(5, root)
    rep = report(r, tok, "challenge/run")
    assert rep["cwd"] == str(root), f"cd to \"$DOJO\" first (it ran in {rep['cwd']})"
    assert rep["argv0"] == "challenge/run", f"call it as challenge/run. You used {rep['argv0']!r}"

@task("6 explicit relative path with .")
def _():
    root = dojo()
    r, tok = go(6, root)
    rep = report(r, tok, "challenge/run")
    assert rep["cwd"] == str(root), f"cd to \"$DOJO\" first (it ran in {rep['cwd']})"
    a = rep["argv0"]
    assert not a.startswith("/"), f"use a relative path. You used {a!r}"
    assert "." in a.split("/"), f"put a `.` in the relative path. You used {a!r}"

@task("7 run a program in the current directory")
def _():
    root = dojo()
    r, tok = go(7, root)
    rep = report(r, tok, "run")
    assert rep["cwd"] == str(root / "challenge"), f"cd to \"$DOJO/challenge\" first (it ran in {rep['cwd']})"
    assert rep["argv0"] == "./run", f"call it as ./run. You used {rep['argv0']!r}"

@task("8 home sweet home")
def _():
    s = secret("home")
    root = dojo(subs={"@SECRET@": s})
    r, _ = go(8, root)
    home = root / "home/hacker"
    got = [p for p in home.iterdir() if p.is_file() and p.read_text().strip() == s]
    assert got, f"no file in your home directory holds the secret {show(r)}"
    ok = [a for a in args_of(8, "copyflag") if a and a[0].startswith("~/") and len(a[0]) <= 3]
    assert ok, "pass copyflag an argument that starts with ~/ and that you type with 3 characters or fewer, like ~/x"

print(f"{len(passed)}/{len(passed) + len(failed)} tasks pass")
if failed:
    print("Not yet:")
    for line in failed:
        print("  -", line)
    raise SystemExit(1)
print("CHECK_OK")
