#!/usr/bin/env python3
"""Run with ./check. Tests each task in answers/task1.sh to answers/task15.sh and lists what still fails."""
import sys
sys.path.insert(0, ".")
sys.dont_write_bytecode = True
failed, passed = [], []

def task(name):
    def run(fn):
        try:
            fn()
            passed.append(name)
        except NotImplementedError:
            failed.append(f"{name}: not implemented yet")
        except Exception as exc:  # show the learner what broke
            failed.append(f"{name}: {type(exc).__name__}: {exc}")
        return fn
    return run

import os, pathlib, shutil, subprocess, tempfile

HERE = pathlib.Path(".").resolve()

def answer(n):
    """Path of answers/taskN.sh; NotImplementedError while it still says TODO."""
    p = HERE / "answers" / f"task{n}.sh"
    if not p.exists() or "TODO" in p.read_text():
        raise NotImplementedError
    return p

def sandbox(files=None):
    """Fresh temp dir filled with {relative path: text or bytes}. Returns its Path."""
    # ponytail: sandboxes live in /tmp and are left for the OS to clean.
    d = pathlib.Path(tempfile.mkdtemp(prefix="academy-sh-"))
    for rel, data in (files or {}).items():
        p = d / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data) if isinstance(data, bytes) else p.write_text(data)
    return d

def run(n, cwd=None, stdin=None, env=None, args=(), timeout=20):
    """Run answers/taskN.sh with bash in cwd (a new sandbox by default).
    Returns (CompletedProcess, cwd). HOME points at the sandbox unless env overrides it."""
    cwd = cwd or sandbox()
    e = {**os.environ, "HOME": str(cwd), **(env or {})}
    r = subprocess.run(["bash", str(answer(n)), *args], cwd=cwd, input=stdin, env=e,
                       capture_output=True, text=True, timeout=timeout)
    return r, cwd

import random, re, shlex
RNG = random.Random(103)


def word(n=8):
    return "".join(RNG.choice("abcdefghijklmnopqrstuvwxyz0123456789") for _ in range(n))


def secret(tag="s"):
    return "academy{%s_%s}" % (tag, word(12))


def dojo(tree=None, subs=None):
    """Fresh fake root from TREE and PROGS (plus overrides). Returns its resolved Path."""
    root = sandbox({**TREE, **(tree or {})}).resolve()
    for d in ("home/hacker", "tmp"):
        (root / d).mkdir(parents=True, exist_ok=True)
    allsubs = {**PRACTICE, **(subs or {})}
    for rel, body in PROGS.items():
        for k, v in allsubs.items():
            body = body.replace(k, v)
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(body)
        p.chmod(0o755)
    return root


def go(n, root, cwd=None, stdin=None, env=None, timeout=20):
    """Run answers/taskN.sh the way the README describes. Returns (result, token)."""
    home = root / "home/hacker"
    tok = word()
    e = {"DOJO": str(root), "HOME": str(home), "TOKEN": tok,
         "PATH": str(root / "bin") + os.pathsep + os.environ.get("PATH", ""), **(env or {})}
    r, _ = run(n, cwd=cwd or home, stdin=stdin, env=e, timeout=timeout)
    return r, tok


def show(r):
    return f"(stdout: {r.stdout[-300:]!r}, stderr: {r.stderr[-300:]!r})"


def reports(r, tok):
    """Each run of a reporting program whose token matches: dict(argv0, cwd, args)."""
    out, cur = [], None
    for line in r.stdout.splitlines():
        if line.startswith("RAN argv0="):
            cur = {"argv0": line[10:], "args": []}
        elif cur is not None and line.startswith("RAN cwd="):
            cur["cwd"] = line[8:]
        elif cur is not None and line.startswith("RAN arg="):
            cur["args"].append(line[8:])
        elif cur is not None and line.startswith("RAN token="):
            if line[10:] == tok:
                out.append(cur)
            cur = None
    return out


def report(r, tok, prog="the challenge program"):
    reps = reports(r, tok)
    assert reps, f"{prog} never ran {show(r)}"
    return reps[-1]


def commands(n):
    """Answer lines split into words like the shell does, globs left as typed (comments skipped)."""
    out = []
    for line in answer(n).read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        s = shlex.shlex(line, posix=True, punctuation_chars=True)
        s.whitespace_split = True
        try:
            out.append(list(s))
        except ValueError:
            out.append(line.split())
    return out


def args_of(n, name):
    """For every place the script calls a command ending in `name`: its argument words."""
    found = []
    for words in commands(n):
        for i, w in enumerate(words):
            if w.endswith(name):
                rest = []
                for a in words[i + 1:]:
                    if a in (";", "&&", "||", "|", "&", ">", "<", ">>", "2>"):
                        break
                    rest.append(a)
                found.append(rest)
    return found


def lines(r):
    return [x for x in r.stdout.splitlines() if x.strip()]

TREE = {'home/hacker/flag': 'academy{practice_cat}\n', 'flag': 'academy{practice_root_flag}\n', 'opt/vault/a1/b2/c3/flag': 'academy{practice_chase}\n', 'challenge/data.txt': 'tone radio gain sdr pi\nfft pi tone band sdr\nfft wave sdr pi gain\ngain pi wave pi fft\ngain sdr band pi wave\nband sdr band band gain\nsdr wave sdr fft radio\nnoise gain radio fft pi\nband noise fft radio pi\nband band wave tone pi\nfft pi band sdr band\nwave iq fft gain tone\niq band iq tone noise\nwave radio wave pi band\nnoise fft iq tone iq\nnoise band pi pi fft\ngain radio tone radio iq\ngain sdr pi fft band\ntone tone tone band iq\nband iq pi pi noise\niq pi sdr noise band\niq noise gain tone sdr\niq tone radio band pi\niq sdr wave noise radio\nwave gain gain iq pi\nradio iq gain fft noise\nradio gain fft noise gain\ntone gain wave radio pi\nradio radio wave wave sdr\niq band radio noise noise\nsdr radio gain fft tone\nband band tone radio fft\nband sdr iq fft gain\ngain gain gain pi iq\ngain sdr wave pi wave\niq radio pi tone band\nsdr pi sdr band radio\nfft pi tone band sdr\npi wave band gain radio\nnoise tone band tone iq\npi pi iq iq iq\niq noise pi radio pi\ntone noise iq radio fft\nsdr wave fft tone radio\nfft sdr fft noise pi\nnoise fft tone radio tone\nwave fft fft fft tone\nwave band wave wave gain\nwave wave fft iq tone\nsdr sdr noise iq noise\nwave band tone iq tone\ntone pi wave pi wave\niq wave tone wave iq\nband band sdr iq tone\npi pi gain wave iq\nradio gain tone pi gain\niq gain pi radio radio\nradio sdr radio band iq\nradio band band iq tone\nradio fft fft radio sdr\nsdr pi fft radio gain\nwave wave sdr noise wave\nnoise fft wave band tone\nnoise fft gain radio sdr\ntone iq band fft gain\nfft radio fft radio fft\nfft sdr iq radio band\nsdr radio radio radio iq\nband pi fft sdr tone\nfft fft fft iq pi\nfft sdr wave wave noise\nsdr pi fft iq fft\nsdr pi iq tone band\nfft band fft wave noise\niq fft fft iq fft\nwave fft noise fft wave\niq radio gain pi gain\niq tone pi wave gain\npi wave noise pi radio\ntone radio noise radio iq\nwave pi gain iq radio\nwave radio gain fft gain\ntone gain wave tone tone\npi tone sdr tone fft\niq iq sdr gain tone\nfft band noise fft pi\npi wave pi pi noise\nnoise sdr radio noise radio\ngain noise gain radio fft\nfft band iq tone pi\nnoise sdr radio gain pi\nnoise sdr pi noise pi\nband wave pi noise pi\niq sdr tone fft gain\nnoise band radio sdr fft\nwave pi radio noise sdr\nradio wave noise noise fft\nwave noise iq fft radio\nnoise tone sdr noise sdr\nsdr sdr fft fft wave\nfft iq wave iq pi\ngain iq fft gain fft\nnoise wave wave tone wave\nradio gain tone sdr radio\nsdr pi noise gain radio\nsdr pi gain fft noise\nband wave noise sdr iq\nradio radio noise iq sdr\nnoise tone tone fft tone\nwave sdr noise wave tone\nradio sdr tone gain pi\niq noise fft wave wave\nfft sdr pi noise pi\nradio gain band sdr gain\nsdr noise noise wave pi\nband fft radio band gain\ntone iq radio noise band\nradio sdr fft gain fft\nradio fft fft band sdr\nband wave pi sdr sdr\nradio tone pi gain iq\nfft sdr sdr fft wave\niq noise sdr iq pi\nfft fft pi fft pi\niq noise pi noise wave\nwave wave iq iq gain\npi iq noise sdr band\nwave pi band radio tone\nnoise noise band band radio\nsdr iq sdr iq noise\npi wave iq noise fft\nnoise iq iq iq pi\nfft wave noise pi iq\nsdr noise iq pi fft\niq noise gain wave wave\npi band pi radio fft\nnoise tone radio band fft\nnoise pi tone wave iq\niq gain sdr radio sdr\niq iq gain noise radio\ngain tone gain tone pi\ntone sdr tone tone gain\npi wave sdr noise noise\ntone pi gain gain band\npi tone gain noise sdr\nnoise pi sdr noise radio\nwave noise gain fft tone\nwave tone gain sdr gain\nfft fft wave pi sdr\ngain iq band radio noise\niq sdr fft radio radio\niq gain tone noise noise\nnoise noise gain wave noise\niq fft gain pi radio\nradio pi wave fft iq\nfft wave iq tone iq\ngain radio fft wave wave\npi radio tone fft pi\ntone wave tone noise band\nwave sdr gain gain gain\nfft wave gain noise tone\nsdr iq noise band tone\nradio fft fft wave pi\nnoise wave gain gain iq\ngain noise sdr radio sdr\ngain iq band iq sdr\npi gain fft iq iq\nwave pi wave radio radio\nfft pi iq pi fft\nsdr sdr radio wave band\nsdr noise radio noise fft\ngain pi pi pi noise\nfft band wave gain noise\nwave band sdr sdr fft\nnoise iq noise tone wave\niq fft wave fft wave\nsdr gain noise sdr sdr\nwave iq gain pi noise\nwave gain tone wave iq\nsdr tone gain tone gain\nwave sdr noise fft pi\nwave iq wave noise wave\nwave iq wave noise noise\npi band iq band radio\nwave iq gain sdr band\nradio gain sdr wave sdr\nband radio gain sdr sdr\nradio gain iq tone pi\npi radio tone wave radio\nfft iq sdr noise gain\ntone tone iq radio pi\nsdr pi noise pi tone\ngain pi fft wave gain\ntone noise gain pi sdr\niq wave tone fft iq\nwave tone tone iq sdr\ngain wave gain sdr gain\nsdr iq pi sdr noise\nwave pi band tone tone\nnoise tone band sdr noise\ntone noise noise sdr band\npi sdr wave pi iq\niq gain noise gain iq\nradio iq radio sdr noise\nradio band wave tone tone\niq tone band pi fft\nwave gain radio wave gain\npi sdr iq fft fft\ntone radio gain pi pi\nnoise band pi wave pi\ngain iq iq radio wave\nradio gain iq band wave\nfft pi noise noise noise\nband noise tone noise noise\nwave iq wave radio wave\nwave radio noise band wave\ntone pi gain noise wave\nfft fft wave pi iq\nsdr pi sdr iq wave\niq tone sdr noise wave\npi sdr wave band band\nwave pi tone fft radio\niq band noise sdr pi\nband band tone wave sdr\ntone tone radio sdr wave\nnoise sdr band wave sdr\ntone gain tone radio band\nnoise pi wave sdr iq\nfft iq pi gain pi\ngain fft radio fft pi\nradio gain noise gain noise\nnoise gain sdr noise band\ntone gain gain sdr tone\nwave gain gain wave sdr\ngain radio gain pi pi\ngain band tone iq radio\nradio sdr sdr fft radio\ngain pi band band tone\nfft radio radio tone noise\nradio fft radio pi pi\ngain iq wave noise radio\nsdr iq tone sdr band\ngain pi band radio wave\nband gain band wave iq\nradio band wave sdr gain\nfft radio gain tone pi\nradio wave wave sdr fft\nsdr tone pi gain band\niq fft noise gain noise\nband wave gain gain tone\niq fft iq radio sdr\nsdr band iq iq wave\niq band iq radio iq\ngain pi pi radio tone\ngain tone pi iq fft\nfft sdr sdr radio pi\ntone fft pi sdr fft\ngain radio sdr pi band\npi wave radio iq noise\nradio wave pi tone band\nnoise radio tone band noise\niq radio noise fft iq\nwave band noise band fft\nwave tone tone sdr wave\nradio gain radio noise tone\ngain radio noise pi fft\nsdr tone iq fft fft\nband pi noise fft gain\ntone noise gain tone band\nradio tone tone pi iq\nwave radio band sdr noise\nfft noise noise band tone\nsdr sdr wave radio noise\nband gain gain fft tone\nsdr radio iq wave band\nsdr sdr sdr sdr band\ntone noise pi fft tone\nfft wave gain band noise\nband radio wave tone band\niq radio radio sdr wave\nradio iq pi pi radio\nnoise gain noise sdr sdr\nfft tone band band iq\nband fft iq wave radio\nsdr sdr sdr fft sdr\ngain radio wave radio sdr\npi sdr band fft wave\nradio gain wave fft band\nfft gain band radio fft\nnoise pi noise sdr iq\nfft sdr gain gain iq\npi iq radio wave pi\nnoise wave sdr pi tone\nnoise sdr noise fft gain\nfft noise noise wave pi\nfft sdr radio noise wave\nwave radio tone wave gain\ntone band wave gain fft\niq iq fft sdr sdr\ngain wave band noise wave\ngain band band pi band\nradio radio sdr sdr pi\npi band radio tone radio\nsdr sdr sdr radio sdr\npi sdr pi band tone\nwave fft pi gain pi\nwave wave wave pi sdr\nsdr pi noise iq pi\nradio pi wave noise tone\ntone gain noise sdr tone\nnoise noise sdr tone tone\nband fft iq noise band\nsdr gain sdr gain fft\npi tone iq sdr fft\nband wave pi band noise\nradio gain sdr fft wave\nnoise sdr sdr tone iq\npi iq radio iq band\ntone fft noise band radio\nnoise wave wave iq radio\npi pi iq fft pi\ntone tone pi gain gain\npi gain sdr tone wave\nnoise noise gain fft fft\nradio gain wave iq radio\nfft band band sdr tone\nband tone fft radio iq\nfft tone radio iq iq\nnoise band wave radio tone\niq wave fft wave noise\nnoise band radio radio wave\ntone band fft tone radio\nwave tone wave noise pi\nradio pi wave gain radio\nradio noise noise gain noise\nwave pi pi noise wave\ngain iq sdr sdr gain\ngain wave fft noise iq\nsdr radio noise band gain\nsdr wave gain band band\ngain wave band wave radio\npi iq gain tone noise\npi gain wave gain radio\nnoise gain iq iq sdr\nband gain fft radio tone\nsdr gain iq pi sdr\nnoise fft wave radio wave\nfft tone pi band iq\nfft wave iq fft sdr\ntone fft tone gain iq\nwave radio gain fft pi\nband tone sdr noise noise\ngain gain sdr sdr pi\ngain gain tone band noise\npi wave noise gain fft\nwave gain iq wave radio\nradio pi wave iq fft\nwave radio tone gain iq\nnoise fft radio iq tone\nwave noise gain noise gain\nradio iq sdr noise tone\nwave noise tone iq iq\ngain band pi tone radio\nnoise gain sdr pi band\ntone radio fft tone band\nsdr sdr wave pi noise\nnoise band pi band radio\nwave radio iq tone radio\nwave gain fft radio band\nband pi fft noise wave\niq wave fft pi iq\npi fft pi noise gain\nwave radio iq iq fft\nsdr iq iq radio iq\nwave iq radio fft band\nsdr radio tone iq band\niq noise iq tone gain\ngain pi radio tone sdr\nsdr band sdr tone pi\nfft iq iq radio sdr\nwave gain radio tone pi\ntone tone iq fft fft\nwave noise gain tone gain\nnoise fft sdr noise noise\ntone iq gain tone fft\nnoise fft tone wave iq\npi tone wave tone noise\nradio band pi sdr gain\nfft gain fft band sdr\ngain noise pi sdr sdr\nwave iq band sdr fft\nfft band gain band radio\nband pi wave sdr iq\nradio pi radio sdr gain\npi sdr tone radio noise\nfft noise noise radio gain\nsdr tone sdr gain band\nband sdr iq band fft\nsdr pi gain band gain\niq pi sdr gain band\nband radio iq gain fft\npi pi iq wave radio\nsdr gain sdr sdr pi\npi wave pi radio iq\nsdr noise band wave iq\nradio sdr tone radio pi\nnoise fft iq iq noise\nsdr sdr sdr sdr sdr\nband pi gain noise noise\nband radio iq band sdr\ntone tone band iq iq\nradio radio pi tone radio\ngain iq gain iq noise\nband tone noise noise sdr\nband band tone band sdr\nradio band noise band gain\nwave gain gain gain band\nwave iq noise sdr tone\nnoise noise gain radio band\nsdr noise radio band radio\nnoise fft iq tone fft\npi fft fft iq gain\nwave wave noise band sdr\ngain iq wave noise band\nsdr gain iq fft pi\nfft tone pi wave gain\nband fft noise fft tone\niq fft band wave wave\nwave wave pi radio noise\ntone band band tone gain\nfft radio wave sdr iq\ntone pi tone iq pi\nradio tone band sdr tone\nnoise fft band sdr pi\nsdr wave band iq band\nband wave noise noise gain\npi iq band band radio\nnoise sdr tone wave radio\ngain pi sdr sdr sdr\nfft tone iq iq pi\nband gain pi pi noise\ntone band wave pi fft\ngain radio iq radio tone\nwave wave radio sdr noise\ntone sdr fft sdr sdr\nnoise fft iq sdr pi\nradio tone sdr wave noise\nband band iq pi iq\ntone tone noise gain pi\ntone iq gain radio iq\nwave radio sdr iq wave\nsdr radio wave pi band\ntone radio iq pi gain\nsdr pi iq tone tone\nwave iq pi tone radio\ntone wave sdr radio iq\nfft radio iq radio noise\ngain gain wave radio sdr\nnoise band noise tone radio\nnoise iq pi tone iq\niq pi radio fft sdr\nwave fft iq noise pi\nnoise wave tone gain noise\nwave wave pi gain noise\ngain radio sdr noise radio\nsdr iq fft tone fft\nradio iq sdr fft noise\nradio tone gain sdr gain\nwave noise band radio radio\nradio fft wave radio wave\nband pi pi band iq\nnoise radio wave radio band\nwave band noise wave sdr\npi fft gain sdr fft\ntone tone noise iq pi\nsdr gain iq radio noise\nwave radio band tone sdr\nradio tone band band sdr\ntone fft iq fft pi\npi tone wave tone gain\nband sdr noise pi iq\niq fft sdr fft fft\nradio sdr wave pi wave\nband radio radio pi noise\nnoise fft sdr sdr pi\nwave noise sdr band band\niq fft wave iq pi\ntone pi radio sdr noise\npi iq iq band fft\nnoise pi pi pi gain\nradio fft band wave wave\nradio band iq gain radio\nsdr gain gain band band\nfft sdr gain sdr tone\ntone gain wave tone gain\nband tone gain fft sdr\ntone fft radio tone wave\ngain sdr tone pi fft\nradio pi tone gain wave\nfft sdr wave radio gain\ngain iq sdr sdr sdr\nband noise band noise fft\nsdr band pi noise pi\nfft sdr gain wave sdr\nnoise pi noise tone radio\npi sdr band fft noise\npi iq band fft radio\niq pi fft radio noise\ngain band noise noise wave\npi fft noise iq band\nband wave gain wave fft\ntone iq fft noise band\niq iq noise sdr wave\ntone wave wave fft fft\ngain band gain sdr tone\nradio wave tone fft tone\niq noise noise wave noise\nsdr sdr radio fft pi\nband tone iq sdr fft\ngain iq tone pi fft\nwave radio gain tone tone\nradio wave band band noise\nfft pi iq noise radio\ngain pi sdr gain fft\nband pi iq gain band\nradio gain noise band band\npi gain iq iq noise\ntone noise tone gain fft\nfft band gain tone sdr\niq gain iq noise radio\nfft noise radio gain band\ngain band wave pi tone\ntone band wave tone wave\ngain sdr sdr sdr noise\nband iq noise fft noise\nfft band gain fft fft\ngain gain iq tone sdr\nband tone iq sdr pi\nfft wave pi gain tone\nfft gain fft band radio\nwave gain iq gain iq\nband band tone fft pi\nradio tone tone tone pi\nnoise fft radio pi noise\ntone fft gain radio fft\nnoise fft wave fft wave\ngain radio sdr band band\npi tone band sdr gain\nsdr sdr noise fft sdr\nnoise gain pi band sdr\nsdr wave radio iq fft\nband noise fft fft radio\nband wave gain band pi\nradio radio fft fft pi\nsdr pi pi radio fft\niq iq band gain sdr\nsdr band tone radio wave\ntone noise radio sdr noise\npi band pi tone wave\niq band gain sdr sdr\nwave gain band sdr iq\nsdr band wave wave wave\nsdr radio band radio tone\nsdr iq noise gain band\nnoise iq pi wave gain\nband wave gain noise gain\niq sdr wave pi radio\nradio tone gain radio sdr\nnoise gain fft tone pi\ntone fft gain tone gain\npi pi gain tone fft\nwave gain wave iq noise\ntone wave gain sdr noise\nsdr tone radio wave radio\npi wave noise fft radio\nfft iq iq wave radio\ntone tone wave gain gain\nband wave noise iq fft\nwave wave iq radio noise\nband iq band tone fft\nwave gain band fft wave\nradio pi fft pi fft\nnoise gain sdr band radio\nnoise sdr gain pi radio\nwave tone wave pi pi\nfft tone fft noise wave\npi noise pi wave noise\nradio gain noise tone gain\niq radio noise radio sdr\ntone tone gain sdr iq\nwave gain tone pi radio\nnoise pi noise band wave\nsdr gain sdr band radio\ngain wave noise radio gain\nsdr fft noise radio band\nwave band iq fft noise\ngain band tone sdr pi\nnoise sdr band band sdr\nwave pi sdr tone wave\ntone pi gain gain band\nwave noise fft pi tone\ngain iq tone fft iq\nfft sdr wave gain fft\nradio iq wave sdr fft\nnoise radio fft radio wave\nfft noise wave sdr radio\ntone tone gain pi wave\nnoise radio radio iq iq\nwave wave sdr fft iq\nradio tone noise radio radio\nband band wave tone pi\nfft gain radio radio band\niq gain wave pi noise\nsdr tone iq wave sdr\nsdr noise noise wave pi\nnoise iq pi radio tone\niq iq band tone noise\nradio fft pi sdr sdr\niq iq pi tone band\nnoise pi iq gain iq\nwave fft tone sdr tone\npi noise band noise wave\npi radio sdr sdr gain\nradio noise tone radio fft\nradio pi noise band tone\ngain radio tone tone wave\ntone radio fft tone noise\nwave sdr sdr pi band\ngain sdr wave iq gain\niq radio noise band band\npi radio wave radio radio\niq gain pi sdr iq\niq wave wave tone sdr\nsdr band fft gain radio\nnoise pi sdr fft gain\ntone pi iq sdr radio\nradio gain noise sdr iq\nband tone band wave iq\npi fft tone fft iq\ngain fft radio gain band\nband pi sdr tone band\nnoise band band gain tone\niq radio noise tone fft\nsdr wave wave iq pi\nradio band tone fft band\ngain tone fft wave band\niq gain noise pi wave\nradio wave fft pi wave\nnoise pi wave fft noise\niq wave fft iq wave\nfft band pi fft band\nband pi gain pi iq\nradio fft fft fft pi\nfft pi iq gain fft\nradio wave band iq pi\nradio tone band sdr gain\nwave sdr tone sdr sdr\nband wave iq noise pi\nradio gain pi band wave\nband pi tone radio tone\ntone sdr noise pi wave\ntone fft fft tone iq\nsdr band tone pi tone\nfft tone band pi sdr\nwave noise tone wave iq\nsdr band iq pi sdr\niq pi pi noise radio\nradio fft noise gain radio\nband noise fft noise iq\nsdr sdr tone radio iq\nfft iq sdr sdr pi\nradio band band gain iq\nradio iq gain wave band\nfft pi tone tone fft\nwave noise radio band band\nsdr wave radio tone iq\ntone band iq gain tone\ntone sdr tone band iq\ntone wave sdr wave iq\nband sdr radio radio noise\ngain noise pi fft noise\ntone band band fft band\nradio sdr fft pi wave\ngain band pi tone noise\nwave radio pi noise tone\ntone fft wave tone fft\ngain tone sdr tone tone\niq fft tone wave wave\ntone radio radio wave sdr\niq gain iq gain band\nnoise radio band pi radio\nnoise noise noise band fft\ntone pi wave band pi\nband radio noise band tone\niq tone gain pi iq\ntone radio noise noise fft\nsdr radio noise wave sdr\nwave sdr gain iq wave\nband noise fft pi wave\nwave sdr radio band sdr\npi pi band tone radio\nsdr wave noise fft sdr\ntone sdr wave tone tone\nsdr iq gain band tone\nradio sdr gain sdr pi\nband tone iq band gain\nnoise iq sdr sdr tone\nband tone sdr gain band\ntone radio pi sdr radio\nwave radio fft pi tone\ntone gain tone fft band\nfft radio band band tone\nwave band noise iq sdr\nnoise fft iq fft noise\ntone fft fft noise radio\nnoise sdr fft iq pi\ntone radio wave gain pi\nsdr band radio pi sdr\nfft fft wave fft radio\nnoise band tone radio radio\nradio fft sdr tone wave\niq iq wave tone gain\niq wave tone sdr pi\nsdr pi gain tone sdr\nwave band gain gain gain\nwave sdr noise sdr noise\ngain wave wave tone wave\ntone gain noise noise iq\nwave band radio iq noise\nradio noise noise pi tone\nsdr iq wave radio tone\nband band iq wave band\nsdr wave tone sdr iq\nradio gain radio noise sdr\npi radio sdr radio noise\nradio fft tone pi radio\niq gain pi gain tone\ngain tone sdr band wave\nwave sdr sdr radio fft\nband wave band gain pi\nsdr sdr tone pi pi\npi iq radio fft gain\nsdr radio wave fft radio\nfft fft pi fft tone\niq pi tone wave wave\npi noise radio sdr noise\nnoise pi sdr wave fft\nsdr gain fft tone noise\nsdr tone sdr iq fft\nnoise fft tone gain noise\ngain gain tone fft gain\ngain radio gain gain gain\nradio sdr wave band fft\nnoise band gain wave wave\npi pi band sdr sdr\ngain fft tone iq fft\ntone iq band sdr iq\niq fft tone band fft\ngain wave gain tone pi\ngain fft noise band tone\npi fft wave band noise\nnoise iq tone fft band\niq band wave radio pi\nfft tone fft wave fft\nradio tone wave radio radio\niq radio sdr tone gain\ntone gain pi gain radio\nnoise gain pi tone tone\nfft fft noise iq pi\nnoise gain noise iq pi\niq iq radio fft radio\nsdr radio tone iq fft\nwave band tone fft tone\ngain noise sdr fft wave\nsdr band noise sdr band\nradio noise fft noise tone\nnoise wave noise iq pi\nfft iq pi wave radio\ngain noise band tone sdr\niq gain tone sdr noise\ngain gain band noise tone\nwave gain band radio band\nwave band tone pi wave\ntone pi pi iq gain\ngain fft gain iq sdr\npi band band iq iq\ngain gain iq radio pi\niq gain iq radio fft\nsdr wave wave gain fft\nsdr noise fft tone gain\niq pi pi wave pi\nband sdr pi iq pi\nwave band iq sdr wave\ntone iq sdr fft gain\nband radio gain sdr radio\ntone tone wave fft sdr\nradio fft noise fft noise\npi tone gain noise noise\nfft gain fft gain sdr\nnoise noise wave gain gain\nfft noise noise wave radio\nsdr wave fft tone iq\niq band radio tone tone\nwave iq fft sdr tone\nsdr fft pi gain band\ntone sdr noise wave iq\nnoise wave wave band band\niq gain iq wave wave\nsdr radio gain pi sdr\nradio pi band iq radio\nsdr fft radio iq wave\nnoise wave fft radio radio\nwave fft pi iq pi\nwave pi sdr gain wave\nnoise iq gain radio sdr\nradio sdr radio iq noise\nwave band tone fft radio\nnoise noise tone fft wave\nradio wave gain sdr tone\ngain radio noise wave fft\npi wave iq radio radio\ngain tone gain pi sdr\ntone pi wave fft fft\npi noise iq tone sdr\niq pi wave iq noise\nnoise band band fft pi\nwave radio iq noise wave\nband noise sdr band band\npi sdr tone wave radio\nnoise sdr radio tone tone\niq iq wave tone tone\nradio pi noise pi fft\niq pi fft pi radio\nband gain iq sdr sdr\nsdr fft band pi gain\nradio gain band tone pi\ntone radio tone radio pi\ntone sdr iq noise radio\nnoise pi pi wave pi\nradio iq noise fft fft\npi tone iq wave radio\nband fft sdr fft noise\ntone wave noise gain fft\nwave radio wave fft fft\nwave pi sdr pi sdr\niq band wave wave pi\nradio radio noise sdr gain\ngain band fft pi noise\nband pi pi band wave\nwave wave band fft sdr\nwave pi band tone pi\nsdr wave band radio noise\ntone pi iq band radio\nsdr tone gain gain sdr\npi wave radio fft radio\nradio tone radio wave wave\nwave tone pi sdr iq\nsdr iq fft tone pi\nband pi wave sdr tone\ngain pi tone band radio\niq iq radio noise noise\nsdr iq band radio gain\ngain fft noise band fft\npi pi noise wave wave\nwave band iq fft wave\niq band sdr gain gain\ntone gain gain pi wave\ntone band gain noise sdr\nnoise iq band sdr pi\niq gain gain band noise\niq radio tone fft wave\npi tone gain iq band\nsdr noise tone pi noise\nradio iq gain fft wave\npi wave sdr gain radio\ngain noise tone radio tone\nradio wave tone band gain\nnoise iq tone fft band\nwave radio gain fft sdr\nsdr radio pi wave iq\nband noise tone pi fft\nfft gain radio noise gain\npi fft band tone iq\nnoise noise tone noise gain\nfft sdr iq iq tone\nsdr sdr pi fft gain\niq noise fft radio band\niq sdr tone iq radio\nsdr noise radio wave band\nband fft sdr gain radio\nband noise wave noise fft\nsdr gain fft gain pi\ngain iq tone noise tone\nradio band iq sdr fft\ntone radio wave fft sdr\nradio noise fft radio noise\nsdr band noise gain tone\nradio noise noise iq wave\nband tone iq gain pi\nnoise tone gain tone gain\nacademy{practice_grep}\niq noise pi wave band\niq fft gain radio tone\nsdr radio noise fft iq\nfft gain pi noise gain\ntone gain fft noise pi\nnoise iq sdr sdr fft\nband noise tone band tone\nnoise wave pi fft pi\nband gain pi noise radio\nradio pi gain gain tone\ngain gain iq tone tone\nradio radio fft fft gain\nnoise radio wave tone pi\ngain pi fft sdr band\nwave band gain gain wave\nband noise radio radio wave\nwave fft pi noise sdr\ngain noise radio gain band\nnoise pi band band fft\nnoise band wave wave noise\npi tone band pi tone\nsdr fft pi pi tone\nwave sdr iq radio iq\nnoise fft sdr iq band\nfft band sdr sdr fft\niq pi iq wave noise\ntone tone fft band wave\nwave fft wave noise band\nfft sdr wave radio sdr\nfft noise gain tone pi\nnoise pi band pi gain\ngain fft band gain wave\nsdr tone fft tone noise\npi iq band radio gain\niq band iq wave tone\nband wave pi gain radio\nnoise wave pi fft sdr\niq wave wave noise wave\nfft noise sdr band sdr\npi tone wave gain sdr\nfft noise fft tone radio\nband tone tone noise pi\nsdr radio tone gain sdr\niq pi tone pi radio\ntone iq iq pi tone\ntone iq radio pi fft\nband noise fft gain wave\ntone noise sdr wave noise\nfft gain gain radio gain\nradio radio sdr pi wave\nband fft gain sdr sdr\npi iq sdr wave band\nfft pi tone tone band\nfft iq iq wave sdr\nwave wave tone gain pi\npi band radio wave iq\niq band band iq pi\nband sdr iq radio gain\nwave iq iq band radio\npi iq band gain pi\nwave wave sdr gain band\nwave sdr wave pi wave\nsdr sdr iq sdr gain\nwave wave sdr fft band\ngain noise sdr radio iq\nsdr iq pi pi radio\nradio fft radio band fft\ntone pi fft gain sdr\npi sdr fft pi fft\nfft band band band fft\npi sdr fft band noise\niq gain sdr fft wave\nsdr radio fft iq wave\npi wave gain pi band\npi fft fft tone pi\npi wave pi pi tone\nnoise noise noise noise radio\niq band band tone wave\nsdr pi pi sdr pi\nband wave fft gain iq\ngain band band wave pi\nsdr sdr sdr radio gain\nsdr radio band noise iq\nnoise radio noise noise tone\nsdr tone gain pi radio\niq radio iq band tone\nnoise wave sdr gain fft\nsdr tone wave fft tone\ntone sdr wave tone pi\nfft radio pi sdr tone\ngain tone tone pi fft\npi iq radio wave fft\nsdr fft wave gain fft\npi wave wave noise sdr\nnoise gain pi radio band\niq band radio noise gain\nwave tone noise sdr pi\nwave noise band band radio\npi band pi gain noise\npi pi pi fft sdr\npi tone pi radio fft\npi iq fft noise iq\nradio pi noise noise gain\ngain radio iq pi iq\ntone tone wave sdr gain\nwave pi wave tone tone\nnoise band sdr wave pi\npi radio band noise noise\nradio sdr radio iq pi\nsdr gain noise pi band\nband wave sdr pi noise\nsdr noise radio tone tone\nfft radio radio tone noise\ntone tone radio fft pi\nwave radio noise gain sdr\nwave wave wave gain tone\nwave iq noise sdr sdr\npi gain tone wave noise\nsdr iq iq iq pi\npi iq fft iq pi\ngain pi iq iq radio\nwave gain iq sdr pi\nwave pi noise tone iq\niq wave tone fft sdr\npi fft wave iq wave\nband band gain pi sdr\ngain fft sdr wave fft\nradio fft tone wave pi\npi iq noise iq iq\nradio pi iq tone pi\nwave noise tone pi pi\niq iq noise radio fft\nsdr fft sdr iq sdr\nfft wave iq band radio\ntone radio gain tone sdr\ntone radio wave sdr band\niq pi iq wave sdr\nnoise iq radio wave noise\ntone band wave pi gain\nsdr radio sdr tone iq\nwave pi iq tone fft\niq wave band wave wave\niq wave noise iq noise\nwave tone sdr gain radio\ntone gain sdr band tone\nradio wave sdr radio band\nnoise band iq iq fft\nfft gain radio noise wave\nfft pi noise gain radio\nradio fft radio band tone\nsdr radio wave gain radio\npi band iq gain noise\nband wave radio noise gain\npi sdr gain pi sdr\nnoise pi noise radio radio\ngain pi fft gain noise\nfft band pi iq wave\niq fft band tone fft\nfft wave gain pi band\nnoise band gain radio noise\nwave gain tone fft noise\npi sdr band iq wave\ntone sdr iq iq tone\nradio iq tone wave gain\npi wave fft gain gain\nradio wave tone tone gain\niq tone radio wave wave\nnoise pi sdr fft radio\ngain band gain pi iq\nband iq tone band fft\ntone tone gain tone radio\niq sdr radio gain tone\npi noise fft wave wave\nband wave tone noise noise\nradio pi band iq band\nsdr wave sdr band fft\ngain fft noise sdr pi\nsdr radio pi wave sdr\nradio wave radio noise wave\nsdr sdr pi pi pi\nwave radio iq tone pi\nfft tone tone noise gain\niq noise tone sdr pi\nnoise radio noise pi pi\nband sdr noise radio tone\ntone fft iq radio wave\nband fft sdr radio gain\ngain noise sdr wave noise\npi iq pi pi band\nradio wave iq iq wave\nband pi iq band gain\nradio sdr wave band wave\npi iq wave noise fft\ngain fft fft tone sdr\nsdr wave sdr wave fft\nnoise wave iq band wave\nradio wave noise noise radio\nradio sdr wave iq tone\nnoise gain tone fft noise\nsdr band tone pi noise\nsdr tone fft wave radio\nradio wave iq sdr wave\ntone pi fft fft tone\niq fft noise pi pi\npi band gain gain iq\npi noise fft wave iq\ntone iq gain tone fft\niq tone band sdr pi\niq pi noise radio sdr\nfft radio pi iq band\nsdr noise pi tone gain\nfft pi radio gain pi\nsdr sdr noise radio fft\npi pi tone radio fft\nband gain radio wave radio\ngain gain tone tone pi\nwave iq fft pi pi\nnoise gain iq wave radio\nband noise iq gain wave\nradio wave iq pi fft\ntone wave sdr noise fft\niq radio band tone tone\nradio tone wave gain sdr\nsdr wave band tone sdr\nnoise band sdr sdr tone\nwave tone noise tone noise\ntone band tone gain gain\nnoise pi wave sdr gain\nband wave sdr radio radio\nnoise noise fft tone gain\ngain noise radio wave fft\ntone sdr tone radio tone\nradio fft sdr fft iq\ntone iq iq wave tone\ntone wave pi pi pi\ntone sdr sdr wave tone\npi band pi iq sdr\nwave iq gain noise iq\ngain noise band iq tone\ntone noise tone band pi\nband band fft pi iq\niq gain sdr wave wave\nwave tone fft tone pi\nband sdr iq band band\ngain sdr radio gain pi\nradio fft noise fft tone\npi wave band sdr wave\ntone gain radio gain pi\ngain wave tone noise tone\nfft radio iq fft fft\nsdr radio band gain fft\nradio radio sdr fft pi\nband tone sdr sdr wave\nfft sdr fft wave fft\niq radio fft wave radio\nradio iq sdr gain radio\nband noise band noise wave\ngain wave fft iq sdr\npi sdr tone radio wave\nfft noise wave fft radio\nwave band radio wave band\npi iq band wave noise\ngain fft sdr iq sdr\niq pi pi fft gain\nradio tone iq radio wave\nfft tone gain wave wave\nwave radio gain tone band\ngain noise noise radio wave\niq pi radio wave band\ntone pi fft noise radio\ngain iq iq band iq\niq noise iq fft wave\niq band fft radio fft\nradio wave pi tone gain\npi gain pi tone gain\ntone tone gain radio iq\nband fft sdr sdr iq\ntone fft gain gain band\nnoise radio fft sdr radio\ntone gain tone band band\nwave tone radio fft fft\ngain radio noise pi radio\nsdr band tone iq iq\niq noise tone fft sdr\ntone fft fft tone iq\npi tone noise gain band\nband band noise sdr tone\ngain pi tone fft sdr\nnoise tone noise iq radio\ngain sdr pi wave wave\nsdr radio radio noise wave\nwave sdr gain noise pi\npi radio fft fft pi\nradio gain wave sdr iq\ngain gain pi radio band\nradio noise sdr pi sdr\nradio pi sdr sdr tone\nradio pi iq radio pi\nradio wave band tone wave\ntone pi gain tone gain\ngain noise iq wave iq\nsdr radio radio radio radio\ntone sdr iq fft band\nsdr iq fft band sdr\niq iq sdr band tone\ngain fft radio sdr fft\nfft radio iq radio gain\nradio sdr fft fft sdr\ntone gain wave band gain\ngain tone iq band band\nradio tone gain wave noise\nwave band sdr band tone\ntone fft noise band tone\nradio band fft iq noise\npi iq sdr radio gain\npi band gain noise band\nfft gain sdr pi band\nradio pi gain noise pi\nband gain iq noise pi\niq tone pi sdr iq\nnoise wave pi noise noise\ntone wave fft fft fft\ngain band noise iq tone\ngain iq pi sdr radio\nnoise sdr band fft radio\ntone gain wave noise fft\nsdr iq iq sdr pi\npi sdr wave iq band\niq pi noise tone band\nradio radio pi radio fft\nnoise tone radio radio wave\niq wave noise noise sdr\nwave radio band noise pi\ngain fft band iq wave\npi gain iq tone sdr\ngain wave iq iq fft\nwave noise radio fft pi\nfft tone gain radio radio\niq iq iq noise band\ntone pi fft iq band\ntone radio tone pi tone\ngain pi radio iq band\nnoise tone gain band fft\nradio tone sdr tone wave\niq pi noise iq tone\nband tone iq wave fft\nradio tone wave band wave\nnoise noise wave band pi\ngain sdr wave fft pi\nwave fft fft pi wave\npi noise pi wave band\nsdr noise sdr gain pi\nnoise tone band sdr fft\ngain tone band fft radio\nsdr band wave radio wave\npi wave pi noise band\nfft tone gain gain sdr\npi band gain pi noise\nfft radio gain tone sdr\nsdr sdr gain band fft\ngain radio tone tone fft\nradio tone tone noise fft\nradio radio radio radio radio\npi band pi radio noise\nfft band band pi fft\niq gain iq fft sdr\nsdr wave gain radio wave\nsdr wave tone wave pi\niq band gain gain tone\niq sdr wave sdr iq\nfft wave sdr band radio\nwave pi noise pi tone\npi tone pi gain noise\npi fft iq wave radio\nradio noise gain tone pi\nfft gain radio band sdr\niq pi radio sdr noise\nfft sdr tone sdr pi\nfft wave fft gain radio\nwave wave gain noise iq\npi wave iq sdr wave\ngain pi wave gain pi\nfft noise tone tone wave\nnoise tone wave sdr gain\ngain gain pi radio pi\npi sdr fft wave noise\npi gain fft iq noise\nwave pi iq band iq\nnoise pi band iq radio\nradio pi iq gain radio\nsdr radio band sdr pi\npi tone wave sdr wave\nband noise tone radio tone\ngain noise radio iq iq\nradio sdr radio pi fft\ngain wave radio noise pi\npi gain pi wave sdr\nradio sdr tone pi noise\nband tone fft band iq\nband fft wave noise fft\nwave iq tone radio tone\ntone fft fft band wave\nband noise fft radio fft\nsdr gain gain band radio\nsdr fft noise noise pi\niq tone fft iq wave\nfft fft gain fft noise\nnoise gain sdr noise iq\ntone wave iq tone noise\niq tone pi tone wave\nwave gain noise tone sdr\nnoise fft sdr tone tone\ngain sdr gain band fft\nnoise wave tone tone iq\npi radio iq pi tone\nwave noise iq sdr radio\ntone gain iq noise gain\nradio tone radio radio radio\ntone noise sdr wave tone\nsdr radio sdr gain gain\nwave radio tone fft pi\npi noise iq fft gain\nband noise sdr gain gain\nradio gain sdr tone pi\ntone tone radio sdr band\nwave wave sdr band band\nband wave noise pi wave\nwave wave iq band band\ntone pi sdr band tone\nfft band pi fft iq\npi wave wave iq noise\ngain tone sdr wave pi\ntone gain wave gain wave\ntone band wave gain sdr\nfft fft noise noise iq\niq iq sdr sdr gain\niq wave band band radio\nband iq fft gain radio\npi noise iq pi noise\niq wave sdr pi pi\npi radio tone sdr gain\ngain fft iq noise tone\nfft tone radio pi fft\nfft iq pi tone noise\nfft wave wave gain tone\ntone band band fft band\nnoise noise pi band tone\npi tone fft tone radio\ntone pi tone radio gain\nsdr tone wave gain sdr\nradio wave fft iq tone\ngain noise wave radio iq\nradio tone sdr sdr gain\nwave tone gain sdr iq\nfft iq wave fft radio\npi radio radio noise fft\nradio band radio fft tone\nnoise fft fft radio iq\nband pi radio noise noise\nnoise wave fft band band\nwave iq tone band radio\ntone iq iq fft radio\nsdr pi pi band band\nsdr band fft radio noise\npi radio fft sdr sdr\nband wave iq pi iq\nfft wave radio wave tone\ntone band sdr radio tone\ntone pi pi sdr band\npi sdr radio noise noise\nnoise pi wave iq band\nnoise fft sdr sdr noise\nwave noise pi fft iq\nband band radio gain fft\niq gain iq wave wave\nnoise noise fft wave radio\nnoise gain sdr wave pi\nwave iq tone iq fft\ntone fft iq sdr band\ntone gain wave radio tone\niq gain radio fft radio\ngain radio iq fft wave\nwave wave tone band pi\nnoise noise tone pi iq\nnoise gain band band wave\ntone gain sdr noise noise\nradio fft fft band band\nradio radio noise pi gain\niq gain gain wave pi\nradio gain radio fft radio\ntone wave gain gain noise\nradio pi radio band wave\nradio iq band fft wave\niq fft iq pi sdr\nwave iq sdr band pi\nfft gain wave noise band\nwave band radio tone tone\npi iq pi radio noise\nradio noise fft pi sdr\nband sdr wave wave wave\npi noise noise pi noise\niq radio noise sdr noise\niq wave tone wave gain\npi wave sdr pi tone\npi iq iq sdr wave\nwave tone sdr tone gain\ngain fft gain wave noise\ngain pi band fft iq\ngain band fft iq noise\nradio gain gain wave sdr\nfft wave iq band wave\nfft fft pi pi tone\ngain sdr sdr noise iq\nradio wave iq radio noise\ngain wave radio gain sdr\nnoise sdr gain iq tone\nfft band wave tone pi\nradio sdr pi noise sdr\nnoise noise fft radio pi\npi pi noise sdr tone\nradio band gain fft gain\npi pi fft iq noise\niq iq gain pi gain\nwave gain wave tone iq\ngain gain fft fft noise\npi band sdr iq noise\nwave radio iq gain band\nnoise tone radio band fft\nradio gain radio noise wave\npi fft sdr gain pi\nsdr band iq noise band\niq pi pi pi gain\nnoise fft sdr gain tone\nradio iq pi sdr sdr\nradio fft wave pi pi\nfft wave band fft pi\nradio noise gain iq noise\nband wave tone sdr band\npi fft gain noise band\nsdr pi pi gain pi\nband wave band noise iq\nnoise radio band gain sdr\nnoise iq band tone noise\nfft noise fft pi pi\nfft iq tone wave tone\npi tone fft fft noise\nnoise tone wave gain fft\nnoise band band wave gain\niq noise band wave radio\nfft radio fft sdr pi\nnoise radio tone noise band\nwave gain iq radio pi\nnoise pi radio iq fft\ngain sdr wave gain gain\ngain wave tone fft noise\ngain band gain fft gain\nwave gain radio fft tone\nfft iq sdr pi wave\npi fft radio tone noise\niq iq tone noise band\ntone radio fft radio radio\npi radio band fft wave\niq tone pi fft radio\nradio fft wave tone noise\nnoise pi noise wave gain\nsdr gain wave gain iq\nsdr iq gain sdr pi\nwave gain noise wave sdr\nband pi iq gain band\nfft pi wave iq noise\nwave sdr tone band sdr\npi band sdr band iq\nfft radio gain radio fft\niq noise tone gain radio\nwave pi band tone band\ngain wave noise band tone\nsdr fft tone fft pi\nsdr tone noise noise noise\ngain fft iq iq iq\niq band tone pi band\nradio pi wave radio wave\nradio wave iq tone wave\ntone iq iq sdr radio\nsdr radio iq pi pi\niq sdr sdr iq gain\nfft pi gain wave radio\nsdr band gain wave tone\nnoise iq gain gain sdr\nfft sdr tone sdr band\ngain wave wave tone sdr\nsdr pi sdr gain iq\niq tone pi band gain\nband tone sdr gain noise\ngain band pi iq fft\nfft gain pi iq pi\ngain pi iq gain fft\nband sdr pi band iq\nnoise sdr band gain band\nnoise sdr iq wave tone\nband iq gain pi noise\n', 'challenge/decoys_only.txt': 'academy{decoy_a0ef}\nacademy{decoy_c2e0}\nacademy{decoy_9a74}\nacademy{decoy_9dd4}\nacademy{decoy_0d71}\nacademy{decoy_54f1}\nacademy{decoy_4e92}\nacademy{decoy_8b03}\nacademy{decoy_3c1f}\nacademy{decoy_eda7}\nacademy{decoy_d368}\nacademy{decoy_9115}\nacademy{decoy_6646}\nacademy{decoy_e9dc}\nacademy{decoy_e317}\nacademy{decoy_90e7}\nacademy{decoy_cc89}\nacademy{decoy_fe01}\nacademy{decoy_a8ec}\nacademy{decoy_0775}\nacademy{decoy_6e32}\nacademy{decoy_75c0}\nacademy{decoy_e1fc}\nacademy{decoy_8d61}\nacademy{decoy_a26e}\nacademy{decoy_ba10}\nacademy{decoy_948d}\nacademy{decoy_f7fe}\nacademy{decoy_2571}\nacademy{decoy_9f90}\nacademy{decoy_bbd1}\nacademy{decoy_7a5e}\nacademy{decoy_4dcf}\nacademy{decoy_a25e}\nacademy{decoy_e708}\nacademy{decoy_888c}\nacademy{decoy_0b8d}\nacademy{decoy_b477}\nacademy{decoy_4a1d}\nacademy{decoy_f26b}\nacademy{decoy_aa8e}\nacademy{decoy_0390}\nacademy{decoy_25d6}\nacademy{decoy_5204}\nacademy{decoy_b5af}\nacademy{decoy_e059}\nacademy{decoy_b381}\nacademy{decoy_0f45}\nacademy{decoy_c3e2}\nacademy{decoy_ca50}\nacademy{decoy_3e8d}\nacademy{decoy_07e8}\nacademy{decoy_e90d}\nacademy{decoy_a5ef}\nacademy{decoy_2a2b}\nacademy{decoy_cce1}\nacademy{decoy_4334}\nacademy{decoy_3cf3}\nacademy{decoy_bb95}\nacademy{decoy_6197}\nacademy{decoy_d655}\nacademy{decoy_39f6}\nacademy{decoy_bee2}\nacademy{decoy_b46b}\nacademy{decoy_b7ce}\nacademy{decoy_875e}\nacademy{decoy_fabf}\nacademy{decoy_9b09}\nacademy{decoy_c50b}\nacademy{decoy_5353}\nacademy{decoy_9d52}\nacademy{decoy_9632}\nacademy{decoy_244e}\nacademy{decoy_f456}\nacademy{decoy_ce2c}\nacademy{decoy_c779}\nacademy{decoy_d1be}\nacademy{decoy_f3a6}\nacademy{decoy_19da}\nacademy{decoy_3f48}\nacademy{decoy_7078}\nacademy{decoy_841a}\nacademy{decoy_e2e4}\nacademy{decoy_62bc}\nacademy{decoy_f3a5}\nacademy{decoy_5898}\nacademy{decoy_274e}\nacademy{decoy_cdac}\nacademy{decoy_72c4}\nacademy{decoy_2ccb}\nacademy{decoy_d81d}\nacademy{decoy_8efb}\nacademy{decoy_f64b}\nacademy{decoy_c628}\nacademy{decoy_49f5}\nacademy{decoy_ef7c}\nacademy{decoy_5ee5}\nacademy{decoy_04c3}\nacademy{decoy_8722}\nacademy{decoy_454e}\n', 'challenge/decoys_and_real.txt': 'academy{decoy_a0ef}\nacademy{decoy_c2e0}\nacademy{decoy_9a74}\nacademy{decoy_9dd4}\nacademy{decoy_0d71}\nacademy{decoy_54f1}\nacademy{decoy_4e92}\nacademy{decoy_8b03}\nacademy{decoy_3c1f}\nacademy{decoy_eda7}\nacademy{decoy_d368}\nacademy{decoy_9115}\nacademy{decoy_6646}\nacademy{decoy_e9dc}\nacademy{decoy_e317}\nacademy{decoy_90e7}\nacademy{decoy_cc89}\nacademy{decoy_fe01}\nacademy{decoy_a8ec}\nacademy{decoy_0775}\nacademy{decoy_6e32}\nacademy{decoy_75c0}\nacademy{decoy_e1fc}\nacademy{decoy_8d61}\nacademy{decoy_a26e}\nacademy{decoy_ba10}\nacademy{decoy_948d}\nacademy{decoy_f7fe}\nacademy{decoy_2571}\nacademy{decoy_9f90}\nacademy{decoy_bbd1}\nacademy{decoy_7a5e}\nacademy{decoy_4dcf}\nacademy{decoy_a25e}\nacademy{decoy_e708}\nacademy{decoy_888c}\nacademy{decoy_0b8d}\nacademy{practice_diff}\nacademy{decoy_b477}\nacademy{decoy_4a1d}\nacademy{decoy_f26b}\nacademy{decoy_aa8e}\nacademy{decoy_0390}\nacademy{decoy_25d6}\nacademy{decoy_5204}\nacademy{decoy_b5af}\nacademy{decoy_e059}\nacademy{decoy_b381}\nacademy{decoy_0f45}\nacademy{decoy_c3e2}\nacademy{decoy_ca50}\nacademy{decoy_3e8d}\nacademy{decoy_07e8}\nacademy{decoy_e90d}\nacademy{decoy_a5ef}\nacademy{decoy_2a2b}\nacademy{decoy_cce1}\nacademy{decoy_4334}\nacademy{decoy_3cf3}\nacademy{decoy_bb95}\nacademy{decoy_6197}\nacademy{decoy_d655}\nacademy{decoy_39f6}\nacademy{decoy_bee2}\nacademy{decoy_b46b}\nacademy{decoy_b7ce}\nacademy{decoy_875e}\nacademy{decoy_fabf}\nacademy{decoy_9b09}\nacademy{decoy_c50b}\nacademy{decoy_5353}\nacademy{decoy_9d52}\nacademy{decoy_9632}\nacademy{decoy_244e}\nacademy{decoy_f456}\nacademy{decoy_ce2c}\nacademy{decoy_c779}\nacademy{decoy_d1be}\nacademy{decoy_f3a6}\nacademy{decoy_19da}\nacademy{decoy_3f48}\nacademy{decoy_7078}\nacademy{decoy_841a}\nacademy{decoy_e2e4}\nacademy{decoy_62bc}\nacademy{decoy_f3a5}\nacademy{decoy_5898}\nacademy{decoy_274e}\nacademy{decoy_cdac}\nacademy{decoy_72c4}\nacademy{decoy_2ccb}\nacademy{decoy_d81d}\nacademy{decoy_8efb}\nacademy{decoy_f64b}\nacademy{decoy_c628}\nacademy{decoy_49f5}\nacademy{decoy_ef7c}\nacademy{decoy_5ee5}\nacademy{decoy_04c3}\nacademy{decoy_8722}\nacademy{decoy_454e}\n', 'challenge/run-practice': '', 'home/hacker/delete_me': 'bye\n', 'home/hacker/keep_me': 'stay\n', '.secret-practice': '', 'usr/lib/flag': 'not this one\n', 'CLUE': 'The trail starts in usr/share/doc/quest (from the root). Read the file called HINT there.\n', 'usr/share/doc/quest/HINT': 'Not here! Head to var/cache/quest/old and read the file named NEXT.\n', 'var/cache/quest/old/NEXT': 'Almost there. The treasure is in a HIDDEN folder inside opt/quest. Try ls -a.\n', 'opt/quest/TREASURE': 'Nice try. This one is a decoy.\n', 'opt/quest/.hideout/TREASURE': 'academy{practice_quest}\n'}
PROGS = {'challenge/catflag': '#!/bin/bash\ncat "$HOME/not-the-flag"\n'}
PRACTICE = {}


QUEST = {'CLUE': 'The trail starts in usr/share/doc/quest (from the root). Read the file called HINT there.\n', 'usr/share/doc/quest/HINT': 'Not here! Head to var/cache/quest/old and read the file named NEXT.\n', 'var/cache/quest/old/NEXT': 'Almost there. The treasure is in a HIDDEN folder inside opt/quest. Try ls -a.\n', 'opt/quest/TREASURE': 'Nice try. This one is a decoy.\n', 'opt/quest/.hideout/TREASURE': 'academy{practice_quest}\n'}

def elsewhere():
    return sandbox()  # an empty folder outside $DOJO, so relative paths into $DOJO fail

@task("1 cat")
def _():
    s = secret("cat")
    r, _ = go(1, dojo({"home/hacker/flag": s + "\n"}))
    assert r.stdout.strip() == s, f"print the contents of ~/flag {show(r)}"

@task("2 cat an absolute path")
def _():
    s = secret("abs")
    root = dojo({"flag": s + "\n"})
    r, _ = go(2, root, cwd=elsewhere())
    assert r.stdout.strip() == s, f"print $DOJO/flag by its absolute path (the check runs this script from outside $DOJO) {show(r)}"

@task("3 more catting practice")
def _():
    s = secret("chase")
    r, _ = go(3, dojo({"opt/vault/a1/b2/c3/flag": s + "\n"}), cwd=elsewhere())
    assert r.stdout.strip() == s, f"print $DOJO/opt/vault/a1/b2/c3/flag by its absolute path {show(r)}"

@task("4 grep for a needle")
def _():
    s = secret("grep")
    data = [" ".join(RNG.choice(["sdr", "pi", "radio", "wave", "academy", "flag"]) for _ in range(5)) for _ in range(20000)]
    data.insert(RNG.randrange(20000), s)
    r, _ = go(4, dojo({"challenge/data.txt": "\n".join(data) + "\n"}))
    assert r.stdout.strip() == s, f"print only the line containing academy{{ {show(r)}"

@task("5 diff")
def _():
    s = secret("diff")
    dec = [secret("decoy") for _ in range(100)]
    both = dec[:]
    both.insert(RNG.randrange(100), s)
    r, _ = go(5, dojo({"challenge/decoys_only.txt": "\n".join(dec) + "\n",
                       "challenge/decoys_and_real.txt": "\n".join(both) + "\n"}))
    assert s in r.stdout, f"the extra line should be in diff's output {show(r)}"
    assert sum(d in r.stdout for d in dec) == 0, "print only the difference, not the decoys"

@task("6 ls")
def _():
    name = "run-" + word()
    r, _ = go(6, dojo({"challenge/" + name: ""}))
    assert name in r.stdout.split(), f"list $DOJO/challenge (it holds a file called {name}) {show(r)}"

@task("7 touch")
def _():
    root = dojo()
    r, _ = go(7, root)
    for f in ("pwn", "college"):
        p = root / "tmp" / f
        assert p.is_file(), f"$DOJO/tmp/{f} was not created {show(r)}"
        assert p.stat().st_size == 0, f"$DOJO/tmp/{f} should be empty"

@task("8 rm")
def _():
    root = dojo()
    r, _ = go(8, root)
    assert not (root / "home/hacker/delete_me").exists(), f"~/delete_me still exists {show(r)}"
    assert (root / "home/hacker/keep_me").exists(), "only delete ~/delete_me, keep ~/keep_me"

@task("9 mv")
def _():
    s = secret("mv")
    root = dojo({"flag": s + "\n"})
    r, _ = go(9, root)
    dst = root / "tmp/hack-the-planet"
    assert dst.is_file() and dst.read_text().strip() == s, f"$DOJO/tmp/hack-the-planet should contain the text that was in $DOJO/flag {show(r)}"
    assert not (root / "flag").exists(), "mv moves: $DOJO/flag should be gone"

@task("10 cp")
def _():
    s = secret("cp")
    root = dojo({"flag": s + "\n"})
    r, _ = go(10, root)
    dst = root / "tmp/hack-the-planet"
    assert dst.is_file() and dst.read_text().strip() == s, f"$DOJO/tmp/hack-the-planet should be a copy of $DOJO/flag {show(r)}"
    assert (root / "flag").exists(), "cp copies: $DOJO/flag must still exist"

@task("11 hidden files")
def _():
    name = ".secret-" + word()
    r, _ = go(11, dojo({name: ""}))
    assert name in r.stdout.split(), f"list everything in $DOJO, including hidden files {show(r)}"

@task("12 filesystem quest")
def _():
    s = secret("quest")
    r, _ = go(12, dojo({"opt/quest/.hideout/TREASURE": s + "\n"}))
    assert r.stdout.strip() == s, f"follow the clues and print the real treasure file at the end {show(r)}"

@task("13 mkdir")
def _():
    root = dojo()
    r, _ = go(13, root)
    assert (root / "tmp/pwn").is_dir(), f"$DOJO/tmp/pwn should be a directory {show(r)}"
    assert (root / "tmp/pwn/college").is_file(), "create the file $DOJO/tmp/pwn/college"

@task("14 find")
def _():
    extra = {}
    for _ in range(4):
        extra["/".join(word(4) for _ in range(RNG.randint(1, 4))) + "/flag"] = secret("find")
    root = dojo(extra)
    want = sorted(str(p) for p in root.rglob("flag") if p.is_file())
    r, _ = go(14, root)
    got = sorted(lines(r))
    assert got == want, f"expected the {len(want)} paths of files named flag under $DOJO, got {len(got)} lines {show(r)}"

@task("15 symbolic link")
def _():
    s = secret("ln")
    root = dojo({"flag": s + "\n"})
    r, _ = go(15, root)
    link = root / "home/hacker/not-the-flag"
    assert link.is_symlink(), f"~/not-the-flag should be a symbolic link {show(r)}"
    assert s in r.stdout, f"catflag did not print $DOJO/flag. Did you run it after you made the link? {show(r)}"

print(f"{len(passed)}/{len(passed) + len(failed)} tasks pass")
if failed:
    print("Not yet:")
    for line in failed:
        print("  -", line)
    raise SystemExit(1)
print("CHECK_OK")
