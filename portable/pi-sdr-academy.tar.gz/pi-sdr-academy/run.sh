#!/bin/sh
# Closed-network launcher. Needs: python3 only. No pip. No internet.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname "$0")" && pwd)

# Prefer this folder's code — ignore user site-packages on the host.
export PYTHONNOUSERSITE=1
export PYTHONPATH="$ROOT/vendor:$ROOT/platform"

# Docker layout puts academy/ at ROOT
if [ ! -d "$ROOT/platform/academy" ] && [ -d "$ROOT/academy" ]; then
  export PYTHONPATH="$ROOT/vendor:$ROOT"
fi

export ACADEMY_CURRICULUM="${ACADEMY_CURRICULUM:-$ROOT/curriculum}"
export ACADEMY_DATA="${ACADEMY_DATA:-$ROOT/.academy-data}"
export ACADEMY_WORKSPACE="${ACADEMY_WORKSPACE:-$HOME/signal-dojo/challenge}"
export ACADEMY_FLAG_PATH="${ACADEMY_FLAG_PATH:-$ROOT/.academy-data/flag.txt}"

# The course teaches vim. Anything that opens an editor (git commit, crontab -e,
# sudoedit) gets vim, or vi where vim is missing; never the distro default.
_editor=vi
command -v vim >/dev/null 2>&1 && _editor=vim
export EDITOR="$_editor" VISUAL="$_editor" GIT_EDITOR="$_editor" SUDO_EDITOR="$_editor"

if ! command -v python3 >/dev/null 2>&1; then
  echo "Signal Dojo needs python3 on PATH." >&2
  echo "No pip install required — only the python3 interpreter." >&2
  exit 1
fi

# Prove the pack is complete before opening the port.
if ! python3 -c "import yaml, academy"; then
  echo "Self-check failed: cannot import vendored yaml/academy." >&2
  echo "PYTHONPATH=$PYTHONPATH" >&2
  exit 1
fi

mkdir -p "$ACADEMY_DATA" "$ACADEMY_WORKSPACE"
HOST="${HOST:-127.0.0.1}"
PORT="${PORT:-8080}"

echo ""
echo "  Signal Dojo  (offline / closed network)"
echo "  Open  http://$HOST:$PORT/"
echo "  Then  Start (a terminal opens in $ACADEMY_WORKSPACE) → solve → Done"
echo ""

case "${ACADEMY_ADMIN:-0}" in
  1|true|yes)
    echo "  Admin http://$HOST:$PORT/admin"
    exec python3 -m academy.cli admin --host "$HOST" --port "$PORT"
    ;;
  *)
    exec python3 -m academy.cli serve --local --host "$HOST" --port "$PORT"
    ;;
esac
