# Signal Dojo

An offline lab that teaches software-defined radio from zero: **8 belts, 134 challenges, Linux → C++ → Python → radio**. It runs on a Raspberry Pi (or any machine with `python3`).

## Run it

```bash
tar -xzf pi-sdr-academy.tar.gz && cd pi-sdr-academy
./run.sh            # open the URL it prints
```

Press **Read lesson** to learn the idea, **Start** to get the files (a terminal opens in `~/signal-dojo/challenge`), solve, run `./check`, then press **Done**.

One-page guide for learners and admins: [docs/signal-dojo-guide.pdf](docs/signal-dojo-guide.pdf) (rebuild with `./scripts/build_guide.sh`).

### Save your work

**Save to a file** (in the lab, under Progress) downloads one `.zip` with your progress and every script you
wrote. **Restore** on any copy of Signal Dojo, even on another machine, brings it back; it only adds, so
nothing already solved is lost. From a terminal: `./academy save` (writes `~/signal-dojo/signal-dojo-save-DATE.zip`)
and `./academy restore FILE`.

Start empties the challenge folder, so the files you wrote or changed are kept first (in `.academy-data/work/`)
and come back when you start that challenge again. **Restart** on the challenge you are in gives you clean
starter files. Files over 5 MB (captures, recordings) are not kept; they come back with the challenge.

No pip, no internet. To build the tarball: `./scripts/pack_portable.sh` (→ `dist/`).

## Belts

| Belt | What you learn |
|------|----------------|
| White | Terminal from zero, shell basics |
| Yellow | Processes, users, permissions, scripts, services |
| Orange | C++ from zero: first programs, strings, vectors, classes, files, then pointers and bytes, gdb, Linux system calls and the C++ qualification |
| Blue | Python from zero to qualification |
| Purple | GNU Radio: the official GNU Radio tutorials as 8 missions, built in your own GNU Radio Companion (3.10+) and checked by rebuilding your `.grc` |
| Brown | **Range 7: Sentry Tower Bring-Up**. PySDR chapters 1-4, 6 (USRP) and 10-13, one short mission and a theory quiz per chapter |
| Red | **Range 7: Unknown Aircraft**. PySDR chapters 14-18 and 24, one short mission and a theory quiz per chapter |
| Black | **Operation Ghost Rotor**: one real-world project that uses every belt. A hostile drone circles a desert test range and the sensor tower's USRP recorded 2.25 s of its 915 MHz downlink. Build the counter-drone ground station (shell, Python, GNU Radio, DSP, C++ with gdb, systemd) that tracks it, finds its operator and rebuilds the last picture from its camera, graded as seven milestones |

Every Brown and Red challenge says which PySDR chapter to read first, then has you write two small Python functions from it. The mission script, `mission.py`, is already written: it uses your two functions on a simulated USRP recording at **Range 7**, the fictional Bastion Dynamics test range of the Black belt, and saves the picture the link carries as `picture.png`. In Brown you bring Sentry Tower 3's USRP up on your own test drones. In Red you track unknown drones over the range, up to the night of Operation Ghost Rotor. `./check` tests your functions and checks `picture.png`.

The only radio the academy uses is the Ettus **USRP** (B210), and every recording is simulated, so no radio is needed.

Each challenge folder has a short `README` (the tasks) and a `LESSON` (the teaching, new words, further reading). Both open inside the app too.

## Lab machine packages

```bash
sudo apt install vim tmux curl build-essential manpages-dev gdb cmake pkg-config \
                 python3-numpy python3-scipy gnuradio gnuradio-dev
sudo update-alternatives --set editor /usr/bin/vim.basic   # make vim the system editor
```

The course teaches **vim** as the one text editor. `./run.sh` and the terminal the app opens
set `EDITOR`/`VISUAL` to vim (or `vi` if vim is missing), so `git commit`, `crontab -e` and
`sudoedit` open vim too. The `update-alternatives` line above does the same for any shell.

## Admin mode: open any challenge

```bash
ACADEMY_ADMIN=1 ./run.sh
```

Every belt is unlocked. Open `http://127.0.0.1:8080/`, enter the lab, and use the **Admin mode** box to jump to
any challenge by id or title, then press **Start**. `http://127.0.0.1:8080/admin` lists every challenge with a
filter, and a link like `http://127.0.0.1:8080/#challenge/pysdr-17-synchronization` opens one directly. From a
terminal, `ACADEMY_ADMIN=1 ./academy start pysdr-17-synchronization` stages it in `~/signal-dojo/challenge`.
Admin mode is ignored by the classroom server (`./academy serve`), so learners never get it.

### Turn dojos and challenges on or off

`/admin` has a **Turn dojos and challenges on or off** list: every dojo with a checkbox, and inside it every
challenge with its own. Uncheck one and learners no longer see it: it leaves the dojo, the profile, the belt
counts and `./academy`, and it cannot be started; a dojo with every challenge off disappears and stops blocking
the next belt. Check it again to bring it back; progress is kept. The switches live in
`.academy-data/disabled.json`, apply to the classroom server too, and `scripts/pack_portable.sh` copies them
into the tarball.

Admin mode is password protected. The first `./run.sh` asks you to set the admin password (Enter skips; the first
admin run then asks instead), and every admin run asks for it in the terminal. Only a salted hash is stored, in
`.academy-data/admin.json`. Change it with `./academy admin --change-password`. Forgot it? Run
`./academy admin --reset-password` (or delete that file) and the next admin run sets a new one.
`scripts/pack_portable.sh` copies the hash into the tarball so learner copies stay locked. Anyone who can edit this
folder can also reset the password, so it keeps learners out of admin mode, not someone with your files.

## Instructor answers guide

Every challenge has a worked answer, and a script proves each one still passes its own check:

```bash
python3 scripts/verify_answers.py --json dist/verify.json      # fresh copy of each challenge, answer applied, ./check run
python3 scripts/build_answers_guide.py --report dist/verify.json --pdf   # dist/signal-dojo-answers.pdf
```

The answers live in each challenge's `solution/` folder (plus `solve.sh` for the commands a learner types), and the
walkthroughs in `docs/answers/`. PySDR challenges without a walkthrough get one generated from their verified
solution. Neither ships in the learner tarball.

## Classroom

`./academy serve --host <LAN IP>` serves the whole class with logins and an optional shared git repo for progress. See [docs/CLASSROOM.md](docs/CLASSROOM.md).

## Notes

- Instructor solutions live in `solution/` next to each `files/`; they never reach learners and are left out of the tarball unless `INCLUDE_SOLUTIONS=1`.
- The Linux shell modules are adapted from pwn.college Linux Luminarium (BSD 2-Clause). The PySDR modules are original challenges on the topics of PySDR by Marc Lichtman.
- No lesson links to the internet. The PySDR chapters (CC BY-NC-SA 4.0, so the academy must not be sold while it ships them) and the GNU Radio wiki tutorials (CC BY-SA 4.0) are saved in `curriculum/readings/` and served at `/readings/`. `python3 scripts/fetch_readings.py` downloads them again on a machine with internet; the page list is `curriculum/readings/sources.json`. `scripts/check_curriculum.py` fails on any outside link in a challenge.

```text
run.sh  academy  curriculum/  platform/  vendor/  scripts/  docs/
```
